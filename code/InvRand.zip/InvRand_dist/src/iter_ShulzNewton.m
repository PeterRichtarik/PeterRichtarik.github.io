function M = iter_ShulzNewton(A,M,options)
M =2*M - M*A*M;
end