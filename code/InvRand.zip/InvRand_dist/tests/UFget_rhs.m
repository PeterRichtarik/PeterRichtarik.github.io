cd /home/s1065527/Software/Matlab/UFget
