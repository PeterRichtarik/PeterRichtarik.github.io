function x =iter_BCD(A,b,x,options)
s = randsample(length(b),options.block_size);
x(s) = x(s) -(A(s,s)\(A(s,:)*x -b(s))) ;
end


