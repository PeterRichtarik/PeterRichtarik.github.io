/*
 *  Created on: 8 April 2014
 *      Author: Olivier Fercoq
 */

#ifndef LINESEARCHES_H
#define LINESEARCHES_H

#include "../class/loss/losses.h"

/*

//Only ESO is useful since dso is a particular case of ESO with Q=(0,...,0,1)
template<typename L, typename D, typename traits> 
void dsoLineSearch(const problem_data<L, D> &inst,
		   const std::vector<D> &residuals, const L idx,
		   std::vector<D> &h_Li, D epsilon, std::vector<D> &update_x)
{
  D omega_S=std::min(inst.omega, inst.tau);
  h_Li[idx]*=2.;  //This is the inverse Lipschitz constant estimate
  L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  std::vector<D> gplus(nbcoord);
  std::vector<D> grad(nbcoord);
  D test;
  do {
    h_Li[idx]/=2.;
    Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update_x);
    //cout << "inside: "<<update_x[0]<< endl;
    Losses<L, D, traits>::compute_grad_xph(inst, residuals, idx, omega_S, h_Li, update_x, grad, gplus);
    test=0;
    for (int i=0; i<nbcoord; i++)
      test+=(grad[i]-gplus[i])*(grad[i]-gplus[i])/2.*h_Li[idx] - update_x[i]*update_x[i]/h_Li[idx]/2.;

//cout << "update="<< update_x[0] << endl;
 //      cout << "i=" << idx <<", L="<<1/h_Li[idx] << ", grad="<< grad[0]<< ", gplus="<< gplus[0]<<", test=" << test << endl;
  //     sleep(1);

  }
  while ( test > epsilon/inst.n/2. );

}

template<typename L, typename D, typename traits> 
void dsoLineSearchAccel(const problem_data<L, D> &inst,
		   const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
		   std::vector<D> &h_Lintau, D epsilon, D theta, std::vector<D> &update_z)
{
  D omega_S=std::min(inst.omega, inst.tau);
  h_Lintau[idx]*=2.;  //This is the inverse Lipschitz constant estimate
  L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  std::vector<D> gplus(nbcoord);
  std::vector<D> grad(nbcoord);
  D test;
  D novertau=(inst.n/(D)inst.tau);
  do {
    h_Lintau[idx]/=2.;
    Losses<L, D, traits>::compute_update_accel(inst, theta, residuals_w, residuals_z, idx, h_Lintau, update_z);
    Losses<L, D, traits>::compute_grad_xph_accel(inst, theta, residuals_w,residuals_z, idx, omega_S, h_Lintau, update_z, grad, gplus);
    test=0;
    for (int i=0; i<nbcoord; i++)
      test+=(grad[i]-gplus[i])*(grad[i]-gplus[i])/2.*h_Lintau[idx]*novertau - novertau*theta*update_z[i]*novertau*theta*update_z[i]/h_Lintau[idx]/novertau/2.;

//cout << "theta=" << theta << ", update="<< update_z[0] << endl;
 //      cout << "L["<<idx <<"]="<<1/h_Lintau[idx]*novertau << ", grad="<< grad[0]<< ", gplus="<< gplus[0]<<", test=" << test << endl;
 //      sleep(1);

  }
  while ( test > novertau*theta*epsilon/inst.n/2. );

}*/





template<typename L, typename D, typename traits> 
void EsoLineSearch(problem_data<L, D> &inst,
		   std::vector<D> &residuals, const L idx,
		   std::vector<D> &h_Li, const D epsilon, const std::vector<D> Q, std::vector<D> &update_x)
{

  L omega_S=std::min(inst.omega, inst.tau);
  L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  std::vector<D> gplus(nbcoord);
  std::vector<D> grad(nbcoord);
  std::vector<D> tmp(nbcoord);

  D delta;
//  L fixed_delta=1;

//  parallel::atomic_add(h_Li[inst.n], -1./h_Li[idx]/2.);
  h_Li[idx]*=2.;


  D test;
  do {
//    parallel::atomic_add(h_Li[inst.n], 1./h_Li[idx]);
    h_Li[idx]/=2.;  //This is the inverse Lipschitz constant estimate

    Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update_x, grad);
    for (L i=0; i<nbcoord; i++)
      gplus[i]=0;
    for (L s=0; s<= floor(log2(omega_S))+1; s++)  {
      if (Q[s]>1e-15)  {  //To win a little of speed
	L maxint=std::min(omega_S,(((L)1)<<(s+1))-1);
      	Losses<L, D, traits>::compute_grad_xph(inst, residuals, idx, maxint, h_Li, update_x, tmp);
      	for (L i=0; i<nbcoord; i++)
	  gplus[i]+=Q[s]*tmp[i];
      }
    }

    test=0.;
    int nesterovlinesearch=1;
    if ((nesterovlinesearch==1) && (epsilon==0)  && (inst.lambda==0.))
      for (L i=0; i<nbcoord; i++)
	test = -grad[i]*gplus[i];
    else
      for (L i=0; i<nbcoord; i++)
        test+=(grad[i]-gplus[i])*(grad[i]-gplus[i])*h_Li[idx]/2.*2. - update_x[i]*update_x[i]/h_Li[idx]/2./2.;


//  if (fixed_delta==1)
	delta = epsilon/2./inst.n;
//  else
//	delta = 1./h_Li[idx]/h_Li[inst.n]*epsilon/2.;  // h_Lintau[inst.n] is the sum of the indices.

//#pragma omp critical
//cout <<idx << "  "<< delta << " " << h_Li[inst.n] << " " << h_Li[idx] << endl;



/*#pragma omp master
if ((inst.x[idx]>1000)||(idx==62317)) {
      cout << "omega_S=" << omega_S<< ", update="<< update_x[0]<< ", L["<< idx << "]="<<1/h_Li[idx] << ", grad="<< grad[0]<< ", gplus="<< gplus[0]<< ", x=" << inst.x[idx] <<", test=" << test << endl;
      sleep(1);
}*/
  }
  while ((test!=test) || (test > delta));

/*#pragma omp master
if (h_Li[idx]<1e-8){
Losses<L, D, traits>::recompute_residuals(inst, residuals);
D fval = Losses<L, D, traits>::compute_fast_objective(inst, residuals);  
inst.normalization_factor=1;
D gradnorm=0;
vector<D> grad1(1);
vector<D> update1(1);
for (L i=0; i<inst.n; i++){
        Losses<L, D, traits>::compute_update(inst, residuals, i, h_Li, update1, grad1);
	gradnorm+=grad1[0]*grad1[0];
}

#pragma omp critical
  cout << "EsoLineSearch, attention! grad["<< idx<< "]=" << grad[0] << " "<< gplus[0]<<" "<<gradnorm<<", fval="<<fval<<", Li=" << h_Li[idx]<< endl;

sleep(1);
}*/


}


template<typename L, typename D, typename traits> 
void EsoLineSearchAccel(problem_data<L, D> &inst,
		   const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
		   std::vector<D> &h_Lintau, D epsilon, const std::vector<D> Q, D theta, std::vector<D> &update_z)
{


  L omega_S=std::min(inst.omega, inst.tau);
  L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  std::vector<D> gplus(nbcoord);
  std::vector<D> grad(nbcoord);
  std::vector<D> tmp(nbcoord);

  D delta;
//  L fixed_delta=1;



//  parallel::atomic_add(h_Lintau[inst.n], -1./h_Lintau[idx]/2.);
  h_Lintau[idx]*=2.;  //This is the inverse Lipschitz constant estimate

  D test;
  D novertau=(inst.n/(D)inst.tau);
  do {

//    parallel::atomic_add(h_Lintau[inst.n], 1./h_Lintau[idx]);
    h_Lintau[idx]/=2.;
    Losses<L, D, traits>::compute_update_accel(inst, theta, theta*theta, residuals_w, residuals_z, idx, h_Lintau, update_z, grad);
    for (L i=0; i<nbcoord; i++)
      gplus[i]=0;
    for (L s=0; s<= floor(log2(omega_S))+1; s++)  {
      if (Q[s]>1e-15)  {
	L maxint=std::min(omega_S,(((L)1)<<(s+1))-1);
	Losses<L, D, traits>::compute_grad_xph_accel(inst, theta, residuals_w,residuals_z, idx, maxint, h_Lintau, update_z, tmp);

      	for (L i=0; i<nbcoord; i++)
	  gplus[i]+=Q[s]*tmp[i];
      }
    }
    test=0;
    int nesterovlinesearch=1; 
    if ((nesterovlinesearch==1) && (epsilon==0) && (inst.lambda==0.))
      for (L i=0; i<nbcoord; i++)
	test = grad[0]*gplus[0];
    else
      for (L i=0; i<nbcoord; i++)
        test+=(grad[i]-gplus[i])*(grad[i]-gplus[i])/2.*h_Lintau[idx]*novertau*2. - novertau*theta*update_z[i]*novertau*theta*update_z[i]/h_Lintau[idx]/novertau/2./2.;


//  if (fixed_delta==1)
	delta = epsilon/inst.n/2.;
//  else
//	delta = 1./h_Lintau[idx]/h_Lintau[inst.n]*epsilon/2.;  // h_Lintau[inst.n] is the sum of the indices.



//cout << "theta=" << theta << ", update="<< update_z[0] << endl;
/*if (idx==62317){
 #pragma omp critical
      cout << "L["<<idx <<"]="<<1/h_Lintau[idx]/novertau << ", grad="<< grad[0]<< ", gplus="<< gplus[0]<<", test=" << test << endl;
       sleep(1);
}*/

  }
  while ((test!=test) || (test > novertau*theta*delta));

}



template<typename L, typename D> 
vector<D> compute_Q_probabilities(L omega, L tau, L n)
{
  L theta=std::min(omega, tau);

  D* num=new D[tau];
  L* den=new L[tau];
  
  vector<D> pi;
  pi.resize(theta+1);

  vector<D> Q;
  Q.resize(floor(log2(theta))+1,0.);


  for (L k=theta; k>=0; k--)
    {
      for (L i=0; i<tau-k; i++)
	{
	  num[i]=n-omega-i;
	}
      for (L i=tau-k; i<tau; i++)
	{  
	  D I=i-tau+k; //to avoid Euclidean division.
	  num[i]=(tau-I)*(omega-I)/(k-I);
	}
      for (L i=0; i<tau; i++)
	{
	  den[i]=n-i;
	  num[i]=num[i]/den[i];
	}

      // Permute the elements for better numerical stability
      D tmp; 
      L randomindex;
      for (L i=0; i<tau; i++)
	{
	  randomindex = rand() % tau;
	  tmp=num[i]; num[i]=num[randomindex]; num[randomindex]=tmp;
	}
       
      pi[k]=1;
      for (L i=0; i<tau; i++)
	pi[k]*=num[i];

    }

  for (L s=0; s<= floor(log2(theta)); s++)
    {
      L maxint=std::min(theta,((L)1<<(s+1))-1);
      cout << (1<<s) <<" " << maxint<<endl;
      for (L k=(1<<s); k<= maxint; k++)
	Q[s]+= k*pi[k]/(D)omega*n/(D)tau;
    }


  for (L k=0; k<= theta; k++)
    cout << "pi["<< k << "]="<<pi[k] << endl;

  for (L s=0; s<= floor(log2(theta)); s++)
    cout << "Q["<< s << "]="<<Q[s] << endl;

  return Q;
}




template<typename L, typename D, typename traits> 
void univgradLineSearch(problem_data<L, D> &inst,
		   std::vector<D> &residuals, const L idx,
		   std::vector<D> &h_Li, const D epsilon, const std::vector<D> Q, std::vector<D> &update_x)
{

  h_Li[idx]*=4.;
  L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  std::vector<D> grad(nbcoord);
  std::vector<D> tmp(nbcoord);

  D fval_x = Losses<L, D, traits>::compute_fast_objective(inst, residuals);

  for (int i=0; i<inst.N; i++)
      update_x[i]=0.;

  D test;
  do {
    h_Li[idx]/=2.;  //This is the inverse Lipschitz constant estimate

  // We cancel previous update.
    for (int i=0; i<inst.N; i++)
      update_x[i]=-update_x[i];
    Losses<L, D, traits>::do_single_update_parallel( inst, idx, residuals, inst.x, h_Li, update_x);    

    Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update_x, grad);

    //We compute the function value at the tentative point
    Losses<L, D, traits>::do_single_update_parallel( inst, idx, residuals, inst.x, h_Li, update_x);
    D fval_tmp = Losses<L, D, traits>::compute_fast_objective(inst, residuals);    
    
    test = fval_x - fval_tmp;
    for (int i=0; i<inst.N; i++)
	 test+=grad[i]*update_x[i] + 1./h_Li[idx]/2*update_x[i]*update_x[i];
    test+=inst.epsilon/2;

 //  cout << "test=" << test << " " << fval_x << " " << fval_tmp<<endl;
  }
  while ((test!=test) || (test < 0));


//cout << endl;
/*#pragma omp master
if (h_Li[idx]<1e-8){
Losses<L, D, traits>::recompute_residuals(inst, residuals);
D fval = Losses<L, D, traits>::compute_fast_objective(inst, residuals);  
inst.normalization_factor=1;
D gradnorm=0;
vector<D> grad1(1);
vector<D> update1(1);
for (L i=0; i<inst.n; i++){
        Losses<L, D, traits>::compute_update(inst, residuals, i, h_Li, update1, grad1);
	gradnorm+=grad1[0]*grad1[0];
}

#pragma omp critical
  cout << "EsoLineSearch, attention! grad["<< idx<< "]=" << grad[0] << " "<< gplus[0]<<" "<<gradnorm<<", fval="<<fval<<", Li=" << h_Li[idx]<< endl;

sleep(1);
}*/


}


#endif //LINESEARCHES_H
