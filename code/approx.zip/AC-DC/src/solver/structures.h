/*
 * This file contains an functions for experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */

/*
 * Optimization and output structures,
 *
 * optimization_setting structure is used to configure solvers, how much can solver run,
 */

#ifndef OPTIMIZATION_STRUCTURES_H_
#define OPTIMIZATION_STRUCTURES_H_

#include <ios>
#include <cstdlib>
#include <unistd.h>

#include "sys/types.h"
#include "sys/sysinfo.h"

#include <algorithm>
#include <iterator>
#include <iostream>
#include <fstream>
#include <string>

template<typename L, typename D>
class problem_data {
public:
	std::vector<D> A_csc_values;
	std::vector<L> A_csc_row_idx;
	std::vector<L> A_csc_col_ptr;

	std::vector<D> A_csr_values;
	std::vector<L> A_csr_col_idx;
	std::vector<L> A_csr_row_ptr;

	std::vector<D> b;
#ifdef NEWATOMICS
	std::vector< atomic_float<D, L> > x;
#else
	std::vector<D> x;
#endif

	L m;
	L n;
	L N;
	L total_n;
	D lambda;
	std::vector<D> lowerbound;
	std::vector<D> upperbound;
	L omega;
	L tau;
	D sigma;


//Added by O. Fercoq for smoothing

	D mu;
	D epsilon;
	std::vector<D> rownorms;
//for inf-norm
	D normalization_factor; 

//Added by O. Fercoq for accelerated gradient

	std::vector<D> update;
	std::vector<D> z;		
        std::vector<D> update_w;
	std::vector<D> w;	

	std::vector<D> b0;
	D lambda_svm;
	std::vector<D> c; // linear part of the objective
	D lipschitz;

	D mupsi;
	D muf;
	D lambda2; // for L2 regularizer
	D lambda2f; // for L2 regularizer in f

//Added by O. Fercoq for denoising
	std::vector<L> blocks_ptr;
	D radius;
	L dimball;
	D alpha;
	D beta;

};

template<typename L, typename D>
class problem_mc_data {
public:
	std::vector<D> A_coo_values;
	std::vector<L> A_coo_row_idx;
	std::vector<L> A_coo_col_idx;
	std::vector<short int> A_coo_operator; // 0 is equality  -1 or +1 is inequality constraint
	D mu;
	L m;
	L n;
	L rank;

	std::vector<D> R_mat;
	std::vector<D> L_mat;
};


#endif /* OPTIMIZATION_STRUCTURES_H_ */

