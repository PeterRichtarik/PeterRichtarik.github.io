/*
 * This file contains an functions for experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */



/*
 * Set of functions and structures
 */

#ifndef SOFT_TRESHHOLD_H_
#define SOFT_TRESHHOLD_H_

#include <limits>

/*
 *       Softtresholding formula
 *        sgn(X) (|X|-T)_+
 *           X-T  X>T
 *           X+T  X<-T
 *            0    otherwise
 */
template<typename T>
T compute_soft_treshold(T valT, T valX) {
	T absXminusT = abs(valX) - valT;
	if (absXminusT < 0)
		absXminusT = 0;
	return sgn(valX) * absXminusT;
}

template<typename L, typename D>
void projL2ball(std::vector<D> &x, L nbcoord, L dim, D radius) {
	
	if (radius < numeric_limits<D>::max())
	{
		if (nbcoord%dim>0)
			cout << "projL2ball-attention: ball dimension is ill set" << endl; 
#pragma omp parallel for if (nbcoord>=12*dim)
		for (L i=0; i<nbcoord; i+=dim)
		{
			D norm=0;
			for (L k=i; k<i+dim; k++)
				norm+=x[k]*x[k];
			norm=sqrt(norm);
			if (norm>radius) {
				D factor=radius/norm;
				for (L k=i; k<i+dim; k++)
					x[k]*=factor;
			}
		}
	}
}


#endif /* SOFT_TRESHHOLD_H_ */
