/*
 * This file contains a function for experiment done in paper
 * O. Fercoq and P. Richtárik
 *      Smoothed Parallel Coordinate Descent Method for Huge-Scale Optimization Problems 
 */


/*
 *  Created on: 20 May 2013
 *      Author: Olivier Fercoq
 */

#ifndef INFNORM_LOSS_H
#define INFNORM_LOSS_H


template<typename L, typename D>
D esofactor(L omega, L tau, L m, L n)
{
  L theta=std::min(omega, tau);
  D beta=0;

  D* num=new D[tau];
  L* den=new L[tau];
  
  D p;
  D Sp=0;
  D Spc=0;
  D Spl=0;

  for (L k=theta; k>=1; k--)
    {
      for (L i=0; i<tau-k; i++)
	{
	  num[i]=n-omega-i;
	}
      for (L i=tau-k; i<tau; i++)
	{  
	  D I=i-tau+k; //to avoid Euclidean division.
	  num[i]=(tau-I)*(omega-I)/(k-I);
	}
      for (L i=0; i<tau; i++)
	{
	  den[i]=n-i;
	  num[i]=num[i]/den[i];
	}

      // Permute the elements for better numerical stability
      D tmp; 
      L randomindex;
      for (L i=0; i<tau; i++)
	{
	  randomindex = rand() % tau;
	  tmp=num[i]; num[i]=num[randomindex]; num[randomindex]=tmp;
	}
       
      p=1;
      for (L i=0; i<tau; i++)
	p*=num[i];

      Sp+=p;
      D c=std::max(k/(D)omega, (tau-k)/max(1e-10,(D) n-omega));
      Spc+=p*c;
      Spl+=p*k;
//cout << "c["<< k << "]=" << c<< endl;

      //beta+=std::min(1., m*Sp);
      //beta+=std::min(1., m*n/(D)tau/std::max((D) n-omega,1e-10)*(tau*Sp-Spl)+n*m*Spl/(tau*omega) );
      beta+=std::min(1., m*n/(D)tau * Spc);

    }

  return beta;
}


struct infnorm_loss_traits: public loss_traits {
};

/*******************************************************************/
// a partial specialisation for inf norm loss
template<typename L, typename D>
class Losses<L, D, infnorm_loss_traits> {

public:

	static inline void set_residuals_for_zero_x(problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = -inst.b[i];
		}

		// Compute the value of the function safely.
		D v = *std::max_element(residuals.begin(), residuals.end());

		D tmp=0;
		for (L i = 0; i < inst.m; i++) {
			tmp += exp((residuals[i]-v)/inst.mu);
		}

		inst.normalization_factor = v + inst.mu*log(1+tmp);

		// Set the reduction entries to 0.
		inst.reduction_counter=0;
		for (int proc = 0; proc<inst.tau; proc++)
			inst.reduction_vector[proc]=0;

	}

	static inline void recompute_residuals(problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		recompute_residuals(inst, residuals, inst.x, inst.b);
	}

	static inline void recompute_residuals(problem_data<L, D> &inst,
			std::vector<D> &residuals, std::vector<D> &x, std::vector<D> &b) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = -b[i];
		}
		for (L i = 0; i < inst.n; i++) {
			for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1];
					j++) {
				residuals[inst.A_csc_row_idx[j]] += inst.A_csc_values[j]
						* x[i];
			}
		}	
		// Compute the value of the function safely.
		D v = *std::max_element(residuals.begin(), residuals.end());

		D tmp=0;
		for (L i = 0; i < inst.m; i++) {
			tmp += exp((residuals[i]-v)/inst.mu);
		}

		inst.normalization_factor = v + inst.mu*log(1+tmp);


//cout << "m="<<inst.m << ", normaliz="<<inst.normalization_factor << "=" << v << "+" << inst.mu << "*" << "log(1+" << tmp << ")\n";
	}



	static inline void recompute_residuals_for_my_instance_data(
			const problem_data<L, D> &inst, std::vector<D> &residuals) {
		for (L row = 0; row < inst.m; row++) {
			residuals[row] = -inst.b[row];
			for (L col_tmp = inst.A_csr_row_ptr[row];
					col_tmp < inst.A_csr_row_ptr[row + 1]; col_tmp++) {
				residuals[row] += inst.A_csr_values[col_tmp]
						* inst.x[inst.A_csr_col_idx[col_tmp]];
			}
		}
	}

	static inline D do_single_iteration_serial(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, const D grad=0) {
		vector<D> update(1);
		compute_update(inst, residuals, idx, Li, update);
		D tmp=update[0];
		x[idx] += tmp;
		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			D oldres=residuals[inst.A_csc_row_idx[j]];
			residuals[inst.A_csc_row_idx[j]] += tmp * inst.A_csc_values[j];
			D newres=residuals[inst.A_csc_row_idx[j]];
		        inst.normalization_factor = inst.normalization_factor + inst.mu*log( 1 + exp((newres-inst.normalization_factor)/inst.mu) - exp((oldres-inst.normalization_factor)/inst.mu) );
		}
		return abs(tmp);
	}

	static inline void do_single_iteration_parallel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li) {
	    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	    std::vector<D> update(nbcoord);
    	    compute_update(inst, residuals, idx, Li, update);
   	    do_single_update_parallel(inst, idx, residuals, x,Li, update);
	}

	/*static inline D do_single_iteration_parallel_for_distributed(
			problem_data<L, D> &inst, const L idx,
			std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, D* residual_updates) {
		D tmp;
		tmp = compute_update(inst, residuals, idx, Li);
		parallel::atomic_add(x[idx], tmp);
		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			parallel::atomic_add(residual_updates[inst.A_csc_row_idx[j]],
					tmp * inst.A_csc_values[j]);
		}
		return abs(tmp);
	}*/

	static inline void do_single_update_parallel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, const std::vector<D> &update) {

		D tmp=update[0];
		parallel::atomic_add(x[idx], tmp);

		D reduction=0;
		D normalization=inst.normalization_factor; //Avoids looking at variables stored in other caches.
		D mumu=inst.mu;

		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			// Update of the residuals
			D Akh = tmp * inst.A_csc_values[j];
			D newres;
			newres=parallel::atomic_add(residuals[inst.A_csc_row_idx[j]], Akh);
			D oldres = newres-Akh;  

			// Reduction for the update of the normalization factor
		 	//inst.reduction_vector[proc] += exp((newres-inst.normalization_factor)/inst.mu) - exp((oldres-inst.normalization_factor)/inst.mu) ;
			reduction+=exp((newres-normalization)/mumu) - exp((oldres-normalization)/mumu);//exp((newres-normalization)/mumu)*(1 - exp((oldres-newres)/mumu)); //
			//parallel::atomic_add( inst.reduction_vector[proc], exp((newres-inst.normalization_factor)/inst.mu) - exp((oldres-inst.normalization_factor)/inst.mu) ) ;
		}

		D updatetonormaliz = mumu*log(1+reduction);
		parallel::atomic_add(inst.normalization_factor, updatetonormaliz);

	}


	static inline void do_single_update_parallel_accel(problem_data<L, D> &inst,
						     const L idx, std::vector<D> &residuals_w, std::vector<D> &residuals_z, const std::vector<D> &Li, std::vector<D> & update_w, std::vector<D> & update_z) {

		cout << "Attention, infnorm: accelerated coordinate descent not implemented.\n";
	}

   static inline void compute_update(problem_data<L, D> &inst, std::vector<D> &residuals, const L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}

 static inline void compute_update(const problem_data<L, D> &inst, const std::vector<D> &residuals, const L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}

	static inline void compute_update(const problem_data<L, D> &inst,
			const std::vector<D> &residuals, const L idx,
			const std::vector<D> &Li, std::vector<D> &update_x, std::vector<D> &grad) {

		L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
		if (nbcoord>1)
			cout << "Attention, infnorm: block coordinate descent not implemented\n";
		
		D tmp = 0; //compute partial derivative f_idx'(x)

		D normalization=inst.normalization_factor;  //Avoids looking at variables stored in other caches.
		D mumu=inst.mu;

		for (L k = inst.A_csc_col_ptr[idx];
				k < inst.A_csc_col_ptr[idx + 1]; k++) {
		  L j = inst.A_csc_row_idx[k];
		  D resmod=exp((residuals[j]-normalization)/mumu);
   		  tmp += inst.A_csc_values[k] * resmod;

		}
	        tmp += inst.c[idx];

	        if ((L)grad.size()>=nbcoord)
		    grad[0]=tmp;

		//D tmp2=tmp;
		update_x[0]= compute_soft_treshold(Li[idx] * inst.lambda,
				inst.x[idx] - Li[idx] * tmp) - inst.x[idx];
//cout << inst.normalization_factor << " " << tmp << " " << tmp2 << " "<< Li[idx]*tmp2 <<" " << Li[idx] << endl;
	}

  static inline void compute_grad_xph(const problem_data<L, D> &inst,
					const std::vector<D> &originalresiduals, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_x, std::vector<D> &gradient_xph) {
	
    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    D reduction=0;
    D normalization=inst.normalization_factor;  //Avoids looking at variables stored in other caches.
    D mumu=inst.mu;

if (nbcoord>1)
  cout << "loss inf norm: compute grad xph, attention: not coded for blocksize>1\n";
    for (L k=0; k<nbcoord; k++)
      {	
	L coordinate=inst.blocks_ptr[idx]+k;

	gradient_xph[k] = 0; //compute partial derivative f_idx'(x+h e_idx)
	for (L j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++)  {

	  D res_xph=originalresiduals[inst.A_csc_row_idx[j]]+omega_S*update_x[k]*inst.A_csc_values[j];
	  D resmod_xph_wrongnormalization = exp((res_xph-normalization)/mumu);
	  gradient_xph[k] += inst.A_csc_values[j] * resmod_xph_wrongnormalization;

	  reduction+=exp((res_xph-normalization)/mumu) - exp((originalresiduals[inst.A_csc_row_idx[j]]-normalization)/mumu);
	}
      }

//    D normalization_xph = normalization + mumu*log(1+reduction);

//cout <<"grad=" << gradient_xph[0] << ", reduction=" << reduction<<endl;
//sleep(1);

    for (L k=0; k<nbcoord; k++)
      {	
	L coordinate=inst.blocks_ptr[idx]+k;
	gradient_xph[k]/=max(1e-20,1+reduction); // = exp((-normalization_xph+normalization)/mumu); // reduction is not precise with large steps and may be smaller that -1 although it should not be.
	gradient_xph[k]+=inst.c[coordinate];
      }

  }

  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z) {

   std::vector<D> nogradreturned(0);
   compute_update_accel(inst, theta, theta*theta, residuals_w, residuals_z, idx, Lintau, update_z, nogradreturned);

}

	static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta, const D theta2,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z, std::vector<D> &grad) {

		cout << "Attention, infnorm: accelerated coordinate descent not implemented.\n";
	}


	static inline void compute_grad_xph_accel(const problem_data<L, D> &inst, const D theta,
					const std::vector<D> &originalresiduals_w, const std::vector<D> &originalresiduals_z, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_z, std::vector<D> &gradient_xph) {	

		cout << "Attention, infnorm: accelerated coordinate descent not implemented.\n";
	}

	static inline D compute_fast_objective(const problem_data<L, D> &inst,
			const std::vector<D> &residuals) {
		D logsumexp=inst.normalization_factor+inst.mu*log(1./inst.m);
		D sumx=0;
		if (inst.lambda!=0)
			for (L i = 0; i < inst.n; i++) {
				sumx += abs(inst.x[i]);
			}
		return logsumexp + inst.lambda * sumx;
	}

	static inline void compute_reciprocal_lipschitz_constants(
			problem_data<L, D> &inst, std::vector<D> &h_Li) {

	  inst.epsilon=0.01;
	  inst.mu=inst.epsilon/log(inst.m)/2;

	  D colnorms;

	  //Here, the dual norm is a weighted 1-norm, so we do need to change beta(=sigma)
	  inst.sigma=esofactor<L,D>(inst.omega,inst.tau,inst.m,inst.n);

	  for (L i=0; i<inst.n; i++)
	    {   
	      colnorms=0;
      		for (L k=inst.A_csc_col_ptr[i]; k<inst.A_csc_col_ptr[i+1]; k++)
			colnorms=std::max(colnorms, abs(inst.A_csc_values[k]));
	       h_Li[i]=std::max(1e-5,colnorms*colnorms/inst.mu);
	   
	       h_Li[i]/=4;  //Lipschitz constant instead of norm of column

 	       if (h_Li[i] > 0)
	          h_Li[i] = 1. / (inst.sigma * h_Li[i]); // Compute reciprocal Lipschitz Constants
	       else
	          h_Li[i] = 1e10;
    	    }  

	  cout << "epsilon=" << inst.epsilon << ", mu=" << inst.mu<< ", (dual 1-norm) beta=" << inst.sigma << endl;

	  }


	
};

#endif /* INFNORM_LOSS_H */
