/*
 * Loss TGV2: 0.5*norm(f-u)_2^2 + alpha norm(grad u - w)_{1,2} + beta norm(E w)_{F,1}
 * We then smooth it.
 */


/*
 *  Created on: 27 Feb 2014
 *      Author: O. Fercoq
 */

#ifndef TGV2_LOSS_H
#define TGV2_LOSS_H

#include "loss_abstract.h"
#include "loss_onenorm.h"


struct tgv2_loss_traits: public loss_traits {
};

/*******************************************************************/
// a partial specialisation for smoothed tgv2 loss
// The variable x is of size N = (1+2)*width*height
// The matrix A has 21 blocks corresponding to u, w1 and w2 vs the three compoment of the objective:
// A = [ -I, 0; grad, -I; 0, E]
// b(0:N/3-1) is equal to f, b(N/3:N-1)=0
template<typename L, typename D>
  class Losses<L, D, tgv2_loss_traits> {

 public:

  static inline void set_residuals_for_zero_x(const problem_data<L, D> &inst,
					      std::vector<D> &residuals) {
    for (L i = 0; i < inst.m; i++) {
      residuals[i] = -inst.b[i];
    }
  }


  static inline void recompute_residuals(const problem_data<L, D> &inst,
					 std::vector<D> &residuals, const std::vector<D> &x, const std::vector<D> &b) {
#pragma omp parallel for
    for (L i = 0; i < inst.m; i++) {
      residuals[i] = -b[i];
    }
#pragma omp parallel for 
    for (L i = 0; i < inst.N; i++) {
      for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1];
	   j++) {
	parallel::atomic_add(residuals[inst.A_csc_row_idx[j]], inst.A_csc_values[j]*x[i]);
      }
    }
  }


  static inline void recompute_residuals(const problem_data<L, D> &inst,
			std::vector<D> &residuals) {
	recompute_residuals(inst, residuals, inst.x, inst.b);	
  }


  static inline void recompute_residuals_for_my_instance_data(
							      const problem_data<L, D> &inst, std::vector<D> &residuals) {
    for (L row = 0; row < inst.m; row++) {
      residuals[row] = -inst.b[row];
      for (L col_tmp = inst.A_csr_row_ptr[row];
	   col_tmp < inst.A_csr_row_ptr[row + 1]; col_tmp++) {
	residuals[row] += inst.A_csr_values[col_tmp] * inst.x[inst.A_csr_col_idx[col_tmp]];
      }
    }
  }

  static inline void do_single_iteration_serial(problem_data<L, D> &inst,
						const L idx, std::vector<D> &residuals, std::vector<D> &x,
						const std::vector<D> &Li) {
    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    std::vector<D> update(nbcoord);	
    compute_update(inst, residuals, idx, Li, update);		
    for (L k=0; k<nbcoord; k++)
      {
	L coordinate=inst.blocks_ptr[idx]+k;	
	x[coordinate] += update[k];
	for (unsigned int j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  residuals[inst.A_csc_row_idx[j]] += update[k] * inst.A_csc_values[j];
	}
      }
  }

  static inline void do_single_iteration_parallel(problem_data<L, D> &inst,
						  const L idx, std::vector<D> &residuals, std::vector<D> &x,
						  const std::vector<D> &Li) {

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    std::vector<D> update(nbcoord);
    compute_update(inst, residuals, idx, Li, update);
    do_single_update_parallel(inst, idx, residuals, x,Li, update);

  }

  static inline D do_single_iteration_parallel_for_distributed(problem_data<L, D> &inst, const L idx,
							       std::vector<D> &residuals, std::vector<D> &x,
							       const std::vector<D> &Li, D* residual_updates) {
    D tmp = 0;
    tmp = compute_update(inst, residuals, idx, Li);
    parallel::atomic_add(x[idx], tmp);
    for (unsigned int j = inst.A_csc_col_ptr[idx];
	 j < inst.A_csc_col_ptr[idx + 1]; j++) {
      parallel::atomic_add(residual_updates[inst.A_csc_row_idx[j]],
			   tmp * inst.A_csc_values[j]);
    }
    return abs(tmp);
  }

  static inline void do_single_update_parallel(const problem_data<L, D> &inst,
					       const L idx, std::vector<D> &residuals, std::vector<D> &x,
					       const std::vector<D> &Li, const std::vector<D> & update) {

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#pragma omp parallel for if (nbcoord>=inst.tau) 
    for (L i=0; i<nbcoord; i++)
      {
	L coordinate=inst.blocks_ptr[idx]+i;			
	parallel::atomic_add(x[coordinate], update[i]);
	for (L k = inst.A_csc_col_ptr[coordinate];
	     k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
	  parallel::atomic_add(residuals[inst.A_csc_row_idx[k]], update[i] * inst.A_csc_values[k]);

	}
      }
  }


  static inline void do_single_update_parallel_accel(problem_data<L, D> &inst,
						     const L idx, std::vector<D> &residuals_w, std::vector<D> &residuals_z, const std::vector<D> &Li, std::vector<D> & update_w, std::vector<D> & update_z) {
    // The accelerated coordinate descent method is rather unstable so it is important to update w and z together for y to be the least affected by the asynchronous implementation.

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#pragma omp parallel for if (nbcoord>=inst.tau) 
    for (L i=0; i<nbcoord; i++)
      {
	L coordinate=inst.blocks_ptr[idx]+i;	
	parallel::atomic_add(inst.w[coordinate], update_w[i]);
	parallel::atomic_add(inst.z[coordinate], update_z[i]);
	for (L k = inst.A_csc_col_ptr[coordinate];
	     k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
	  L j = inst.A_csc_row_idx[k];
	  D Aji=inst.A_csc_values[k];
	  parallel::atomic_add(residuals_w[j], update_w[i] * Aji);
	  parallel::atomic_add(residuals_z[j], update_z[i] * Aji);
	}

      }

  }

  static inline D square(D x) { return x*x; }

  static inline void compute_update(problem_data<L, D> &inst, std::vector<D> &residuals, const L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}



  static inline void compute_update(problem_data<L, D> &inst,
				    std::vector<D> &residuals, const L idx,
				    const std::vector<D> &Li, std::vector<D> &update_x, std::vector<D> &grad) {

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#pragma omp parallel for if (nbcoord>=inst.tau) 
    for (L i=0; i<nbcoord; i++)
      {			
	L coordinate=inst.blocks_ptr[idx]+i;
	update_x[i] = 0; //compute partial derivative f_idx'(x)

	for (L k = inst.A_csc_col_ptr[coordinate];
	     k < inst.A_csc_col_ptr[coordinate + 1]; k++)  {
	    L j = inst.A_csc_row_idx[k];
	    D resmod;
	    L pixel=j/7;
	    if (j % 7 == 0)
		resmod = residuals[j];
	    else if ((j % 7 == 1)||(j % 7 == 2))  {
		D diffu = sqrt(square(residuals[7*pixel+1])+square(residuals[7*pixel+2]));
		resmod = inst.alpha*inst.alpha*residuals[j]/std::max(inst.mu*inst.rownorms[0], inst.alpha*diffu);
	    }
	    else {  // j % 7 >= 3
		D diffw = sqrt(square(residuals[7*pixel+3])
			+2*square(0.5*(residuals[7*pixel+4]+residuals[7*pixel+5]))
			+square(residuals[7*pixel+6]));
		if ((j % 7 == 4)||(j % 7 == 5))
			resmod = inst.beta*inst.beta*0.5*(residuals[7*pixel+4]+residuals[7*pixel+5])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
		else
			resmod = inst.beta*inst.beta*residuals[j]/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
	    }
	    update_x[i] += inst.A_csc_values[k] * resmod;	

	}
    
	update_x[i]+=inst.c[coordinate];

        if ((L)grad.size()>=nbcoord)
	    grad[i]=update_x[i];

// test gradient
/*if (idx==3*100){
D step=1e-4;
D fval=compute_fast_objective(inst, residuals);
update_x[0]=step;
do_single_update_parallel( inst, idx, residuals, inst.x, Li, update_x);
D fval2=compute_fast_objective(inst, residuals);
cout << "Gradient: direct calculation=" << grad[0] << ", finite differences=" << (fval2-fval)/step << endl;
sleep(1);
}*/

	//Soft and hard thresholding
	update_x[i] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate], 
				compute_soft_treshold(Li[idx] * inst.lambda, 
					inst.x[coordinate] - Li[idx] * update_x[i] ))) - inst.x[coordinate];	

       }
  }

  	static inline void compute_grad_xph(const problem_data<L, D> &inst,
					const std::vector<D> &originalresiduals, const L idx, D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_x, std::vector<D> &gradient_xph) {	

    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	if (nbcoord>1)
  		cout << "loss_tgv2: compute_grad_xph, attention: not coded for blocksize>1\n";

#pragma omp parallel for if (nbcoord>=inst.tau) 
	for (L i=0; i<nbcoord; i++)
          {			
	    L coordinate=inst.blocks_ptr[idx]+i;
	    gradient_xph[i] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x
	    // grad[i] = 0;   //compute partial derivative f_idx'(x)
	    for (L k = inst.A_csc_col_ptr[coordinate];
			k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
		L j = inst.A_csc_row_idx[k];
		D Aji = inst.A_csc_values[k];
	    	L pixel=j/7;

		D resmod_xph; 
	    	if (j % 7 == 0)
		    resmod_xph = originalresiduals[j]+omega_S*update_x[i]*Aji;
	        else if ((j % 7 == 1)||(j % 7 == 2))  {
		    vector<D> newresids(2);
		    for (L jj=0; jj<2; jj++) {
			newresids[jj]=originalresiduals[7*pixel+1+jj];
		    }
		    for (L kk = inst.A_csc_col_ptr[coordinate];
			kk < inst.A_csc_col_ptr[coordinate + 1]; kk++) {
			L jtmp = inst.A_csc_row_idx[kk];
			if ((jtmp/7==pixel) && (jtmp % 7 >=1) && (jtmp <=2))
			    newresids[jtmp % 7-1] += omega_S*update_x[i]*inst.A_csc_values[kk];
		    }
/*		    for (L jj=0; jj<2; jj++) {
			if (inst.A_csc_row_idx[k + (1-j%7) + jj]==7*pixel+1+jj)
			    newresids[jj]=originalresiduals[7*pixel+1+jj]+omega_S*update_x[i]*inst.A_csc_values[k+(1-j%7) + jj];
			else
			    newresids[jj]=originalresiduals[7*pixel+1+jj];
		    }*/
		    D diffu = sqrt(square(newresids[0])+square(newresids[1]));
		    resmod_xph = inst.alpha*inst.alpha*newresids[j%7-1]/std::max(inst.mu*inst.rownorms[0], inst.alpha*diffu);
	        }
	        else {  // j % 7 >= 3
		    vector<D> newresids(4);
		    for (L jj=0; jj<4; jj++) {
			newresids[jj]=originalresiduals[7*pixel+3+jj];
		    }
		    for (L kk = inst.A_csc_col_ptr[coordinate];
			kk < inst.A_csc_col_ptr[coordinate + 1]; kk++) {
			L jtmp = inst.A_csc_row_idx[kk];
			if ((jtmp/7==pixel) && (jtmp % 7 >=3))
			    newresids[jtmp % 7-3] += omega_S*update_x[i]*inst.A_csc_values[kk];
		    }
		    D diffw = sqrt(square(newresids[0])+2*square(0.5*(newresids[1]+newresids[2]))
			+square(newresids[3]));
		    if ((j % 7 == 4)||(j % 7 == 5))
			resmod_xph = inst.beta*inst.beta*0.5*(newresids[1]+newresids[2])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
		    else
			resmod_xph = inst.beta*inst.beta*newresids[j%7-3]/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
	        }

		/*D resmod; 
	    	if (j % 7 == 0)
		    resmod = originalresiduals[j];
	        else if ((j % 7 == 1)||(j % 7 == 2))  {
		    D diffu = sqrt(square(originalresiduals[7*pixel+1])+square(originalresiduals[7*pixel+2]));
		    resmod = inst.alpha*originalresiduals[j]/std::max(inst.mu*inst.rownorms[0], inst.alpha*diffu);
	        }
	        else {  // j % 7 >= 3
		    D diffw = sqrt(square(originalresiduals[7*pixel+3])
			+2*square(0.5*(originalresiduals[7*pixel+4]+originalresiduals[7*pixel+5]))
			+square(originalresiduals[7*pixel+6]));
		    if ((j % 7 == 4)||(j % 7 == 5))
			resmod = inst.beta*0.5*(originalresiduals[7*pixel+4]+originalresiduals[7*pixel+5])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
		    else
			resmod = inst.beta*originalresiduals[j]/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
	        }*/

  	        gradient_xph[i] += Aji * resmod_xph;  
		// grad[i] += Aji * resmod;
		}

	  }

	}

  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z) {

   std::vector<D> nogradreturned(0);
   compute_update_accel(inst, theta, residuals_w, residuals_z, idx, Lintau, update_z, nogradreturned);

}


  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z, std::vector<D> &grad) {

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#pragma omp parallel for if (nbcoord>=inst.tau) 
    for (L i=0; i<nbcoord; i++)
      {			
	L coordinate=inst.blocks_ptr[idx]+i;
	update_z[i] = 0; //compute partial derivative f_idx'(theta^2 w + z)
	D theta2=theta*theta;

	for (L k = inst.A_csc_col_ptr[coordinate];
	     k < inst.A_csc_col_ptr[coordinate + 1]; k++)  {
	    L j = inst.A_csc_row_idx[k];
	    D resmod;
	    L pixel=j/7;
	    if (j % 7 == 0)
		resmod = theta2*residuals_w[j]+residuals_z[j];
	    else if ((j % 7 == 1)||(j % 7 == 2))  {
		D diffu = sqrt(square(theta2*residuals_w[7*pixel+1]+residuals_z[7*pixel+1])+square(theta2*residuals_w[7*pixel+2]+residuals_z[7*pixel+2]));
		resmod = inst.alpha*inst.alpha*(theta2*residuals_w[j]+residuals_z[j])/std::max(inst.mu*inst.rownorms[0], inst.alpha*diffu);
	    }
	    else {  // j % 7 >= 3
		D diffw = sqrt(square(theta2*residuals_w[7*pixel+3]+residuals_z[7*pixel+3])
			+2*square(0.5*(theta2*residuals_w[7*pixel+4]+residuals_z[7*pixel+4]+theta2*residuals_w[7*pixel+5]+residuals_z[7*pixel+5]))
			+square(theta2*residuals_w[7*pixel+6]+residuals_z[7*pixel+6]));
		if ((j % 7 == 4)||(j % 7 == 5))
			resmod = inst.beta*inst.beta*0.5*(theta2*residuals_w[7*pixel+4]+residuals_z[7*pixel+4]+theta2*residuals_w[7*pixel+5]+residuals_z[7*pixel+5])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
		else
			resmod = inst.beta*inst.beta*(theta2*residuals_w[j]+residuals_z[j])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
	    }

	    update_z[i] += inst.A_csc_values[k] * resmod;	

	}

	update_z[i]+=inst.c[coordinate];

        if ((L)grad.size()>= nbcoord)
		grad[i]=update_z[i];
	
	//Soft and hard thresholding
	update_z[i] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate], 
				compute_soft_treshold(Lintau[idx] * inst.lambda / theta, 
					inst.z[coordinate] - Lintau[idx] * update_z[i] / theta))) - inst.z[coordinate];

      }

  }


	static inline void compute_grad_xph_accel(const problem_data<L, D> &inst, D theta,
					const std::vector<D> &originalresiduals_w, const std::vector<D> &originalresiduals_z, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_z, std::vector<D> &gradient_xph) {	


    	   L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	   D ck=-(1.-inst.n/(D)inst.tau*theta)/(theta*theta);
#pragma omp parallel for if (nbcoord>=inst.tau) 
	   for (L i=0; i<nbcoord; i++)
             {			
	        L coordinate=inst.blocks_ptr[idx]+i;
		// grad[i] = 0; //compute partial derivative f_idx'(theta^2 w + z)
	    	gradient_xph[i] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x
		D theta2=theta*theta;

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L j = inst.A_csc_row_idx[k];
			D Aji=inst.A_csc_values[k];	
			L pixel=j/7;

		    	/*D resmod;
	    		if (j % 7 == 0)
		    	   resmod = theta2*originalresiduals_w[j]+originalresiduals_z[j];
	        	else if ((j % 7 == 1)||(j % 7 == 2))  {
			   vector<D> newresids(2);
			   for (L jj=0; jj<2; jj++)
			      newresids[jj]=theta2*originalresiduals_w[7*pixel+1+jj]+originalresiduals_z[7*pixel+1+jj];
		    	   D diffu = sqrt(square(newresids[0])+square(newresids[1]));
		    	   resmod = inst.alpha*newresids[j%7-1]/std::max(inst.mu*inst.rownorms[0], inst.alpha*diffu);
	        	}
		        else {  // j % 7 >= 3
			    vector<D> newresids(4);
			    for (L jj=0; jj<4; jj++)
				newresids[jj]=theta2*originalresiduals_w[7*pixel+3+jj]+originalresiduals_z[7*pixel+3+jj];
			    D diffw = sqrt(square(newresids[0])+2*square(0.5*(newresids[1]+newresids[2]))
				+square(newresids[3]));
			    if ((j % 7 == 4)||(j % 7 == 5))
				resmod = inst.beta*0.5*(newresids[1]+newresids[2])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
			    else
				resmod = inst.beta*newresids[j%7-3]/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
	        	}*/

			D resmod_xph;
		    	if (j % 7 == 0)
			    resmod_xph = theta2*(originalresiduals_w[j]+ck*omega_S*update_z[i]*Aji)
					+(originalresiduals_z[j]+omega_S*update_z[i]*Aji);
		        else if ((j % 7 == 1)||(j % 7 == 2))  {
			    vector<D> newresids(2);
			    for (L jj=0; jj<2; jj++) {
				newresids[jj]=theta2*originalresiduals_w[7*pixel+1+jj]+originalresiduals_z[7*pixel+1+jj];
			    }
			    for (L kk = inst.A_csc_col_ptr[coordinate];
				kk < inst.A_csc_col_ptr[coordinate + 1]; kk++) {
				L jtmp = inst.A_csc_row_idx[kk];
				if ((jtmp/7==pixel) && (jtmp % 7 >=1) && (jtmp <=2))
				    newresids[jtmp % 7-1] += theta2*ck*omega_S*update_z[i]*inst.A_csc_values[kk]+omega_S*update_z[i]*inst.A_csc_values[kk];
			    }
			    D diffu = sqrt(square(newresids[0])+square(newresids[1]));
			    resmod_xph = inst.alpha*inst.alpha*newresids[j%7-1]/std::max(inst.mu*inst.rownorms[0], inst.alpha*diffu);
		        }
		        else {  // j % 7 >= 3
			    vector<D> newresids(4);
			    for (L jj=0; jj<4; jj++) {
				newresids[jj]=theta2*originalresiduals_w[7*pixel+3+jj]+originalresiduals_z[7*pixel+3+jj];
			    }
			    for (L kk = inst.A_csc_col_ptr[coordinate];
				kk < inst.A_csc_col_ptr[coordinate + 1]; kk++) {
				L jtmp = inst.A_csc_row_idx[kk];
				if ((jtmp/7==pixel) && (jtmp % 7 >=3))
				    newresids[jtmp % 7-3] += theta2*ck*omega_S*update_z[i]*inst.A_csc_values[kk]+omega_S*update_z[i]*inst.A_csc_values[kk];
			    }
			    D diffw = sqrt(square(newresids[0])+2*square(0.5*(newresids[1]+newresids[2]))
				+square(newresids[3]));
			    if ((j % 7 == 4)||(j % 7 == 5))
				resmod_xph = inst.beta*inst.beta*0.5*(newresids[1]+newresids[2])/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
			    else
				resmod_xph = inst.beta*inst.beta*newresids[j%7-3]/std::max(inst.mu*inst.rownorms[1], inst.beta*diffw);
		        }
	
			//grad[i] += Aji * resmod;
			gradient_xph[i] += Aji*resmod_xph;
		}

	     }


	}



  static inline D compute_fast_objective(const problem_data<L, D> &inst,
					 const std::vector<D> &residuals) {

    L imagesize=inst.m/7;

    D resids_u = 0;        
    D resids_uw = 0;    
    D resids_ww = 0;    
    for (L i=0; i<imagesize; i++) {
	resids_u += 0.5*square(residuals[7*i]);
	resids_uw += inst.rownorms[0]*psimu(inst.alpha/inst.rownorms[0]*(sqrt(square(residuals[7*i+1])+square(residuals[7*i+2]))),inst.mu);
	resids_ww += inst.rownorms[1]*psimu(inst.beta/inst.rownorms[1]*(sqrt(square(residuals[7*i+3])+2*square(0.5*(residuals[7*i+4]+residuals[7*i+5]))+square(residuals[7*i+6]))),inst.mu);
    }

    D sumx = 0;
    D linpart = 0.;
    for (L j = 0; j < inst.N; j++) {
      sumx += abs(inst.x[j]);
    }
    for (L j = 0; j < inst.N; j++) {
      linpart += inst.c[j]*inst.x[j];
    }

//   cout << "f(x)="<<resids_u << "+"<<resids_uw << "+"<<resids_ww << "+"<<inst.lambda <<"*"<< sumx << "+"<<linpart<<"="<< resids_u +resids_uw+resids_ww+ inst.lambda * sumx + linpart<<endl;

    return resids_u +resids_uw+resids_ww+  inst.lambda * sumx + linpart;
  }


  static inline void compute_reciprocal_lipschitz_constants(
							    problem_data<L, D> &inst, std::vector<D> &h_Li) {

    /*std::vector<D> colnorms2(inst.N);
      for (L i = 0; i < inst.N; i++) {
      colnorms2[i] = 0;
      for (L k = inst.A_csc_col_ptr[i];
      k < inst.A_csc_col_ptr[i + 1]; k++) {
      colnorms2[i] += inst.A_csc_values[k] * inst.A_csc_values[k];
      }
      }*/

/*
    std::vector<L> omega_j(inst.m,0);
    // Not sure this is the quickest way of finding the omega_j's
    	inst.omega=0;
	for (L j = 0; j < inst.m; j++) {
	   L prevnonzero=0;
	   for (L k = inst.A_csr_row_ptr[j]; k < inst.A_csr_row_ptr[j+1]; k++) {
		if (inst.blocks_ptr[prevnonzero] <= inst.A_csr_col_idx[k]) {
		   omega_j[j]++;
		   while (inst.blocks_ptr[prevnonzero] <= inst.A_csr_col_idx[k])
		      prevnonzero++;  
		}
	   }
	   inst.omega=max(inst.omega, omega_j[j]);
	}*/

    inst.omega=6;
    // Summand of the quadratic part: omega_j=1
    // Summand of the gradient part: omega_j=5 (w1, w2 and 3 x's)
    // Summand of the Hessian part: omega_j=6 (3 w1's and 3 w2's)


    inst.sigma = 1. + (inst.tau - 1.) * (inst.omega-1) / (D)(inst.n); 

    cout << "omega = "<< inst.omega << endl;
    
    L imagesize=inst.m/7;

    inst.rownorms.resize(2);
    
    inst.rownorms[0]=max(1e-20,inst.alpha);  //sqrt(3); 
    inst.rownorms[1]=max(1e-20,inst.beta);  //sqrt(2);

    D diameter=1./2.*(inst.rownorms[0]*imagesize + inst.rownorms[1]*imagesize);
    inst.mu = inst.epsilon/2/diameter;

    cout << "epsilon = " << inst.epsilon << ", mu = " << inst.mu << endl;

    if (inst.N==inst.n)
      for (L i=0; i<inst.N; i++) {
 	  h_Li[i] = 0;	    
	  for (L k = inst.A_csc_col_ptr[i];
		 k < inst.A_csc_col_ptr[i + 1]; k++) {
	     L j = inst.A_csc_row_idx[k];
	     if (j % 7 == 0)
		h_Li[i] += inst.A_csc_values[k] * inst.A_csc_values[k];
	     else if ((j % 7 == 1)||(j % 7 == 2))
		h_Li[i] += inst.A_csc_values[k] * inst.A_csc_values[k] * inst.alpha / inst.rownorms[0] / inst.mu;
	     else   // j % 7 >=3
		h_Li[i] += inst.A_csc_values[k] * inst.A_csc_values[k] * inst.beta / inst.rownorms[1] / inst.mu;
	    }
	    if (h_Li[i] > 0)
	      h_Li[i] = 1. / (inst.sigma * h_Li[i]); // Compute reciprocal Lipschitz Constants
	    else
	      h_Li[i] = 1e16;
       }
    else 
	cout << "tgv2:compute_reciprocal_lipschitz_constants: Case not coded yet.\n";

//    cout << 1./h_Li[0] << " " << 1./h_Li[1] << " " << 1./h_Li[2] << " " << 1./h_Li[3] << " " << 1./h_Li[4]<<endl;

  }

};

#endif /* TGV2_LOSS_H */
