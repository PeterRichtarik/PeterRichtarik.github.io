/*
 * This file contains a function for experiment done in paper
 * O. Fercoq and P. Richtárik
 *      Smoothed Parallel Coordinate Descent Method for Huge-Scale Optimization Problems 
 */


/*
 *  Created on: 28 May 2013
 *      Author: Olivier Fercoq
 */

#ifndef EXP_LOSS_H
#define EXP_LOSS_H


struct exp_loss_traits: public loss_traits {
};

/*******************************************************************/
// a partial specialisation for inf norm loss
template<typename L, typename D>
class Losses<L, D, exp_loss_traits> {

public:

	static inline void set_residuals_for_zero_x(problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = -inst.b[i];
		}

		// Compute the value of the function 
		D tmp=0;
		for (L i = 0; i < inst.m; i++) {
			tmp += exp(residuals[i]);
		}

		inst.normalization_factor = tmp;

	}

	static inline void recompute_residuals(problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		recompute_residuals(inst, residuals, inst.x, inst.b);	
	}

	static inline void recompute_residuals(problem_data<L, D> &inst,
			std::vector<D> &residuals, const std::vector<D> &x, const std::vector<D> &b) {
#pragma omp parallel for
		for (L j = 0; j < inst.m; j++) {
			residuals[j] = -b[j];
		}

#pragma omp parallel for
		for (L i = 0; i < inst.N; i++) {
			for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1];
					j++) {
				parallel::atomic_add(residuals[inst.A_csc_row_idx[j]], inst.A_csc_values[j] * x[i]);
			}
		}	

		// Compute the value of the function 
		D tmp=0;
#pragma omp parallel for reduction(+:tmp)
		for (L j = 0; j < inst.m; j++) {
			tmp += exp(residuals[j]);  //No big values for adaboost if we start with the 0 vector.
		}

		inst.normalization_factor = tmp;
	}

/*
	static inline void recompute_residuals_for_my_instance_data(
			const problem_data<L, D> &inst, std::vector<D> &residuals) {
		for (L row = 0; row < inst.m; row++) {
			residuals[row] = -inst.b[row];
			for (L col_tmp = inst.A_csr_row_ptr[row];
					col_tmp < inst.A_csr_row_ptr[row + 1]; col_tmp++) {
				residuals[row] += inst.A_csr_values[col_tmp]
						* inst.x[inst.A_csr_col_idx[col_tmp]];
			}
		}
	}
*/

	static inline void do_single_iteration_serial(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, const D grad) {
		//D tmp=0.5*sqrt(Li[idx])*log((sqrt(Li[idx])+grad)/(sqrt(Li[idx])-grad));
		D lognormaliz=log(inst.normalization_factor);
		D tmpplus=0;
		D tmpminus=0;	
		L coordinate=idx;
		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
		  L j = inst.A_csc_row_idx[k];
		  D resmod=exp(residuals[j]-lognormaliz);
		  if (inst.A_csc_values[k]<0)
			tmpminus += -inst.A_csc_values[k]*resmod;
		  else
			tmpplus += inst.A_csc_values[k]*resmod;
		}
		D tmp=0.5*sqrt(Li[idx])*(log(tmpminus)-log(tmpplus));

		x[idx] += tmp;  
		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			D oldres=residuals[inst.A_csc_row_idx[j]];
			residuals[inst.A_csc_row_idx[j]] += tmp * inst.A_csc_values[j];
			D newres=residuals[inst.A_csc_row_idx[j]];
		        inst.normalization_factor = inst.normalization_factor + exp(newres)- exp(oldres);
		}
	}

	static inline void do_single_iteration_parallel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li) {
	    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	    std::vector<D> update(nbcoord);
    	    compute_update(inst, residuals, idx, Li, update);
   	    do_single_update_parallel(inst, idx, residuals, x,Li, update);
	}

	/*static inline D do_single_iteration_parallel_for_distributed(
			problem_data<L, D> &inst, const L idx,
			std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, D* residual_updates) {
		D tmp;
		tmp = compute_update(inst, residuals, idx, Li);
		parallel::atomic_add(x[idx], tmp);
		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			parallel::atomic_add(residual_updates[inst.A_csc_row_idx[j]],
					tmp * inst.A_csc_values[j]);
		}
		return abs(tmp);
	}*/

	static inline void do_single_update_parallel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, const std::vector<D>& update) {
   	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {		
		D reduction=0.;
		L coordinate=inst.blocks_ptr[idx]+i;	
		parallel::atomic_add(x[coordinate],update[i]);

		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			// Update of the residuals
			D Akh = update[i] * inst.A_csc_values[k];
			D newres;
			newres=parallel::atomic_add(residuals[inst.A_csc_row_idx[k]], Akh);
			D oldres = newres-Akh;  

			// Reduction for the update of the normalization factor
			reduction += exp(newres)*(1.-exp(oldres-newres));
		}

		//Asynchronous reduction.
		parallel::atomic_add(inst.normalization_factor, reduction);
	  }
	}


	// Here, we do not update the normalization, since the normalization needs y = theta^2 w + z. To be used with a line search.
	static inline void do_single_update_parallel_accel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals_w, std::vector<D> &residuals_z,
			const std::vector<D> &Li,  std::vector<D>& update_w, std::vector<D>& update_z) {
// The accelerated coordinate descent method is rather unstable so it is important to update w and z together for y to be the least affected by the asynchronous implementation.
   	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {		
		L coordinate=inst.blocks_ptr[idx]+i;	
		parallel::atomic_add(inst.w[coordinate], update_w[i]);
		parallel::atomic_add(inst.z[coordinate], update_z[i]);
		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			D Aji=inst.A_csc_values[k];
			L j = inst.A_csc_row_idx[k];
			parallel::atomic_add(residuals_w[j], Aji * update_w[i]);
			parallel::atomic_add(residuals_z[j], Aji * update_z[i]);
		}
	  }
	}


  static inline void compute_update(const problem_data<L, D> &inst, const std::vector<D> &residuals, const L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}

	static inline void compute_update(const problem_data<L, D> &inst,
			const std::vector<D> &residuals, const L idx,
			const std::vector<D> &Li, std::vector<D> &update, std::vector<D> &grad) {   	

	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	D lognormaliz=log(inst.normalization_factor); //Avoids looking at variables stored in other caches.


#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {		
		L coordinate=inst.blocks_ptr[idx]+i;	
		update[i] = 0.; //compute partial derivative f_idx'(x)
		D resmod;

		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
		  L j = inst.A_csc_row_idx[k];
		  resmod=exp(residuals[j]-lognormaliz);
   		  update[i] += inst.A_csc_values[k] * resmod;
		}
		update[i]*=exp(lognormaliz);
		update[i]+=inst.c[coordinate];

	        if ((L)grad.size()>=nbcoord)
		    grad[i]=update[i];

		update[i] = compute_soft_treshold(Li[idx] * inst.lambda,
				inst.x[coordinate] - Li[idx] * update[i]) - inst.x[coordinate];

	  }
	}

	static inline void compute_grad_xph(const problem_data<L, D> &inst,
					const std::vector<D> &originalresiduals, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_x, std::vector<D> &gradient_xph) {	

    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	if (nbcoord>1)
  		cout << "loss exp: compute grad xph, attention: not coded for blocksize>1\n";

  	    D lognormaliz=log(inst.normalization_factor); //This is not the good normalization but with the line search, it is as if we did not put the log.

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {			
	    L coordinate=inst.blocks_ptr[idx]+i;
	    gradient_xph[i] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x

	    for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
		    L j = inst.A_csc_row_idx[k];
		    D resmod_xph = exp( originalresiduals[j]+omega_S*update_x[i]*inst.A_csc_values[k] - lognormaliz );

		    gradient_xph[i] += inst.A_csc_values[k] * resmod_xph;  
	    }
	    gradient_xph[i]*=exp(lognormaliz);
	    gradient_xph[i]+=inst.c[coordinate];
	  }

	}

  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z) {

   std::vector<D> nogradreturned(0);
   compute_update_accel(inst, theta, theta*theta, residuals_w, residuals_z, idx, Lintau, update_z, nogradreturned);

}

	// Here, we do not normalize, since the normalization needs y = theta^2 w + z. To be used with a line search.
	static inline void compute_update_accel(const problem_data<L, D> &inst, D theta, D theta2, 
			const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
			const std::vector<D> &Lintau, std::vector<D> &update_z, std::vector<D> &grad) {
    	   L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	   D lognormaliz;
	   if (nbcoord==inst.N)
		lognormaliz=log(inst.normalization_factor);
	   else
		lognormaliz=0.;

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	   for (L i=0; i<nbcoord; i++)
             {			
	        L coordinate=inst.blocks_ptr[idx]+i;
		update_z[i] = 0; //compute partial derivative f_idx'(theta^2 w + z)
		D zi=inst.z[coordinate];

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D Aji=inst.A_csc_values[k];		
		    	D resmod=exp(theta2*residuals_w[row_id]+residuals_z[row_id]-lognormaliz);
			update_z[i] += Aji * resmod;
		}
		update_z[i]+=inst.c[coordinate];

	        if ((L)grad.size()>=nbcoord)
		    grad[i]=update_z[i];

		// proximal operator
		update_z[i] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate], compute_soft_treshold(Lintau[idx] * inst.lambda/theta,
				zi - Lintau[idx] * update_z[i]/theta ))) - zi;
	     }
	}

	static inline void compute_grad_xph_accel(const problem_data<L, D> &inst, const D theta,
					const std::vector<D> &originalresiduals_w, const std::vector<D> &originalresiduals_z, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_z, std::vector<D> &gradient_xph) {	

	   // We cannot use the normalization factor here because it would require us to compute y = theta^2 w + z.
	
    	   L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  	   D theta2=theta*theta;
	   D ck=-(1.-inst.n/(D)inst.tau*theta)/theta2;


#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	   for (L i=0; i<nbcoord; i++)
             {			
	        L coordinate=inst.blocks_ptr[idx]+i;
	    	gradient_xph[i] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D Aji=inst.A_csc_values[k];		
		    	D resmod_xph=exp(
					theta2*(originalresiduals_w[row_id]+ck*omega_S*update_z[i]*Aji)+(originalresiduals_z[row_id]+omega_S*update_z[i]*Aji) 
						);
			gradient_xph[i] += Aji*resmod_xph;
		}
  	        gradient_xph[i]+=inst.c[coordinate];
	     }


	}


	static inline D compute_fast_objective(const problem_data<L, D> &inst,
			const std::vector<D> &residuals) {

		L linesearch=1;
		D logsumexp=0;
		D maxresids=-100;
		if (linesearch==0)
		   logsumexp=log(inst.normalization_factor/inst.m);
		else  {
 		   for (L i = 0; i < inst.m; i++) {
			logsumexp += exp(residuals[i]);  //No big values for adaboost if we start with the 0 vector.
			maxresids=max(maxresids, residuals[i]);			
		   }
		   //logsumexp=log(logsumexp/inst.m);
 		}

		D sumx=0;
		if (inst.lambda!=0) {
#pragma omp parallel for
			for (L i = 0; i < inst.N; i++) {
				sumx += abs(inst.x[i]);
			}
		}
//cout << "f(x)=" << logsumexp << "+" << inst.lambda * sumx << "=" << logsumexp + inst.lambda * sumx <<endl;
		return logsumexp + inst.lambda * sumx;
	}

	static inline void compute_reciprocal_lipschitz_constants(
			problem_data<L, D> &inst, std::vector<D> &h_Li) {

	  inst.epsilon=1e-10;
	  inst.mu=1;

	  D colnorms;

	  //Here, the dual norm is a weighted 1-norm, so we do need to change betas(=sigma)
	  inst.sigma=esofactor<L,D>(inst.omega,inst.tau,inst.m,inst.n); 

	  for (L i=0; i<inst.n; i++)
	    {   
	      colnorms=0;
      		for (L k=inst.A_csc_col_ptr[i]; k<inst.A_csc_col_ptr[i+1]; k++)
			colnorms=std::max(colnorms, abs(inst.A_csc_values[k]));
	       h_Li[i]=std::max(1e-20,colnorms*colnorms/inst.mu);
	   
 	       if (h_Li[i] > 0)
	          h_Li[i] = 1. / (inst.sigma * h_Li[i]); // Compute reciprocal Lipschitz Constants
	       else
	          h_Li[i] = 1e20;
    	    }  

	  cout << "epsilon=" << inst.epsilon << ", mu=" << inst.mu<< ", (dual 1-norm) beta=" << inst.sigma << endl;

	  if (inst.n==1)  {
	     inst.sigma=1;
	     h_Li[0]=0;
	     for (L j=0; j<inst.m; j++)  {
	        D sqrow2norm=0;
	        for (L k=inst.A_csr_row_ptr[j]; k<inst.A_csr_row_ptr[j+1]; k++)
		  sqrow2norm += inst.A_csr_values[k]*inst.A_csr_values[k];
	        h_Li[0]=max(h_Li[0], sqrow2norm); 
	     }
	   cout << "Lipschitz constant: "<<h_Li[0] << endl;
	   h_Li[0] = 1. / h_Li[0];
          }

	}


};

#endif /* INFNORM_LOSS_H */
