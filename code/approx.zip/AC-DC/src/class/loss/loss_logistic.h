/*
 * This file contains an functions for experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */


/*
 * abstract_loss.h
 *
 *  Created on: 19 Jan 2012
 *      Author: jmarecek and taki
 */

#ifndef LOGISTIC_LOSS_H
#define LOGISTIC_LOSS_H

#include "loss_abstract.h"


struct logistics_loss_traits: public loss_traits {
};

/*******************************************************************/
// a partial specialisation for logistic loss
template<typename L, typename D>
class Losses<L, D, logistics_loss_traits> {

public:

	static inline void recompute_residuals_for_my_instance_data(
			const problem_data<L, D> &inst, std::vector<D> &residuals) {
		for (L row = 0; row < inst.m; row++) {
			residuals[row] = 0;
			for (L col_tmp = inst.A_csr_row_ptr[row];
					col_tmp < inst.A_csr_row_ptr[row + 1]; col_tmp++) {
				residuals[row] -= inst.b[row] * inst.A_csr_values[col_tmp]
						* inst.x[inst.A_csr_col_idx[col_tmp]];
			}
		}
	}


	static inline void recompute_residuals(const problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = 0;
		}
		for (L i = 0; i < inst.N; i++) {
			for (L j = inst.A_csc_col_ptr[i];
					j < inst.A_csc_col_ptr[i + 1]; j++) {
				residuals[inst.A_csc_row_idx[j]] -= inst.x[i]
						* inst.b[inst.A_csc_row_idx[j]] * inst.A_csc_values[j];
			}
		}
	}

	static inline void recompute_residuals(const problem_data<L, D> &inst,
			std::vector<D> &residuals, std::vector<D> &x, std::vector<D> &useless) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = 0;
		}
		for (L i = 0; i < inst.N; i++) {
			for (L j = inst.A_csc_col_ptr[i];
					j < inst.A_csc_col_ptr[i + 1]; j++) {
				residuals[inst.A_csc_row_idx[j]] -= x[i]
						* inst.b[inst.A_csc_row_idx[j]] * inst.A_csc_values[j];
			}
		}
	}

	static inline void set_residuals_for_zero_x(const problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = 0;
		}
	}

	static inline void do_single_iteration_serial(problem_data<L, D> &inst,
			const L &idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, const D useless) {
		std::vector<D> tmp(1);
		compute_update(inst, residuals, idx, Li, tmp);
		if (tmp[0] != 0) {
			x[idx] += tmp[0];
			for (unsigned int j = inst.A_csc_col_ptr[idx];
					j < inst.A_csc_col_ptr[idx + 1]; j++) {
				L row_id = inst.A_csc_row_idx[j];
				residuals[row_id] -= tmp[0] * inst.b[row_id]
						* inst.A_csc_values[j];
			}
		}
	}


	static inline void do_single_iteration_parallel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li) {
	    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	    std::vector<D> update(nbcoord);
    	    compute_update(inst, residuals, idx, Li, update);
   	    do_single_update_parallel(inst, idx, residuals, x,Li, update);
	}


	static inline D do_single_iteration_parallel_for_distributed(
			const problem_data<L, D> &inst, const L &idx,
			std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, D* residual_updates) {
		D tmp = compute_update(inst, residuals, idx, Li);
		parallel::atomic_add(x[idx], tmp);
		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			parallel::atomic_add(residual_updates[inst.A_csc_row_idx[j]],
					-tmp * inst.b[inst.A_csc_row_idx[j]]
							* inst.A_csc_values[j]);
		}
		return tmp;
	}


	static inline void do_single_update_parallel(problem_data<L, D> &inst,
			L idx, std::vector<D> &residuals, std::vector<D> &x, 
			const std::vector<D> &Li, std::vector<D> & update) {

	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
         {		
		L coordinate=inst.blocks_ptr[idx]+i;	
		parallel::atomic_add(x[coordinate], update[i]);

		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			parallel::atomic_add(residuals[inst.A_csc_row_idx[k]], - update[i] * inst.b[inst.A_csc_row_idx[k]] * inst.A_csc_values[k]);
		}

	  }
	}


	static inline void do_single_update_parallel_accel(problem_data<L, D> &inst,
			L idx, std::vector<D> &residuals_w, std::vector<D> &residuals_z, 
			const std::vector<D> &Li, std::vector<D> &update_w, std::vector<D> &update_z) {
// The accelerated coordinate descent method is rather unstable so it is important to update w and z together for y to be the least affected by the asynchronous implementation.

	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];


#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
         {		
		L coordinate=inst.blocks_ptr[idx]+i;
		parallel::atomic_add(inst.w[coordinate], update_w[i]);
		parallel::atomic_add(inst.z[coordinate], update_z[i]);
		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			D minusbjAji = -inst.b[inst.A_csc_row_idx[k]]*inst.A_csc_values[k]; 
			L j = inst.A_csc_row_idx[k];
			parallel::atomic_add(residuals_w[j], update_w[i] * minusbjAji);
			parallel::atomic_add(residuals_z[j], update_z[i] * minusbjAji);
		}
	  }
	}

  static inline void compute_update(problem_data<L, D> &inst, std::vector<D> &residuals, L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}

	static inline void compute_update(problem_data<L, D> &inst,
			std::vector<D> &residuals, L idx,
			const std::vector<D> &Li, std::vector<D> &update_x, std::vector<D> &grad) {

	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {		
		L coordinate=inst.blocks_ptr[idx]+i;	
		D partialDerivative = 0;
		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D tmp = exp(residuals[row_id]);
			partialDerivative += tmp / (1 + tmp) * inst.b[row_id]
					* inst.A_csc_values[k];
		}
		partialDerivative = -0.5 * inst.lambda * partialDerivative;
		
	        if ((L)grad.size()>=nbcoord)
		    grad[i]=partialDerivative;

		update_x[i] = compute_soft_treshold(1./(1./Li[idx]+inst.lambda2),
				1./(1.+inst.lambda2*Li[idx])*inst.x[coordinate] - 1./(1./Li[idx]+inst.lambda2) * partialDerivative) - inst.x[coordinate];
	  }


// test gradient
/*if ((idx==62317) && ((L)grad.size()>=nbcoord)){
D step=1e-6;
recompute_residuals(inst, residuals);
D fval=compute_fast_objective(inst, residuals)-abs(inst.x[idx]);
std::vector<D> update_step(1);
update_step[0]=step;
do_single_update_parallel( inst, idx, residuals, inst.x, Li, update_step);
recompute_residuals(inst, residuals);
D fval2=compute_fast_objective(inst, residuals)-abs(inst.x[idx]);
cout << "Gradient: direct calculation=" << grad[0] << ", finite differences=" << (fval2-fval)/step << endl;
sleep(1);
}*/
	}

	static inline void compute_grad_xph(problem_data<L, D> &inst,
					const std::vector<D> &originalresiduals, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_x, std::vector<D> &gradient_xph) {	

    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	if (nbcoord>1)
  		cout << "loss logistic: compute grad xph, attention: not coded for blocksize>1\n";

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {			
	    L coordinate=inst.blocks_ptr[idx]+i;
	    D partialDerivative = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x

	    for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D minusbjAji=-inst.b[row_id]*inst.A_csc_values[k];
			D resids_xph=originalresiduals[row_id]+omega_S*update_x[i]*minusbjAji;
			if (resids_xph >= 0) {   //Sometimes, the line search lets big numbers appear
			    D tmp = exp(-resids_xph); 
			    partialDerivative += 1. / (tmp + 1.) * minusbjAji;
			}
			else {
			    D tmp = exp(resids_xph);
			    partialDerivative += tmp / (1. + tmp) * minusbjAji;
			}
		}
		partialDerivative = 0.5 * inst.lambda * partialDerivative;
		gradient_xph[i] = partialDerivative;
	  }

	}

  static inline void compute_update_accel(problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z) {

   std::vector<D> nogradreturned(0);
   compute_update_accel(inst, theta, theta*theta, residuals_w, residuals_z, idx, Lintau, update_z, nogradreturned);

}


	static inline void compute_update_accel(problem_data<L, D> &inst, const D theta, const D theta2,
			const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
			const std::vector<D> &Lintau, std::vector<D> &update_z, std::vector<D> &grad) {

    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	for (L i=0; i<nbcoord; i++)
          {			
	        L coordinate=inst.blocks_ptr[idx]+i;
		D partialDerivative = 0; //compute partial derivative f_idx'(theta^2 w + z)
			
		D zi=inst.z[coordinate];

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D minusbjAji=-inst.b[row_id]*inst.A_csc_values[k];
			D tmp = exp(theta2*residuals_w[row_id]+residuals_z[row_id]);
			partialDerivative += tmp / (1 + tmp) * minusbjAji;
		}

		partialDerivative = 0.5 * inst.lambda * partialDerivative + inst.lambda2f*(theta2*inst.w[coordinate]+inst.z[coordinate]);

	        if ((L)grad.size()>=nbcoord)
		    grad[i]=partialDerivative;

		update_z[i] = compute_soft_treshold(1./(1./Lintau[idx]*theta+inst.lambda2),
				1./(1.+inst.lambda2*Lintau[idx]/theta)*(zi +inst.tau/(D)inst.n*inst.muf/theta*theta2*inst.w[coordinate]  ) 
				 - partialDerivative/(1./Lintau[idx]*theta+inst.lambda2) ) - zi;
	  }

	}

	static inline void compute_grad_xph_accel(problem_data<L, D> &inst, const D theta,
					const std::vector<D> &originalresiduals_w, const std::vector<D> &originalresiduals_z, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_z, std::vector<D> &gradient_xph) {	

    	   L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
  	   D theta2=theta*theta;
	   D ck=-(1.-inst.n/(D)inst.tau*theta)/theta2;

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	   for (L i=0; i<nbcoord; i++)
             {			
	        L coordinate=inst.blocks_ptr[idx]+i;
	    	D partialDerivative = 0.; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D minusbjAji=-inst.b[row_id]*inst.A_csc_values[k];
		    	D resids_xph=theta2*(originalresiduals_w[row_id]+ck*omega_S*update_z[i]*minusbjAji)+(originalresiduals_z[row_id]+omega_S*update_z[i]*minusbjAji);
			if (resids_xph >= 0) {  //Sometimes, the line search lets big numbers appear
			    D tmp = exp(-resids_xph); 
			    partialDerivative += 1. / (tmp + 1.) * minusbjAji;
			}
			else {
			    D tmp = exp(resids_xph);
			    partialDerivative += tmp / (1. + tmp) * minusbjAji;
			}
		}

		partialDerivative = 0.5 * inst.lambda * partialDerivative;
		gradient_xph[i]=partialDerivative;

	     }


	}




	static inline D compute_fast_objective(const problem_data<L, D> &part,
			const std::vector<D> &residuals) {
		D resids = 0.;
		D sumx = 0.;
		D sumx2 = 0.;
		for (L i = 0; i < part.m; i++) {
			resids += log(1 + exp(residuals[i]));
		}
		for (L j = 0; j < part.N; j++) {
			sumx += abs(part.x[j]);
		}
		for (L j = 0; j < part.N; j++) {
			sumx2 += part.x[j]*part.x[j];
		}
		
		return 0.5 * part.lambda * resids + sumx + 0.5*(part.lambda2+part.lambda2f)*sumx2;
	}


	static inline void compute_reciprocal_lipschitz_constants(
			const problem_data<L, D> &inst, std::vector<D> &h_Li) {
		for (L i = 0; i < inst.n; i++) {
			h_Li[i] = 0;
			for (L j = inst.A_csc_col_ptr[i];
					j < inst.A_csc_col_ptr[i + 1]; j++) {
				D tmp = inst.A_csc_values[j] * inst.b[inst.A_csc_row_idx[j]];
				h_Li[i] += tmp * tmp;
			}
			if (h_Li[i] > 0) //TODO Check if there should be "4" or not!!!
				h_Li[i] = 8 / (inst.sigma * inst.lambda * h_Li[i]); // Compute reciprocal Lipschitz Constants
			else
				h_Li[i]=1e20;
		}
	}
};

#endif /* LOGISTIC_LOSS_H */
