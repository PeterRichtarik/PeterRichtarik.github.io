/*
 * This file contains an functions for experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */


/*
 *  Created on: 19 Jan 2012
 *      Author: jmarecek and taki
 */

#ifndef SQUARE_LOSS_H
#define SQUARE_LOSS_H

#include "loss_abstract.h"

struct square_loss_traits: public loss_traits {
};

/*******************************************************************/
// a partial specialisation for square loss
template<typename L, typename D>
  class Losses<L, D, square_loss_traits> {

 public:

  static inline void set_residuals_for_zero_x(const problem_data<L, D> &inst,
					      std::vector<D> &residuals) {
    for (L i = 0; i < inst.m; i++) {
      residuals[i] = -inst.b[i];
    }
  }


  static inline void recompute_residuals(const problem_data<L, D> &inst,
					 std::vector<D> &residuals, const std::vector<D> &x, const std::vector<D> &b) {
#pragma omp parallel for
    for (L i = 0; i < inst.m; i++) {
      residuals[i] = -b[i];
    }
#pragma omp parallel for 
    for (L i = 0; i < inst.N; i++) {
      for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1];
	   j++) {
	parallel::atomic_add(residuals[inst.A_csc_row_idx[j]], inst.A_csc_values[j] * x[i]);
      }
    }
  }


  static inline void recompute_residuals(const problem_data<L, D> &inst,
					 std::vector<D> &residuals) {
	recompute_residuals(inst, residuals, inst.x, inst.b);
  }


  static inline void recompute_residuals_for_my_instance_data(
							      const problem_data<L, D> &inst, std::vector<D> &residuals) {
    for (L row = 0; row < inst.m; row++) {
      residuals[row] = -inst.b[row];
      for (L col_tmp = inst.A_csr_row_ptr[row];
	   col_tmp < inst.A_csr_row_ptr[row + 1]; col_tmp++) {
	residuals[row] += inst.A_csr_values[col_tmp] * inst.x[inst.A_csr_col_idx[col_tmp]];
      }
    }
  }

  static inline void do_single_iteration_serial(problem_data<L, D> &inst,
						const L idx, std::vector<D> &residuals, std::vector<D> &x,
						const std::vector<D> &Li, const D grad) {  //We do not use grad here, just for compatibility
    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    std::vector<D> update(nbcoord);	
    compute_update(inst, residuals, idx, Li, update);		
    for (L k=0; k<nbcoord; k++)
      {
	L coordinate=inst.blocks_ptr[idx]+k;	
	x[coordinate] += update[k];
	for (unsigned int j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  residuals[inst.A_csc_row_idx[j]] += update[k] * inst.A_csc_values[j];
	}
      }
  }

  static inline void do_single_iteration_parallel(problem_data<L, D> &inst,
						  const L idx, std::vector<D> &residuals, std::vector<D> &x,
						  const std::vector<D> &Li) {

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    std::vector<D> update(nbcoord);
    compute_update(inst, residuals, idx, Li, update);
    do_single_update_parallel(inst, idx, residuals, x,Li, update);

  }

  static inline D do_single_iteration_parallel_for_distributed(problem_data<L, D> &inst, const L idx,
							       std::vector<D> &residuals, std::vector<D> &x,
							       const std::vector<D> &Li, D* residual_updates) {
    D tmp = 0;
    tmp = compute_update(inst, residuals, idx, Li);
    parallel::atomic_add(x[idx], tmp);
    for (unsigned int j = inst.A_csc_col_ptr[idx];
	 j < inst.A_csc_col_ptr[idx + 1]; j++) {
      parallel::atomic_add(residual_updates[inst.A_csc_row_idx[j]],
			   tmp * inst.A_csc_values[j]);
    }
    return abs(tmp);
  }

  static inline void do_single_update_parallel(const problem_data<L, D> &inst,
					       L idx, std::vector<D> &residuals, std::vector<D> &x,
					       const std::vector<D> &Li, const std::vector<D> & update) {

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp parallel for if (nbcoord>10*inst.tau) 
    for (L k=0; k<nbcoord; k++)
      {
	L coordinate=inst.blocks_ptr[idx]+k;			
	parallel::atomic_add(x[coordinate], update[k]);
	for (L j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  parallel::atomic_add(residuals[inst.A_csc_row_idx[j]], update[k] * inst.A_csc_values[j]);

	}
      }
  }


  static inline void do_single_update_parallel_accel(problem_data<L, D> &inst,
						     L idx, std::vector<D> &residuals_w, std::vector<D> &residuals_z, const std::vector<D> &Li, 
						     const std::vector<D> & update_w, const std::vector<D> & update_z) {
    // The accelerated coordinate descent method is rather unstable so it is important to update w and z together for y to be the least affected by the asynchronous implementation.

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp for 
    for (L k=0; k<nbcoord; k++)
      {
	L coordinate=inst.blocks_ptr[idx]+k;	
	parallel::atomic_add(inst.w[coordinate], update_w[k]);
	parallel::atomic_add(inst.z[coordinate], update_z[k]);
	for (L j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  D Aij=inst.A_csc_values[j];
	  L i = inst.A_csc_row_idx[j];
	  parallel::atomic_add(residuals_w[i], update_w[k] * Aij);
	  parallel::atomic_add(residuals_z[i], update_z[k] * Aij);
	}

      }

  }

  static inline void compute_update(const problem_data<L, D> &inst, const std::vector<D> &residuals, const L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}


  static inline void compute_update(const problem_data<L, D> &inst,
				    const std::vector<D> &residuals, const L idx,
				    const std::vector<D> &Li, std::vector<D> &update_x, std::vector<D> &grad) {
    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp for 
    for (L k=0; k<nbcoord; k++)
      {			
	L coordinate=inst.blocks_ptr[idx]+k;
	update_x[k] = 0; //compute partial derivative f_idx'(x)

	for (L j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++)
	  update_x[k] += inst.A_csc_values[j] * residuals[inst.A_csc_row_idx[j]];

	update_x[k]+=inst.c[coordinate];

        if ((L)grad.size()>=nbcoord)
	    grad[k]=update_x[k];

	//Soft and hard thresholding
	update_x[k] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate], 
							   compute_soft_treshold(1./(1./Li[idx]+inst.lambda2) * inst.lambda,
										 1./(1.+inst.lambda2*Li[idx]) * inst.x[coordinate] - 1./(1./Li[idx]+inst.lambda2) * update_x[k] )));
      }
    // L2 projection (should not be used in conjunction with hard thresholding)
    projL2ball<L,D>(update_x, nbcoord, inst.dimball, inst.radius);

//#pragma omp for 
    for (L k=0; k<nbcoord; k++)
      update_x[k]-= inst.x[inst.blocks_ptr[idx]+k];
	
  }

  static inline void compute_grad_xph(const problem_data<L, D> &inst,
					const std::vector<D> &originalresiduals, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_x, std::vector<D> &gradient_xph) {	
	
    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
if (nbcoord>1)
  cout << "loss square: compute grad xph, attention: not coded for blocksize>1\n";
//#pragma omp for  
    for (L k=0; k<1; k++) //(L k=0; k<nbcoord; k++)
      {	
	L coordinate=inst.blocks_ptr[idx]+k;
	gradient_xph[k] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x
	for (L j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  gradient_xph[k] += inst.A_csc_values[j] * (originalresiduals[inst.A_csc_row_idx[j]]+omega_S*update_x[k]*inst.A_csc_values[j]);   //Only valid if blocksize=1
	}

	gradient_xph[k]+=inst.c[coordinate];
      }

  }

  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z) {

   std::vector<D> nogradreturned(0);
   compute_update_accel(inst, theta, theta*theta, residuals_w, residuals_z, idx, Lintau, update_z, nogradreturned);

}


  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta, const D theta2,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z, std::vector<D> &grad) {
    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp for
    for (L k=0; k<nbcoord; k++)
      {	

	D tmpw=0;
	D tmpz=0;
	update_z[k] = 0; //compute partial derivative f_idx'(theta^2 w + z)

	L coordinate=inst.blocks_ptr[idx]+k;
	for (L j = inst.A_csc_col_ptr[coordinate]; j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  D Aij=inst.A_csc_values[j];		
	  tmpw += Aij * residuals_w[inst.A_csc_row_idx[j]];
	  tmpz += Aij * residuals_z[inst.A_csc_row_idx[j]];
	}
	update_z[k] = theta2*tmpw+tmpz;
	update_z[k]+= inst.c[coordinate];

        if ((L)grad.size()>=nbcoord)
	    grad[k]=update_z[k];

	//Soft and hard thresholding
	update_z[k] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate], 
							compute_soft_treshold(1./(1./Lintau[idx]*theta+inst.lambda2) * inst.lambda,
								1./(1.+inst.lambda2*Lintau[idx]/theta)*(inst.z[coordinate]+inst.tau/(D)inst.n*inst.muf/theta*theta2*inst.w[coordinate])
								 - 1./(1./Lintau[idx]*theta+inst.lambda2)* update_z[k] )));   // when restart==FIXED_THETA, theta2 is not theta*theta.
      }
    // L2 projection (should not be used in conjunction with hard thresholding)
    projL2ball<L,D>(update_z, nbcoord, inst.dimball, inst.radius);

//#pragma omp for 
    for (L k=0; k<nbcoord; k++)
      update_z[k]-= inst.z[inst.blocks_ptr[idx]+k];

if (update_z[0]!=update_z[0])
{
#pragma omp critical
 cout << "Probleme: " << idx << " " << theta << " " << theta2 << endl;
sleep(1);
}
  }



  static inline void compute_grad_xph_accel(const problem_data<L, D> &inst, D theta,
					const std::vector<D> &originalresiduals_w, const std::vector<D> &originalresiduals_z, const L idx, const D omega_S,
					const std::vector<D> &Lintau, const std::vector<D> &update_z, std::vector<D> &gradient_xph) {	

    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    D ck=-(1.-inst.n/(D)inst.tau*theta)/(theta*theta);
if (nbcoord>1)
  cout << "loss square: compute grad xph accel, attention: not coded for blocksize>1\n";
//#pragma omp for  
    for (L k=0; k<1; k++) //(L k=0; k<nbcoord; k++)
      {	
	L coordinate=inst.blocks_ptr[idx]+k;
	gradient_xph[k] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x
	D tmpw_xph=0;
	D tmpz_xph=0;
	for (L j = inst.A_csc_col_ptr[coordinate];
	     j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	  D Aij=inst.A_csc_values[j];		
	  tmpw_xph += Aij * (originalresiduals_w[inst.A_csc_row_idx[j]]+ck*omega_S*update_z[k]*Aij);
	  tmpz_xph += Aij * (originalresiduals_z[inst.A_csc_row_idx[j]]+omega_S*update_z[k]*Aij);
	  
	}

	gradient_xph[k] = theta*theta*tmpw_xph+tmpz_xph;   //Only valid if blocksize=1

	gradient_xph[k]+=inst.c[coordinate];
      }

  }

  static inline D compute_fast_objective(const problem_data<L, D> &part,
					 const std::vector<D> &residuals)
{
      return  compute_fast_objective(part, residuals, part.x);
}

  static inline D compute_fast_objective(const problem_data<L, D> &part,
					 const std::vector<D> &residuals, const std::vector<D> &x) {
    D resids = 0;
    D sumx = 0;
    D linpart = 0.;
#pragma omp parallel for reduction(+:resids)
    for (L i = 0; i < part.m; i++) {
      resids += residuals[i] * residuals[i];
    }
#pragma omp parallel for reduction(+:sumx)
    for (L j = 0; j < part.N; j++) {
      sumx += abs(x[j]);
    }
#pragma omp parallel for reduction(+:linpart)
    for (L j = 0; j < part.N; j++) {
      linpart += part.c[j]*x[j];
    }
  //  cout << "f(x)=0.5*"<<resids << "+"<<part.lambda <<"*"<< sumx << "+"<<linpart<<"="<< 0.5 * resids + part.lambda * sumx + linpart<<endl;

    return 0.5 * resids + part.lambda * sumx + linpart;
  }


  static inline void compute_reciprocal_lipschitz_constants(
							    problem_data<L, D> &inst, std::vector<D> &h_Li) {

    /*std::vector<D> colnorms2(inst.N);
      for (L i = 0; i < inst.N; i++) {
      colnorms2[i] = 0;
      for (L k = inst.A_csc_col_ptr[i];
      k < inst.A_csc_col_ptr[i + 1]; k++) {
      colnorms2[i] += inst.A_csc_values[k] * inst.A_csc_values[k];
      }
      }*/

    std::vector<L> omega_j(inst.m,0);


    inst.omega=0;
    D aveomega=0;
    for (L j = 0; j < inst.m; j++) {
	//L prevnonzero=0;
        //for (L k = inst.A_csr_row_ptr[j]; k < inst.A_csr_row_ptr[j+1]; k++) {   
	    // Not sure this is the quickest way of finding the omega_j's
	    /*if (inst.blocks_ptr[prevnonzero] <= inst.A_csr_col_idx[k]) {
	        omega_j[j]++;
	        while (inst.blocks_ptr[prevnonzero] <= inst.A_csr_col_idx[k])
		    prevnonzero++;  
	    }*/
	    // Faster but an upper estimate if blocksize>1.
        //}
	omega_j[j]=inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j];
	aveomega+=omega_j[j]/(D)inst.m;
	inst.omega=max(inst.omega, omega_j[j]);
    }

    //for (L j=0; j<inst.m; j++)
    // 	omega_j[j]=inst.omega;
    //cout << "Attention: old stepsizes!" << endl; 

    inst.sigma = 1. + (inst.tau - 1.) * (inst.omega-1) / max(1.,(D)inst.n-1.); 

    cout << "block setting: omega = "<< inst.omega << ", average omega = " << aveomega << endl;

#pragma omp parallel for 
    for (L idx = 0; idx < inst.n; idx++) {
      if (inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]==1) {
	h_Li[idx] = 0;
	L i = inst.blocks_ptr[idx];
	for (L k = inst.A_csc_col_ptr[i];
	     k < inst.A_csc_col_ptr[i + 1]; k++) {
	  L j = inst.A_csc_row_idx[k];
	  h_Li[idx] += inst.A_csc_values[k] * inst.A_csc_values[k] 
	    * (1.+(omega_j[j])*(inst.tau-1.)/max(1., inst.n-1.));  // omega_j instead of omega_j-1 because we use independent sampling instead of nice sampling
	}
	inst.sigma=1;  // Improved coordinate-dependent version
      }
      else if (inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]==2) {
				
	D a=0;
	for (L k = inst.A_csc_col_ptr[inst.blocks_ptr[idx]];
	     k < inst.A_csc_col_ptr[inst.blocks_ptr[idx] + 1]; k++) {
	  a += inst.A_csc_values[k] * inst.A_csc_values[k];
	}
	D d=0;
	for (L k = inst.A_csc_col_ptr[inst.blocks_ptr[idx] + 1];
	     k < inst.A_csc_col_ptr[inst.blocks_ptr[idx] + 2]; k++) {
	  d += inst.A_csc_values[k] * inst.A_csc_values[k];
	}
	D c=0;
	L k2=inst.A_csc_col_ptr[inst.blocks_ptr[idx]] + 1;
	for (L k = inst.A_csc_col_ptr[inst.blocks_ptr[idx]];
	     k < inst.A_csc_col_ptr[inst.blocks_ptr[idx] + 1]; k++) {
	  while ( (inst.A_csc_row_idx[k2]<inst.A_csc_row_idx[k]) && (k2 < inst.A_csc_col_ptr[inst.blocks_ptr[idx]] + 2) )
	    k2++;
	  if (inst.A_csc_row_idx[k2]==inst.A_csc_row_idx[k])
	    c += inst.A_csc_values[k] * inst.A_csc_values[k2];
	}
	h_Li[idx]=0.5*(a+d+sqrt((a-d)*(a-d)+4*c*c));

	//inst.sigma is not 1 here.
      }
      else if (inst.n==1){  //Power iterations.
	L nbcoord = inst.N;
	std::vector<D> x0;
	std::vector<D> x1;
	std::vector<D> Ax0;
	x0.resize(nbcoord,1.);
	x1.resize(nbcoord,1.);
	Ax0.resize(inst.m);
	for (L k=0; k<20; k++)
	  {
	    for (L i=0; i < nbcoord; i++)
	      x0[i]=x1[i];
	    for (L j = 0; j< inst.m; j++)
	      Ax0[j]=0.;
	    for (L i = 0; i < nbcoord; i++) {
	      for (L j = inst.A_csc_col_ptr[inst.blocks_ptr[idx]+i]; j < inst.A_csc_col_ptr[inst.blocks_ptr[idx]+i+1];
		   j++) {
		Ax0[inst.A_csc_row_idx[j]] += inst.A_csc_values[j]*x0[i];
	      }
	    }
	    for (L i = 0; i < nbcoord; i++) {
	      x1[i]=0.;
	      for (L j = inst.A_csc_col_ptr[inst.blocks_ptr[idx]+i]; j < inst.A_csc_col_ptr[inst.blocks_ptr[idx]+i+1];
		   j++) {
		x1[i] += inst.A_csc_values[j]*Ax0[inst.A_csc_row_idx[j]];
	      }
	    }
	    inst.lipschitz=0.;
	    for (L i=0; i < nbcoord; i++)
	      h_Li[idx]+=x1[i]*x1[i];
	    h_Li[idx]=sqrt(h_Li[idx]);
	    for (L i=0; i < nbcoord; i++)
	      x1[i]/=h_Li[idx];
	    if (inst.N==nbcoord)
	      cout << h_Li[0] << "; ";
	  }
	h_Li[idx]*=1.1; // For security as not converged yet.
	inst.sigma=1;

      }

      if (h_Li[idx] > 0)
	h_Li[idx] = 1. / (inst.sigma * h_Li[idx]); // Compute reciprocal Lipschitz Constants
      else
	h_Li[idx] = 1e20;

      if (inst.n==1)	
	h_Li.resize(inst.N, h_Li[0]);


    }
    cout << "L[0]=" << 1. / (inst.sigma * h_Li[0]) << endl;
		
  }

};

#endif /* SQUARE_LOSS_H */
