/*
 * This file contains a function for experiment done in paper
 * O. Fercoq and P. Richtárik
 *      Smoothed Parallel Coordinate Descent Method for Huge-Scale Optimization Problems 
 */


/*
 *  Created on: 16 May 2013
 *      Author: Olivier Fercoq
 */

#ifndef ONENORM_LOSS_H
#define ONENORM_LOSS_H

#include "loss_abstract.h"

template<typename D>
inline D psimu(D tau, D mu)
{
  if (tau < mu)
	return tau*(tau/2./mu);
  //else (tau >= mu)
  return tau-1./2.*mu;
}



struct onenorm_loss_traits: public loss_traits {
};

/*******************************************************************/
// a partial specialisation for one norm loss
template<typename L, typename D>
class Losses<L, D, onenorm_loss_traits> {

public:

	static inline void set_residuals_for_zero_x(const problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = -inst.b[i];
		}
	}

	static inline void recompute_residuals(const problem_data<L, D> &inst,
			std::vector<D> &residuals, const std::vector<D> &x, const std::vector<D> &b) {
#pragma omp parallel for
		for (L i = 0; i < inst.m; i++) {
			residuals[i] = -b[i];
		}
#pragma omp parallel for
		for (L i = 0; i < inst.N; i++) {
			for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1];
					j++) {
				parallel::atomic_add(residuals[inst.A_csc_row_idx[j]], inst.A_csc_values[j] * x[i]);
			}
		}
	}

	static inline void recompute_residuals(const problem_data<L, D> &inst,
			std::vector<D> &residuals) {
		recompute_residuals(inst, residuals, inst.x, inst.b);	
	}


	static inline void recompute_residuals_for_my_instance_data(
			const problem_data<L, D> &inst, std::vector<D> &residuals) {
		for (L row = 0; row < inst.m; row++) {
			residuals[row] = -inst.b[row];
			for (L col_tmp = inst.A_csr_row_ptr[row];
					col_tmp < inst.A_csr_row_ptr[row + 1]; col_tmp++) {
				residuals[row] += inst.A_csr_values[col_tmp]
						* inst.x[inst.A_csr_col_idx[col_tmp]];
			}
		}
	}

	static inline void do_single_iteration_serial(const problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, const D grad_not_used) {
    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
    	std::vector<D> update(nbcoord);	
    	compute_update(inst, residuals, idx, Li, update);		
    	for (L k=0; k<nbcoord; k++)
      	  {
	    L coordinate=inst.blocks_ptr[idx]+k;	
	    x[coordinate] += update[k];
	    for (L j = inst.A_csc_col_ptr[coordinate];
	       j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
	       residuals[inst.A_csc_row_idx[j]] += update[k] * inst.A_csc_values[j];
             }
	  }
        
	}

	static inline void do_single_iteration_parallel(const problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li) {
	    L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	    std::vector<D> update(nbcoord);
    	    compute_update(inst, residuals, idx, Li, update);
   	    do_single_update_parallel(inst, idx, residuals, x,Li, update);
	}

	static inline D do_single_iteration_parallel_for_distributed(
			const problem_data<L, D> &inst, const L idx,
			std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, D* residual_updates) {
		D tmp = 0;
		tmp = compute_update(inst, residuals, idx, Li);
		parallel::atomic_add(x[idx], tmp);
		for (L j = inst.A_csc_col_ptr[idx];
				j < inst.A_csc_col_ptr[idx + 1]; j++) {
			parallel::atomic_add(residual_updates[inst.A_csc_row_idx[j]],
					tmp * inst.A_csc_values[j]);
		}
		return abs(tmp);
	}

	static inline void do_single_update_parallel(const problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals, std::vector<D> &x,
			const std::vector<D> &Li, std::vector<D>& update) {
    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp parallel for if (nbcoord>=inst.tau) 
	for (L i=0; i<nbcoord; i++)
          {		
		L coordinate=inst.blocks_ptr[idx]+i;	
		parallel::atomic_add(x[coordinate], update[i]);
		for (L j = inst.A_csc_col_ptr[coordinate];
				j < inst.A_csc_col_ptr[coordinate + 1]; j++) {
			parallel::atomic_add(residuals[inst.A_csc_row_idx[j]],
					update[i] * inst.A_csc_values[j]);
		}
	  }
	}

	static inline void do_single_update_parallel_accel(problem_data<L, D> &inst,
			const L idx, std::vector<D> &residuals_w, std::vector<D> &residuals_z,
			const std::vector<D> &Li,  std::vector<D>& update_w, std::vector<D>& update_z) {
// The accelerated coordinate descent method is rather unstable so it is important to update w and z together for y to be the least affected by the asynchronous implementation.
   	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp parallel for if (nbcoord>=inst.tau) 
	for (L i=0; i<nbcoord; i++)
          {		
		L coordinate=inst.blocks_ptr[idx]+i;	
		parallel::atomic_add(inst.w[coordinate], update_w[i]);
		parallel::atomic_add(inst.z[coordinate], update_z[i]);
		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			D Aji=inst.A_csc_values[k];
			L j = inst.A_csc_row_idx[k];
			parallel::atomic_add(residuals_w[j], Aji * update_w[i]);
			parallel::atomic_add(residuals_z[j], Aji * update_z[i]);
		}
	  }
	}


  static inline void compute_update(const problem_data<L, D> &inst, std::vector<D> &residuals, const L idx,
					  const std::vector<D> &Li, std::vector<D> &update_x) {

   std::vector<D> nogradreturned(0);
   compute_update(inst, residuals, idx, Li, update_x, nogradreturned);

}

	static inline void compute_update(const problem_data<L, D> &inst,
			const std::vector<D> &residuals, const L idx,
			const std::vector<D> &Li, std::vector<D> &update_x, std::vector<D> &grad) {

    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp parallel for if (nbcoord>=inst.tau) 
	for (L i=0; i<nbcoord; i++)
          {			
	    L coordinate=inst.blocks_ptr[idx]+i;
	    update_x[i] = 0;   //compute partial derivative f_idx'(x)
		for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
		    L j = inst.A_csc_row_idx[k];
		    D resmod=std::max(-1.,std::min(1.,residuals[j]/inst.mu/inst.rownorms[j]));

		    update_x[i] += inst.A_csc_values[k] * resmod;
		}
		update_x[i]+=inst.c[coordinate];

	        if ((L)grad.size()>=nbcoord)
		    grad[i]=update_x[i];

		update_x[i] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate],compute_soft_treshold(1./(1./Li[idx]+inst.lambda2) * inst.lambda,
				1./(1.+inst.lambda2*Li[idx])*inst.x[coordinate] - 1./(1./Li[idx]+inst.lambda2) * update_x[i]))) - inst.x[coordinate];
	  }
	}

	static inline void compute_grad_xph(const problem_data<L, D> &inst,
					const std::vector<D> &originalresiduals, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_x, std::vector<D> &gradient_xph) {	

    	L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	if (nbcoord>1)
  		cout << "loss onenorm: compute grad xph, attention: not coded for blocksize>1\n";

//#pragma omp parallel for if (nbcoord>=inst.tau) 
	for (L i=0; i<nbcoord; i++)
          {			
	    L coordinate=inst.blocks_ptr[idx]+i;
	    gradient_xph[i] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x
	    for (L k = inst.A_csc_col_ptr[coordinate];
				k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
		    L j = inst.A_csc_row_idx[k];
		    D resmod_xph = std::max(-1., std::min(1., (originalresiduals[inst.A_csc_row_idx[j]]+omega_S*update_x[i]*inst.A_csc_values[j])/inst.mu/inst.rownorms[j]));

		    gradient_xph[i] += inst.A_csc_values[k] * resmod_xph;  
	    }

	  }

	}


  static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta,
					  const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
					  const std::vector<D> &Lintau, std::vector<D> &update_z) {

   std::vector<D> nogradreturned(0);
   compute_update_accel(inst, theta, theta*theta, residuals_w, residuals_z, idx, Lintau, update_z, nogradreturned);

}

	static inline void compute_update_accel(const problem_data<L, D> &inst, const D theta, const D theta2,
			const std::vector<D> &residuals_w, const std::vector<D> &residuals_z, const L idx,
			const std::vector<D> &Lintau, std::vector<D> &update_z, std::vector<D> &grad) {
    	   L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];

//#pragma omp parallel for if (nbcoord>=inst.tau) 
	   for (L i=0; i<nbcoord; i++)
             {			
	        L coordinate=inst.blocks_ptr[idx]+i;
		update_z[i] = 0; //compute partial derivative f_idx'(theta^2 w + z)
		D zi=inst.z[coordinate];

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D Aji=inst.A_csc_values[k];		
		    	D resmod=std::max(-1.,std::min(1.,(theta2*residuals_w[row_id]+residuals_z[row_id])/inst.mu/inst.rownorms[row_id]));
			update_z[i] += Aji * resmod;
		}
		update_z[i]+=inst.c[coordinate];

	        if ((L)grad.size()>=nbcoord)
		    grad[i]=update_z[i];

		update_z[i] = max(inst.lowerbound[coordinate], min(inst.upperbound[coordinate], compute_soft_treshold(1./(1./Lintau[idx]*theta+inst.lambda2)* inst.lambda,
				1./(1.+inst.lambda2*Lintau[idx]/theta)*zi - update_z[i]/(1./Lintau[idx]*theta+inst.lambda2) ))) - zi;
	     }
	}


	static inline void compute_grad_xph_accel(const problem_data<L, D> &inst, D theta,
					const std::vector<D> &originalresiduals_w, const std::vector<D> &originalresiduals_z, const L idx, const D omega_S,
					const std::vector<D> &Li, const std::vector<D> &update_z, std::vector<D> &gradient_xph) {	


    	   L nbcoord=inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx];
	   D ck=-(1.-inst.n/(D)inst.tau*theta)/(theta*theta);
//#pragma omp parallel for if (nbcoord>=inst.tau) 
	   for (L i=0; i<nbcoord; i++)
             {			
	        L coordinate=inst.blocks_ptr[idx]+i;
	    	gradient_xph[i] = 0; //compute partial derivative f_idx'(x+h e_idx) where h=omega_S*update_x
		D theta2=theta*theta;

		for (L k = inst.A_csc_col_ptr[coordinate]; k < inst.A_csc_col_ptr[coordinate + 1]; k++) {
			L row_id = inst.A_csc_row_idx[k];
			D Aji=inst.A_csc_values[k];		
		    	D resmod_xph=std::max(-1.,std::min(1.,( 
					theta2*(originalresiduals_w[row_id]+ck*omega_S*update_z[i]*Aji)+(originalresiduals_z[row_id]+omega_S*update_z[i]*Aji) 
						)/inst.mu/inst.rownorms[row_id]));
			gradient_xph[i] += Aji*resmod_xph;
		}

	     }


	}




static inline D compute_fast_objective(const problem_data<L, D> &inst,
					 const std::vector<D> &residuals)
{
     return   compute_fast_objective(inst, residuals, inst.x);
}


	static inline D compute_fast_objective(const problem_data<L, D> &inst,
			const std::vector<D> &residuals, const std::vector<D> & x) {
		D resids = 0;
		D sumx = 0;
		D sumx2 = 0;
		D linpart = 0;

#pragma omp parallel for reduction(+:resids)
		for (L j = 0; j < inst.m; j++) {
			resids += inst.rownorms[j]*psimu<D>(abs(residuals[j]/inst.rownorms[j]), inst.mu);
		}
#pragma omp parallel for reduction(+:sumx)
		for (L i = 0; i < inst.N; i++) {
			sumx += abs(x[i]);
		}
#pragma omp parallel for reduction(+:sumx2)
		for (L i = 0; i < inst.N; i++) {
			sumx2 += x[i]*x[i];
		}
#pragma omp parallel for reduction(+:linpart)
		for (L i = 0; i < inst.N; i++) 
			linpart += inst.c[i]*x[i];

//cout << resids << "+" << inst.lambda << "*" << sumx<< "+"<< inst.lambda2/2<<"*"<< sumx2 <<"+" << linpart<< "=" << resids + inst.lambda * sumx +inst.lambda2/2. * sumx2 +linpart<< endl;
		return resids + inst.lambda*sumx + inst.lambda2/2.*sumx2 + linpart;
	}


	static inline void compute_reciprocal_lipschitz_constants(
			problem_data<L, D> &inst, std::vector<D> &h_Li) {


	  transpose_matrix(inst);

    	  std::vector<L> omega_j(inst.m,0);

	  inst.omega=0;
    	  for (L j = 0; j < inst.m; j++) {
      	    for (L k = inst.A_csr_row_ptr[j]; k < inst.A_csr_row_ptr[j+1]; k++) {   
	      omega_j[j]=inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j];
	    }
 	    inst.omega=max(inst.omega, omega_j[j]);
	  }
		//for (L j = 0; j < inst.m; j++) 
 		//	omega_j[j]=inst.omega;  // old stepsizes

	  inst.epsilon=0.1; //inst.N/10000.;
	
	  D rownormsum=0;
	  inst.rownorms.resize(inst.m);
#pragma omp parallel for reduction(+:rownormsum)
	  for (L j = 0; j < inst.m; j++) {
	    inst.rownorms[j] = 0;
	    for (L k = inst.A_csr_row_ptr[j];
		 k < inst.A_csr_row_ptr[j + 1]; k++) {
	      inst.rownorms[j]+=inst.A_csr_values[k] * inst.A_csr_values[k];
	    }
	    inst.rownorms[j]=sqrt(inst.rownorms[j]);
	    inst.rownorms[j]=max(inst.rownorms[j], 1e-16);
	    rownormsum+=inst.rownorms[j];
	  }
	  inst.mu=inst.epsilon/2*2/rownormsum;

	  cout << "epsilon=" << inst.epsilon << ", mu=" << inst.mu<< endl;

	  L tau = inst.tau;
	  if (inst.n==1){
	     h_Li.resize(inst.N);
	     tau=inst.N;
 	  }
	     

	  for (L i = 0; i < inst.N; i++) {
	    h_Li[i] = 0;
	    for (L k = inst.A_csc_col_ptr[i];
		 k < inst.A_csc_col_ptr[i + 1]; k++) {
 	      L j = inst.A_csc_row_idx[k];
	      h_Li[i] += inst.A_csc_values[k] * inst.A_csc_values[k] / inst.rownorms[inst.A_csc_row_idx[k]]
				* (1.+(omega_j[j])*(tau-1.)/max(1., inst.N-1.));
	    }
	    if (h_Li[i] > 0)
	      h_Li[i] = inst.mu / h_Li[i]; // Compute reciprocal Lipschitz Constants
	    else
	      h_Li[i] = 1e16;
	  }
		
	  inst.sigma=1;
	  inst.lipschitz=1;
	  //Here, the dual norm is a weighted 2-norm, so we do not need to change beta(=sigma)

	}
};

#endif /* ONENORM_LOSS_H */
