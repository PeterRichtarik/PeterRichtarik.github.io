/*
 * O. Fercoq 28/05/2013
 */

#ifndef LOAD_FILE_H_
#define LOAD_FILE_H_



template<typename D, typename L>
void transpose_matrix(problem_data<L, D> &inst) {

/// Transposition of the matrix

cout << "Transposition of the matrix.\n";

inst.A_csr_row_ptr.resize(inst.m+1);
#pragma omp parallel for
for (L j=0; j<inst.m+1; j++)
  inst.A_csr_row_ptr[j]=0;

vector<L> Cjc2;
Cjc2.resize(inst.m+1);
#pragma omp parallel for
for (L j=0; j<inst.m+1; j++)
  Cjc2[j]=0;

L nnz = inst.total_n;

inst.A_csr_col_idx.resize(nnz);
inst.A_csr_values.resize(nnz);

//Determination of the number of nonzero elements for each line (1st scan)
for (L k=0; k<nnz; k++)
  inst.A_csr_row_ptr[inst.A_csc_row_idx[k]+1]++;

for (L j=0; j<inst.m; j++)
  inst.A_csr_row_ptr[j+1]+=inst.A_csr_row_ptr[j];

//Filling of the other fields (2nd scan)
for (L i=0; i<inst.N; i++)
  for (L k=inst.A_csc_col_ptr[i]; k< inst.A_csc_col_ptr[i+1]; k++)
     {
      inst.A_csr_col_idx[inst.A_csr_row_ptr[inst.A_csc_row_idx[k]]+Cjc2[inst.A_csc_row_idx[k]]]=i;
      inst.A_csr_values[inst.A_csr_row_ptr[inst.A_csc_row_idx[k]]+Cjc2[inst.A_csc_row_idx[k]]]=inst.A_csc_values[k];
      Cjc2[inst.A_csc_row_idx[k]]++;  //Counts the number of entries already found in the row.
     }

cout << "Transposed matrix: "<<   inst.N << " " << inst.m << " " <<nnz << endl;

}


/*
 *  This function generates problem from the files filenamematrix and filenamevector
 */
template<typename D, typename L>
void load_file(problem_data<L, D> &inst, const char* filenamematrix, const char* filenamevector, 
		std::vector<gsl_rng *>& rs, ofstream& histrogramLogFile, int infnorm=0) {

//cout << "Loading data: " << filenamematrix << " " << filenamevector << endl;

char mystring [100];
FILE* pFile;

/// Loading the matrix

pFile=fopen(filenamematrix, "r");
 if (pFile == NULL) perror ("Error opening file");
   else {
if ( fgets (mystring , 100 , pFile) != NULL )
  inst.N=(L)atof(mystring);
if ( fgets (mystring , 100 , pFile) != NULL )
  inst.m=(1+infnorm)*(L)atof(mystring);
if ( fgets (mystring , 100 , pFile) != NULL )
  inst.total_n=(1+infnorm)*(L)atof(mystring);

inst.n=inst.N;

inst.blocks_ptr.resize(inst.n+1);
for (L k=0; k<inst.n+1; k++)
 	inst.blocks_ptr[k]=k;


cout << "N=" <<inst.n << ", n=" <<inst.n << ", m="<< inst.m << ", nnz(A)=" << inst.total_n << endl;


L nnz=inst.total_n;
inst.A_csc_col_ptr.resize(inst.n+1);
inst.A_csc_row_idx.resize(nnz);
inst.A_csc_values.resize(nnz);

L k=0;
if (infnorm==0)
while ( fgets (mystring , 100 , pFile) != NULL ){
	if (k<inst.n+1){
   	   inst.A_csc_col_ptr[k]=(L)atof(mystring);
           k++;}
	else if (k<inst.n+1+nnz){
	  inst.A_csc_row_idx[k-inst.n-1]=(L)atof(mystring);
           k++;}
	else if (k<inst.n+1+2*nnz){
	   inst.A_csc_values[k-nnz-inst.n-1]=atof(mystring);
           k++;}
}
else
{
cout << "Doubling the size of the matrix for the infinity norm problem.\n";
while ( fgets (mystring , 100 , pFile) != NULL ){
	if (k<inst.n+1){
   	   inst.A_csc_col_ptr[k]=2*(L)atof(mystring);
           k++;}
	else if (k<inst.n+1+nnz){
	  inst.A_csc_row_idx[k-inst.n-1]=(L)atof(mystring);
	  inst.A_csc_row_idx[k-inst.n]=inst.m/2+(L)atof(mystring);
           k+=2;}
	else if (k<inst.n+1+2*nnz){
	   inst.A_csc_values[k-nnz-inst.n-1]=atof(mystring);
	   inst.A_csc_values[k-nnz-inst.n]=-atof(mystring);
           k+=2;}
}
}

if (k<inst.n+1+2*nnz)
	cout << "Corrupted matrix file:" << k << "<" << inst.n+1+2*nnz<< endl;
fclose (pFile);



/// Loading the vector
inst.b.resize(inst.m);


pFile=fopen(filenamevector, "r");

  L i=0;
  if (pFile == NULL) perror ("Error opening file");
  else {
    while ( fgets (mystring , 100 , pFile) != NULL ){
      if (i>inst.m){
	perror ("wrong size of vector"); break;}
      inst.b[i]=atof(mystring);
      if (infnorm==1)
	inst.b[i+inst.m/2]=-atof(mystring);
      i++;
    }
  }

if (i!=inst.m/(1+infnorm))
   cout << "Attention! the sizes of the matrix (" << inst.m << "x" << inst.N <<") and of the vector ("<< i << ") do not match.\n";

fclose (pFile);

/// Computation of omega

transpose_matrix(inst);

inst.omega=0;
for (L j=0; j<inst.m; j++)
  {
    if (inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j]>inst.omega)
	inst.omega=inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j];
  }


/*
The other parameters of the problem are computed, if necessary in the function 
Losses<L, D, loss_traits>::compute_reciprocal_lipschitz_constants(inst, h_Li);
	D sigma;
	D mu;
	D epsilon;
	std::vector<D> rownorms;
	std::vector<D> colnorms;

*/

}
}


#endif // LOAD_FILE_H_

