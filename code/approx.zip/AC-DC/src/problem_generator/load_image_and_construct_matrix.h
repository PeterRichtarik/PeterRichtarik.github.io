/*
 * O. Fercoq 28/05/2013
 */

#ifndef LOAD_IMAGE_AND_CO_H_
#define LOAD_IMAGE_AND_CO_H_


/*
 *  This function generates tv problem from the image in filename stored as a vector
 */
template<typename D, typename L>
void load_image_and_construct_diff_matrix(problem_data<L, D> &inst, const char* filename_params, const char* filename_image) {

char mystring [100];
FILE* pFile;

pFile=fopen(filename_params, "r");  // width, height
L width=0;
L height=0;

if (pFile == NULL) perror ("Error opening file");
else {
      fgets (mystring , 100 , pFile);
      height=atof(mystring);

      fgets (mystring , 100 , pFile);
      width=atof(mystring);

    }

fclose(pFile);

/// Loading the vector
inst.m=width*height;
inst.b.resize(inst.m);

pFile=fopen(filename_image, "r");

  L i=0;
  if (pFile == NULL) perror ("Error opening file");
  else {
    while ( fgets (mystring , 100 , pFile) != NULL ){
      if (i>inst.m){
	perror ("wrong size of vector, too big"); break;}
      inst.b[i]=atof(mystring);
      i++;
    }
  if (i<inst.m)
    perror ("wrong size of vector, too small"); 
  }

fclose(pFile);

/// Creating the matrix

inst.N=2*inst.m;

inst.total_n=4*inst.m-width-height;

cout << "N=" <<inst.N << ", m="<< inst.m << ", nnz(A)=" << inst.total_n << endl;


L nnz=inst.total_n;
inst.A_csc_col_ptr.resize(inst.N+1);
inst.A_csc_row_idx.resize(nnz);
inst.A_csc_values.resize(nnz);

L k=0;
inst.A_csc_col_ptr[0]=0;
for (L i=0; i<inst.m; i++){
	k=inst.A_csc_col_ptr[2*i];

	inst.A_csc_row_idx[k]=i;
	inst.A_csc_values[k]=-1.;
	k++;
	if (i+height<inst.m)
	{
		inst.A_csc_row_idx[k]=i+height;
		inst.A_csc_values[k]=1.;
		k++;
	}
	inst.A_csc_col_ptr[2*i+1]=k;

	inst.A_csc_row_idx[k]=i;
	inst.A_csc_values[k]=-1.;
	k++;
	if (i%height != height-1)
	{
		inst.A_csc_row_idx[k]=i+1;
		inst.A_csc_values[k]=1.;
		k++;
	}
	inst.A_csc_col_ptr[2*i+2]=k;
}

if (inst.A_csc_col_ptr[inst.N]!=inst.total_n)
	cout << "Corrupted matrix file:" << inst.A_csc_col_ptr[inst.N] << "!=" << inst.total_n<< endl;

/// Computation of omega

transpose_matrix(inst);

inst.omega=0;
for (L j=0; j<inst.m; j++)
  {
    if (inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j]>inst.omega)
	inst.omega=inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j];
  }

/// Set inst.c to 0 and upper and lower bounds to Inf

inst.c.resize(inst.N, 0.);
inst.upperbound.resize(inst.N, numeric_limits<D>::max());
inst.lowerbound.resize(inst.N, -numeric_limits<D>::max());

/*
The other parameters of the problem are computed, if necessary in the function 
Losses<L, D, loss_traits>::compute_reciprocal_lipschitz_constants(inst, h_Li);
	D sigma;
	D mu;
	D epsilon;
	std::vector<D> rownorms;
	std::vector<D> colnorms;

*/

}



/*
 *  This function generates tgv2 problem from the image in filename stored as a vector
 */
template<typename D, typename L>
void load_image_and_construct_tgv2_matrix(problem_data<L, D> &inst, const char* filename_params, const char* filename_image) {

char mystring [100];
FILE* pFile;

pFile=fopen(filename_params, "r");  // width, height
L width=0;
L height=0;

if (pFile == NULL) perror ("Error opening file");
else {
      fgets (mystring , 100 , pFile);
      height=atof(mystring);

      fgets (mystring , 100 , pFile);
      width=atof(mystring);

    }

fclose(pFile);

/// Loading the vector
L imagesize=width*height;
inst.m=7*imagesize;
inst.b.resize(inst.m,0.);

cout << "image size: "<<imagesize<< " pixels." <<endl;

pFile=fopen(filename_image, "r");

  L i=0;
  if (pFile == NULL) perror ("Error opening file");
  else {
    while ( fgets (mystring , 100 , pFile) != NULL ){
      if (i>imagesize){
	perror ("wrong size of vector, too big"); break;}
      inst.b[7*i]=atof(mystring);  
      i++;
    }
  if (i<imagesize)
    perror ("wrong size of vector, too small"); 
  }
// the rest of vector b is 0.


fclose(pFile);

/// Creating the matrix

// A=[I 0 0 ; -nabla1 I 0; -nabla2 0 I; 0 -nabla1 0; 0 -nabla2 0; 0 0 -nabla1; 0 0 -nabla2] where the true blocking is in [u_i, w_{1,i}, w_{2,i}] for function value evaluation efficiency.

inst.N=3*imagesize;

inst.total_n=3*(4*imagesize-width-height)+3*imagesize; // 3 gradients and 3 identities  

cout << "N=" <<inst.N << ", m="<< inst.m << ", nnz(A)=" << inst.total_n << endl;


L nnz=inst.total_n;
inst.A_csc_col_ptr.resize(inst.N+1);
inst.A_csc_row_idx.resize(nnz);
inst.A_csc_values.resize(nnz);

L k=0;
inst.A_csc_col_ptr[0]=0;
for (L i=0; i<imagesize; i++){
   for (L uw1w2=0; uw1w2<3; uw1w2++)  {
	k=inst.A_csc_col_ptr[3*i+uw1w2];
	
	if (i-height>=0)
	{
		inst.A_csc_row_idx[k]=7*(i-height)+1+2*uw1w2;
		inst.A_csc_values[k]=-1.;
		k++;
	}
	if (i%height != 0)
	{
		inst.A_csc_row_idx[k]=7*(i-1)+2+2*uw1w2;
		inst.A_csc_values[k]=-1.;
		k++;
	}
	inst.A_csc_row_idx[k]=7*i+uw1w2;
	inst.A_csc_values[k]=1.;
	k++;
	
	inst.A_csc_row_idx[k]=7*i+1+2*uw1w2;
	inst.A_csc_values[k]=1.;
	k++;

	inst.A_csc_row_idx[k]=7*i+2+2*uw1w2;
	inst.A_csc_values[k]=1.;
	k++;
	inst.A_csc_col_ptr[3*i+uw1w2+1]=k;


    }
}

cout << "matrix built.\n";

if (inst.A_csc_col_ptr[inst.N]!=inst.total_n)
	cout << "Corrupted matrix file:" << inst.A_csc_col_ptr[inst.N] << "!=" << inst.total_n<< endl;

/// Computation of omega

transpose_matrix(inst);

inst.omega=0;
for (L j=0; j<inst.m; j++)
  {
    if (inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j]>inst.omega)
	inst.omega=inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j];
  }

/// Set inst.c to 0 and upper and lower bounds to Inf

inst.c.resize(inst.N, 0.);
inst.upperbound.resize(inst.N, numeric_limits<D>::max());
inst.lowerbound.resize(inst.N, -numeric_limits<D>::max());



  for (L i=0; i<inst.N;i+=3)
 { inst.lowerbound[i]=0; inst.upperbound[i]=255.;}

/*
The other parameters of the problem are computed, if necessary in the function 
Losses<L, D, loss_traits>::compute_reciprocal_lipschitz_constants(inst, h_Li);
	D sigma;
	D mu;
	D epsilon;
	std::vector<D> rownorms;
	std::vector<D> colnorms;

*/

}


#endif // LOAD_IMAGE_AND_CO_H_

