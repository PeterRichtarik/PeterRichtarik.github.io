/*
 * This file contains an experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */




#include "../helpers/c_libs_headers.h"
#include "../helpers/gsl_random_helper.h"

#include "../solver/structures.h"
#include "../class/loss/losses.h"
#include "../problem_generator/generator_nesterov.h"
#include "../problem_generator/load_file.h"


enum AlgorithmType {
 GRADIENT,
 COORDINATE_DESCENT,
 ACCELERATED_GRADIENT,
 ACCELERATED_COORDINATE_DESCENT
};


template<typename L, typename D, typename traits>
void run_computation(problem_data<L, D> &inst, std::vector<D> &h_Li,
		double fvalOpt, int omp_threads, L n, L m, L sigma, int N,
		int blockReduction, std::vector<gsl_rng *>& rs,
		ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm) {

	double MAXTIME = N;

	for (L i = 0; i < inst.n; i++)
		inst.x[i] = 0;

	if ((algorithm==GRADIENT) || (algorithm==ACCELERATED_GRADIENT))
	{
		D Lip=inst.omega;//
		inst.update.resize(inst.n);
		inst.z.resize(inst.n);
		for (int i=0; i<inst.n; i++)
			h_Li[i]=(inst.sigma/Lip)*h_Li[i];
		for (int i=0; i<inst.n; i++)
			inst.z[i]=inst.x[i];
	}
	D theta=1;

	omp_set_num_threads(omp_threads);
	init_random_seeds(rs);
	std::vector<D> residuals(inst.m);

	Losses<L, D, traits>::recompute_residuals(inst, residuals);
	D fvalInit = Losses<L, D, traits>::compute_fast_objective(inst,
			residuals);
	double totalRunningTime = 0;
	double iterations = 0;
	int nbaff=1;
	int totalIt=0;
	L perPartIterations = inst.n / blockReduction;
	double additional = perPartIterations / (0.0 + inst.n);
	D fval = fvalInit;
// store initial objective value
	cout << setprecision(16) << omp_threads << "," << inst.n << "," << inst.m
			<< "," << inst.sigma << "," << totalRunningTime << "," << iterations
			<< "," << fval << endl;
	experimentLogFile  << setprecision(16) << omp_threads << "," << inst.n << ","
				<<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
				<< iterations << "," << fval << "," << fvalOpt << "," <<0<<",0"
				<< endl;

	//iterate
	while (totalRunningTime<MAXTIME) {
		double startTime = gettime_();

		if ((algorithm==GRADIENT) || (algorithm==ACCELERATED_GRADIENT))
		{
			if (algorithm==ACCELERATED_GRADIENT) { // y=(1-theta)x + theta z
#pragma omp parallel for
				for (L i = 0; i < inst.n; i++) {
					inst.update[i]=theta*(inst.z[i]-inst.x[i]);
//					Losses<L, D, traits>::do_single_update_parallel(
//							inst, i, residuals, inst.x, inst.update, h_Li);
				}

			}
#pragma omp parallel for
			for (L i = 0; i < inst.n; i++) {  // compute descent update
				inst.update[i]=Losses<L, D, traits>::compute_update(inst, residuals, i, h_Li);
			}
#pragma omp parallel for
			for (L i = 0; i < inst.n; i++) { // update y to get x
//				Losses<L, D, traits>::do_single_update_parallel(//
//							inst, i, residuals, inst.x, inst.update, h_Li);
			}
			if (algorithm==ACCELERATED_GRADIENT) {  // update z. Implementation only for smooth function
#pragma omp parallel for
				for (L i = 0; i < inst.n; i++) {
					inst.z[i] += inst.update[i]/theta;
				}
				D theta2=theta*theta;
			  	theta=0.5*sqrt(theta2*theta2+4*theta2)-0.5*theta2;
			}


		}
		else if (algorithm==COORDINATE_DESCENT)
		{
			// Dynamic schedule because the master makes more work
			//L chunk=perPartIterations/inst.tau/10;
#pragma omp parallel for
			for (L it = 0; it < perPartIterations; it++) {
				// one step of the algorithm
				unsigned long int idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);
						Losses<L, D, traits>::do_single_iteration_parallel(
							inst, idx, residuals, inst.x, h_Li);
			}
		}
		
		double endTime = gettime_();
		iterations += additional;
		totalRunningTime += endTime - startTime;
		// recompute residuals  - this step is not necessary but if accumulation of rounding errors occurs it is useful
		D fval__ = Losses<L, D, traits>::compute_fast_objective(inst,
				residuals);  // What are rounding errors like?
		if ((totalIt % 3 == 0) || ((abs(algorithm)!=1)&&(inst.mu==inst.epsilon/log(inst.m))) ) {
			Losses<L, D, traits>::recompute_residuals(inst,
					residuals);
		}
		fval = Losses<L, D, traits>::compute_fast_objective(inst,
				residuals);
		L nnz = 0;
		D wnorm=0;
#pragma omp parallel for reduction(+:nnz) reduction(+:wnorm)
		for (L i = 0; i < inst.n; i++)
			if (inst.x[i] != 0)
			   {
				nnz++;
				wnorm+=inst.x[i]*inst.x[i]/h_Li[i]/inst.sigma;
			   }
		wnorm=sqrt(wnorm);

		if ((totalRunningTime>nbaff) || (totalIt%1000==0)){		
cout << setprecision(5)<< omp_threads << "," << inst.n << ","
				<<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
				<< iterations << "," << fval << "," << fval__ << "," << fvalOpt << "," << nnz << ","
				<< wnorm << endl;
			nbaff++;
		}

		experimentLogFile << setprecision(16) << omp_threads << "," << inst.n << ","
				<<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
				<< iterations << "," << fval << "," << fvalOpt << "," << nnz << ","
				<< wnorm << endl;

if(totalIt==10000)
	break;
		totalIt++;
	}
cout << setprecision(5)<< omp_threads << "," << inst.n << ","
				<<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
				<< iterations << "," << fval << "," << fvalOpt << endl;

}

template<typename L, typename D, typename traits>
void run_experiment(const char* filenameMatrix, const char* filenameVector, int N, int blockReduction,
		std::vector<gsl_rng *>& rs, ofstream & histogramLogFile,
		ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm) {

	problem_data<L, D> inst;
	omp_set_num_threads(MAXIMUM_THREADS);
	init_random_seeds(rs);

//	double fvalOpt = nesterov_generator(inst, n, m, sigma, rs,
//			histogramLogFile);
//	inst.lambda = 1;

//load_file(inst, "/data/fercoq/MaliciousURLs/matriceadaboostcomp.mat", "/data/fercoq/MaliciousURLs/vectoradaboost.mat", rs, histogramLogFile);
	load_file(inst, filenameMatrix, filenameVector, rs, histogramLogFile);
	
	inst.lambda=0;

//for (int j=0; j<inst.m;j++)   // For adaboost
//	inst.b[j]=0;



	double fvalOpt=0;

	std::vector<D> h_Li(inst.n, 0);
	//-------------- set the number of threads which should be used.
	int TH[1] = {8 };
	for (int i = 0; i < 1; i++) {
		cout << "Running experiment with " << TH[i] << " threads" << endl;
		inst.tau=TH[i];
		inst.sigma = 1. + (TH[i] - 1.) * (inst.omega - 1.) / (inst.n - 1.);  // 1. instead of 1 to avoid Euclidean division.
		cout << setprecision(16) << "omega=" << inst.omega << ", beta = " << inst.sigma << endl;
		Losses<L, D, traits>::compute_reciprocal_lipschitz_constants(
				inst, h_Li);

		/*inst.reduction_vector=(D*)malloc(inst.tau*sizeof(D));  
		omp_set_num_threads(TH[i]);
		#pragma omp parallel for
		for (int k=0; k<inst.tau; k++){
			int proc=omp_get_thread_num();
			inst.reduction_vector[proc]=0;  //Lets the memory slot be located in the good cache.
		}*/

		// run the experiment
		run_computation<L, D,traits>(inst, h_Li, fvalOpt, TH[i], inst.n, inst.m, inst.sigma, N, 1, rs,
				experimentLogFile, MAXIMUM_THREADS, algorithm);

		//free(inst.reduction_vector);
	}
}

int main(int argc, char * argv[]) {

	// setup GSL random generators
	gsl_rng_env_setup();
	const gsl_rng_type * T;
	gsl_rng * r;
	T = gsl_rng_default;
	r = gsl_rng_alloc(T);
	const int MAXIMUM_THREADS = 24;
	std::vector<gsl_rng *> rs(MAXIMUM_THREADS);
	for (int i = 0; i < MAXIMUM_THREADS; i++) {
		rs[i] = gsl_rng_alloc(T);
		gsl_rng_set(rs[i], i);
	}
	init_omp_random_seeds();
	//---------------------- Setting parameters of experiment
	string filenameMatrix="/home/ofercoq/datasets/matrix_w8a";
	string filenameVector="/home/ofercoq/datasets/vector_w8a";
	AlgorithmType algorithm = COORDINATE_DESCENT;

	//---------------------- Set output files
	ofstream histogramLogFile;
	histogramLogFile.open("results/large_scale_experiment_histogram.log");
	ofstream experimentLogFile;
	experimentLogFile.open("results/experiment_w8a_coordesc.log");
	//--------------------- run experiment - one can change precision here
	run_experiment<long long, double, exp_loss_traits>(filenameMatrix.c_str(), filenameVector.c_str(), 36000, 1, rs, histogramLogFile,
			experimentLogFile, MAXIMUM_THREADS, algorithm);
	histogramLogFile.close();
	experimentLogFile.close();	
	return 0;
}
