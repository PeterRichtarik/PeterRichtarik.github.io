/*
 * This file contains an experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */


#define OUTSIDELOOP

#include "../helpers/c_libs_headers.h"
#include "../helpers/gsl_random_helper.h"

#include "../solver/structures.h"
#include "../class/loss/losses.h"
#include "../problem_generator/generator_nesterov.h"
#include "../problem_generator/load_file.h"

#include <limits>
#include <stdint.h>


enum AlgorithmType {
  GRADIENT,
  COORDINATE_DESCENT,
  ACCELERATED_GRADIENT,
  ACCELERATED_COORDINATE_DESCENT,
  GREEDY
};

enum restartingStrat {
  NONE,
  FIXED_THETA,
  OPTIMAL,
  ADAPTIVE,
  FIXED_THETA_F
};

enum ProblemType {
  LASSO,
  SVM_DUAL,
  SVM_PRIMAL,
  INF_NORM,
  ONE_NORM,
  ADABOOST,
  LOGISTIC
};


//#define SYNCHRONOUS

template<typename L, typename D, typename traits>
void run_computation(problem_data<L, D> &inst, std::vector<D> &h_Li,
		     double fvalOpt, int omp_threads, L n, L m, L sigma, int N,
		     int blockReduction, std::vector<gsl_rng *>& rs,
		     ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm, ProblemType problem) {

  double MAXTIME = N;

  L compxz=1;
  if (compxz==1)
     cout << "Choosing the best between x and z at every pass through data.\n";
 

  D maxLi=0;
  for (L idx = 0 ; idx < inst.n ; idx++)
     maxLi=max(maxLi, 1./h_Li[idx]);

  D lambda2tmp = inst.lambda2;

  D theta=0;
  D tauovern=min(1., (D)inst.tau/(D)inst.n);  // if we have accelerated gradient, we should take tau=n=1 but we parallelize linear algebra.
  if (algorithm==ACCELERATED_COORDINATE_DESCENT)
    {
      for (L idx=0; idx<inst.n; idx++)
	h_Li[idx]=h_Li[idx]*tauovern;
    }

if ((algorithm==GRADIENT)||(algorithm==ACCELERATED_GRADIENT)) {
    inst.blocks_ptr.resize(inst.N+1);
    for (L k=0; k<inst.N+1; k++)
 	inst.blocks_ptr[k]=k;
}
  omp_set_num_threads(omp_threads);
  init_random_seeds(rs);


//for (int expe=0; expe< (algorithm==ACCELERATED_COORDINATE_DESCENT ? 5:1); expe++) 
for (int expe=0; expe< 1; expe++) 
{

  restartingStrat restart;
  if (expe==0) restart=NONE;
  else if (expe==1) restart=FIXED_THETA;
  else if (expe==2) restart=OPTIMAL;
  else if (expe==3) restart=ADAPTIVE;
  else if (expe==4) { restart=FIXED_THETA_F;}
  

  if (restart==FIXED_THETA_F)
    { 
       inst.mupsi = 0;
       inst.lambda2f=lambda2tmp;
       inst.lambda2=0;
       for (L idx = 0 ; idx<inst.n; idx++)
	  h_Li[idx] = tauovern/(tauovern/h_Li[idx]+inst.lambda2f);
       maxLi = maxLi + inst.lambda2f;
       inst.muf = inst.lambda2f/maxLi;
    }
  else
    {
       inst.lambda2f=0;
       inst.muf = 0;
       inst.lambda2=lambda2tmp;
       inst.mupsi = inst.lambda2/maxLi;
    }

cout << "strongconvcoeff=" << inst.mupsi+inst.muf << ", maxLi=" << maxLi << endl;


  inst.x.resize(inst.N);
  for (L i = 0; i < inst.N; i++)
    inst.x[i] = 0;

  if ((algorithm==ACCELERATED_COORDINATE_DESCENT) || (algorithm==ACCELERATED_GRADIENT))
    {
      theta=tauovern;  
      inst.z.resize(inst.N);
      inst.w.resize(inst.N);
      for (int i=0; i<inst.N; i++)
	inst.z[i]=inst.x[i];
      for (int i=0; i<inst.N; i++)
	inst.w[i]=0;
    }

  if ((restart!=FIXED_THETA)&&(restart!=FIXED_THETA_F)) {
     inst.mupsi = inst.mupsi+inst.muf;  // Hence, we only deal with one single number and we can have one single line for the update of w.
     inst.muf=0;
   }

#ifdef OUTSIDELOOP
  if (inst.n==1)
    cout << "Please define OUTSIDELOOP for parallel computing.\n";
#endif
#ifndef OUTSIDELOOP
  if (inst.n>1)
    cout << "Please remove definition of OUTSIDELOOP for parallel computing.\n";
#endif

  std::vector<D> residuals;	
  std::vector<D> residuals_w;
  std::vector<D> residuals_z;
  std::vector<D> m_zeros(inst.m,0);

  residuals.resize(inst.m);
  if ((algorithm==ACCELERATED_COORDINATE_DESCENT) || (algorithm==ACCELERATED_GRADIENT))
    {
      residuals_w.resize(inst.m);  
      Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  //0 to remove the -b in the residuals.
      residuals_z.resize(inst.m);  		
      Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);

      for (L j=0; j<inst.m; j++)
	residuals[j]=theta*theta*residuals_w[j]+residuals_z[j];
      for (L i=0; i<inst.N; i++)
	inst.x[i]=theta*theta*inst.w[i]+inst.z[i];
    }
  else
    Losses<L, D, traits>::recompute_residuals(inst, residuals, inst.x, inst.b);

  cout << inst.normalization_factor << endl;
  D fvalInit = Losses<L, D, traits>::compute_fast_objective(inst, residuals);


  if (algorithm==GREEDY) {
     for (L idx=0; idx<inst.n; idx++)
	h_Li[idx]*=inst.sigma;
  }

  L maxblocksize=0;
  for (L idx=0; idx<inst.n; idx++)
	maxblocksize=max(maxblocksize, inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]);
	

  double totalRunningTime = 0;
  double iterations = 0;
  int nbaff=1;
  int totalIt=0;
  L perPartIterations;
//  if (SYNCHRONOUS==1)
//	perPartIterations = inst.tau;
//  else
	perPartIterations = inst.n / blockReduction;

  L iterationsPerLoop = inst.n / perPartIterations;
  double additional = iterationsPerLoop * perPartIterations / (0.0 + inst.n);
  D fval = fvalInit;
  // store initial objective value
  cout << setprecision(16) << omp_threads << "," << inst.n << "," << inst.m
       << "," << inst.sigma << "," << totalRunningTime << "," << iterations
       << "," << fval << endl;
  experimentLogFile  << setprecision(16) << omp_threads << "," << inst.n << ","
		     <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
		     << iterations << "," << fval << "," << fvalOpt << "," <<0<<",0,0,0,"<< inst.lambda << ","<<restart 
		     << endl;

  D test=0;
  D gamma=1;

  //iterate
  while (totalRunningTime<MAXTIME) {
    double startTime = gettime_();

    for (L itersync=0; itersync<iterationsPerLoop; itersync++) {
     if (algorithm==GREEDY)
      {
	std::vector<D> grad(inst.N);
#pragma omp parallel
	for (L idx=0; idx<inst.n; idx++) {
		std::vector<D> update(1);
		Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update);
		grad[idx]=update[0];
        }
	
	D max_element=-1;
	L istar=0;
#pragma omp parallel
	{
	  D max_element_proc=-1;  // Local variables for the max-reduction
	  L istar_proc=0;
#pragma omp for
	  for (L i = 0; i < inst.N; i++) {
	    D absgradi = std::abs(grad[i]);
	    if (max_element_proc<absgradi) {
		max_element_proc=absgradi;
		istar_proc=i;
	    } //end if
	  }  //end for			
#pragma omp critical
	  {
	    if (max_element < max_element_proc) {
		max_element=max_element_proc;
		istar=istar_proc;
	    }  //end if
	  }  //end critical
	}  //end parallel
	Losses<L, D, traits>::do_single_iteration_serial(inst, istar, residuals, inst.x, h_Li, grad[istar]);	  
      } // end if GREEDY
    else if (algorithm==GRADIENT)
      {
        std::vector<D> update(inst.N);
#pragma omp parallel for 
	for (L i =0; i<inst.N; i++)   
	{
	  std::vector<D> upi(1);
    	  Losses<L, D, traits>::compute_update(inst, residuals, i, h_Li, upi);
	  update[i]=upi[0];
	}
#pragma omp parallel for 
	for (L i =0; i<inst.N; i++)    
	{
	  std::vector<D> upi(1);
	  upi[0]=update[i];
   	  Losses<L, D, traits>::do_single_update_parallel(inst, i, residuals, inst.x, h_Li, upi);
	}
      }    
     else if (algorithm==ACCELERATED_GRADIENT)
      {
        std::vector<D> update_z(inst.N);
#pragma omp parallel for 
	for (L i =0; i<inst.N; i++)   
	{
	  std::vector<D> upi_z(1);
    	  Losses<L, D, traits>::compute_update_accel(inst, theta, residuals_w, residuals_z, i, h_Li, upi_z);
	  update_z[i]=upi_z[0];
	}
	D ck = -(1.-1./tauovern*theta)/theta/theta;    
#pragma omp parallel for 
	for (L i =0; i<inst.N; i++)    
	{	 
 	   std::vector<D> upi_z(1);
 	   std::vector<D> upi_w(1);
	   upi_z[0]=update_z[i];
	   upi_w[0]=ck*update_z[i];

           Losses<L, D, traits>::do_single_update_parallel_accel(inst, i, residuals_w, residuals_z, h_Li, upi_w, upi_z);  //Efficient implementation for square loss and l1 
 	}
        D theta2=theta*theta;
        theta=0.5*sqrt(theta2*theta2+4*theta2)-0.5*theta2;
      }
    else if (algorithm==COORDINATE_DESCENT)
      {
#ifdef OUTSIDELOOP
#pragma omp parallel
#endif
{
        std::vector<D> update(maxblocksize);
#pragma omp for 
	for (L it = 0; it < perPartIterations; it++)   // one step of the algorithm
	{
	  unsigned long int idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);	    
    	  Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update);
   	  Losses<L, D, traits>::do_single_update_parallel(inst, idx, residuals, inst.x, h_Li, update);
	}
}
      }
    else if (algorithm==ACCELERATED_COORDINATE_DESCENT)
      {
	D iter_glob=iterations;
//	if (restart==FIXED_THETA)
//	   theta=min(tauovern, tauovern*(-strongconvcoeff/2+sqrt(strongconvcoeff*strongconvcoeff+4*strongconvcoeff)/2));
	//#define SYNCHRONOUS
	/*#ifdef SYNCHRONOUS
	  for (L it = 0; it < perPartIterations/inst.tau; it++) {
	  #pragma omp parallel
	  {
	  D theta_loc=theta;
	  D iter_loc=iterations;
	  #pragma omp for
	  for (L proc=0;proc<inst.tau; proc++){
	  #else*/
#ifdef OUTSIDELOOP
#pragma omp parallel 
#endif
	{
	  D iter_loc=iterations;
	  D theta_loc=theta;
	  D gamma_loc=gamma;
	  std::vector<D> update_z(maxblocksize);
	  std::vector<D> update_w(maxblocksize);
	  std::vector<D> nogradreturned(0);
	  L idx;

  // Either perPartIterations or nbcoord is large.
#pragma omp for 
	  for (L it = 0; it < perPartIterations; it++) {
	      //#endif

	      // one step of the algorithm

	      D theta2;
 	      if ((restart!=FIXED_THETA)&&(restart!=FIXED_THETA_F)) 
		theta2 = theta_loc*theta_loc;
	      else
		theta2 = max(gamma_loc, 1e-300);

	      D ck = -(1.-1./tauovern*theta_loc)/theta2;
	      
	      idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);

              Losses<L, D, traits>::compute_update_accel(inst, theta_loc, theta2, residuals_w, residuals_z, idx, h_Li, update_z, nogradreturned);

#ifndef OUTSIDELOOP
#pragma omp parallel for 
#endif
	      for (L i=0; i<inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]; i++)
		   update_w[i]=ck*update_z[i]-tauovern*inst.muf/theta_loc*inst.w[i]; 
	      if ((restart==FIXED_THETA)||(restart==FIXED_THETA_F))
		for (L i=0; i<inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]; i++)
		   update_z[i]+=tauovern*inst.muf/theta_loc*gamma_loc*inst.w[i]; 
//#ifdef SYNCHRONOUS
//	}
//	#pragma omp for
//	for (L it = 0; it < perPartIterations; it++) {
//#endif

	      Losses<L, D, traits>::do_single_update_parallel_accel(inst, idx, residuals_w, residuals_z, h_Li, update_w, update_z);  //Efficient implementation for square loss and l1 loss

	      //---------------------------
	      //#ifndef SYNCHRONOUS

	      if (restart==ADAPTIVE) {
		D tmp = -1./inst.n*test;
		for (L i=0; i<inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]; i++)	
		    {
			L coord=inst.blocks_ptr[idx]+i;
			tmp+= -tauovern*update_z[i]*(update_z[i]-theta*theta/(1-theta)*(inst.w[coord]-update_w[i]));
		    }
		parallel::atomic_add(test, tmp);
		
              }
	      else if (restart==OPTIMAL)
		parallel::atomic_add(test,1);

	      iter_glob=parallel::atomic_add(iter_glob, 1.);			

	        while(iter_loc<iter_glob)
		  {					
   	           if ((restart!=FIXED_THETA)&&(restart!=FIXED_THETA_F)) {
		      D theta2=theta_loc*theta_loc;
		      theta_loc=0.5*sqrt(theta2*theta2+4*theta2)-0.5*theta2;
		      iter_loc+=inst.tau;
                    }
		   else{
		      D theta2=theta_loc*theta_loc;
		      D a = -theta2/tauovern/tauovern-1./tauovern*inst.mupsi*(theta_loc+1)+inst.muf+inst.mupsi;
		      theta_loc=tauovern*tauovern*0.5*( sqrt(a*a+4*(theta2/pow(tauovern,4)+theta_loc/pow(tauovern,3)*inst.mupsi)) + a );
	 	      D lambda_k=(inst.n*theta_loc - inst.tau*inst.muf)/(inst.n - inst.tau*inst.muf);
		      gamma_loc *= (1-lambda_k);
		      iter_loc+=inst.tau;
                    }
		  }
		//#endif
		  //----------------------------
	    //#ifndef SYNCHRONOUS
	      //#endif
//cout << ck << endl;

		}  //end parallel for
#pragma omp critical
	     theta=min(theta,theta_loc);
#pragma omp critical
	     gamma=min(gamma, gamma_loc);

	}  //end parallel

      } // end if ACCELERATED
    } // end for itersync
    double endTime = gettime_();
    //if (algorithm!=ACCELERATED_COORDINATE_DESCENT)
	iterations += additional;
    totalRunningTime += endTime - startTime;
    startTime=gettime_();

    // recompute residuals  - this step is not necessary but if accumulation of rounding errors occurs it is useful
    if ((algorithm==ACCELERATED_COORDINATE_DESCENT)||(algorithm==ACCELERATED_GRADIENT))
      {
        D theta2x;
        if ((restart!=FIXED_THETA)&&(restart!=FIXED_THETA_F)) 
 	  theta2x = theta*theta/(1-theta);
	else  {
          D lambda_k=(inst.n*theta - inst.tau*inst.muf)/(inst.n - inst.tau*inst.muf);
	  theta2x = gamma/(1-lambda_k);
	}
#pragma omp parallel for
	for (L j=0; j<inst.m; j++)
	  residuals[j]=theta2x*residuals_w[j]+residuals_z[j];
#pragma omp parallel for
	for (L i=0; i<inst.N; i++)
	  inst.x[i]=theta2x*inst.w[i]+inst.z[i];
	if ( ((test>0)&&(restart==ADAPTIVE)) || ((test>0)&&(restart==OPTIMAL)) ) {
  	   startTime = gettime_();
	   cout << "Restarting." <<endl;
#pragma omp parallel for
 	   for (L i=0; i<inst.N; i++)
		inst.z[i]=theta2x*inst.w[i]+inst.z[i];
#pragma omp parallel for
 	   for (L i=0; i<inst.N; i++)
		inst.w[i]=0;
	   theta=tauovern;
	   if (restart==OPTIMAL){
	      test= -exp(1)*2./tauovern*sqrt(1.-tauovern+1./inst.mupsi)- (inst.n-inst.tau)/(D)inst.tau;   // Here, mupsi is mupsi+muf	 
	     // cout << test <<endl;
	    }
	   else test=-1;

	   endTime = gettime_();
	}
	totalRunningTime += endTime - startTime;

        if (compxz==1) {
            startTime=gettime_();
	    D theta2x=theta*theta;	
#pragma omp parallel for	
	    for (L i=0; i<inst.N; i++)
	       inst.x[i]=theta2x*inst.w[i]+inst.z[i];
#pragma omp parallel for
	    for (L j=0; j<inst.m; j++)
	       residuals[j]=theta2x*residuals_w[j]+residuals_z[j];

	    fval=Losses<L,D,traits>::compute_fast_objective(inst, residuals, inst.x);
	    D fval_z=Losses<L,D,traits>::compute_fast_objective(inst, residuals_z, inst.z);

	    if (fval_z<fval) {
		cout << "Iteration " << iterations << ", x<-z" << endl;
#pragma omp parallel for	
	        for (L i=0; i<inst.N; i++)
		     inst.w[i]=0;
#pragma omp parallel for
  	        for (L j=0; j<inst.m; j++)
	             residuals_w[j]=0;
	    }

	    endTime = gettime_();
	    totalRunningTime += endTime - startTime;
        }
    }

    D fval__ = Losses<L, D, traits>::compute_fast_objective(inst, residuals);  // What are rounding errors like?
    if (totalIt % 100 == 0) {
      if ((algorithm==ACCELERATED_COORDINATE_DESCENT)||(algorithm==ACCELERATED_GRADIENT)) {
	Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  
	Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);
      }
      else 
	Losses<L, D, traits>::recompute_residuals(inst, residuals, inst.x, inst.b);
    }
    fval = Losses<L, D, traits>::compute_fast_objective(inst, residuals);

/*	for (L i=0; i<inst.N; i++)
	  inst.x[i]=theta*theta*inst.w[i]+inst.z[i];	
	for (L j=0; j<inst.m; j++)
	  residuals[j]=theta*theta*residuals_w[j]+residuals_z[j];
	Losses<L, D, traits>::compute_fast_objective(inst, residuals); // normalization factor
*/

    D Pval=0.;
    D Pval__=0.;
    D infnorm=0.;
    if (problem==SVM_DUAL)
      {
	std::vector<D> primalvar;
	primalvar.resize(inst.m,0.);

	D factor=1./sqrt(inst.lambda_svm)/inst.n; 
	
#pragma omp parallel for
	for (L i = 0; i < inst.n; i++)
	  for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1]; j++) 
	    parallel::atomic_add(primalvar[inst.A_csc_row_idx[j]], inst.A_csc_values[j]/factor * inst.x[i]/(inst.lambda_svm*inst.n) );  //b0[i] is multiplied in A and divided in x.
	Pval=0;//-fvalOpt;

#pragma omp parallel for reduction(+:Pval)
	for (L i=0; i<inst.n; i++) {
	  D tmp=0;
	  for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1]; j++) 
	    tmp+= inst.A_csc_values[j]/factor * primalvar[inst.A_csc_row_idx[j]];
	  Pval+=max(0., 1.-tmp)/inst.n;
	}
#pragma omp parallel for reduction(+:Pval)
	for (L j=0; j<inst.m; j++){
	  Pval+=inst.lambda_svm/2*primalvar[j]*primalvar[j];
	}
//	cout << "duality gap: " << Pval << " - " << -fval << " = " << fval+Pval << endl;
//	sleep(1);
      }  //end svm primal
    else if(problem==SVM_PRIMAL)
	{ fval+=0.5; fval__ += 0.5; } //Writing the hinge loss as a L1 loss lets appear a constant.
    else if(problem==LASSO)
      {

        // if ||A^T mu||_inf <= lambda, then mu is dual admissible. The ideal is to take mu = b-Ax but we rather take (b-Ax)*min(1,lambda/||A^T(b-Ax)||_inf) which is always admissible
	std::vector<D> g;  // for gradient
	g.resize(inst.N,0.);
#pragma omp parallel for 
	for (L i = 0; i < inst.N; i++)
	  for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1]; j++) 
	    parallel::atomic_add(g[i],inst.A_csc_values[j] * residuals[inst.A_csc_row_idx[j]]); 
	
	infnorm=max(1e-20,inst.lambda);
	D bres=0;
	D sqtwonorm=0;
	for (L i = 0; i < inst.N; i++) {
	   infnorm = max(infnorm, abs(g[i])); 
	}
#pragma omp parallel for reduction(+:bres) reduction(+:sqtwonorm)
	for (L j = 0; j < inst.m; j++) {
 	   bres += inst.b[j]*residuals[j];
	   sqtwonorm += residuals[j]*residuals[j];
	}
	
	Pval__ = 0.5*sqtwonorm*inst.lambda*inst.lambda/infnorm/infnorm + bres*inst.lambda/infnorm; // My own version //Dval would be better but this notation was for svm...
	D muk=max(min(bres/inst.lambda/sqtwonorm, 1./infnorm), -1./infnorm);
	Pval = 0.5*inst.lambda*inst.lambda*sqtwonorm*muk*muk - inst.lambda*bres*muk; //Gribonval's version

      }
    L nnz = 0;
    D wnorm=0;
if (inst.lambda>0)
{
#pragma omp parallel for
    for (L i = 0; i < inst.n; i++) 
      if ((algorithm==ACCELERATED_COORDINATE_DESCENT)||(algorithm==ACCELERATED_GRADIENT)) {
	// one step of cyclic coordinate descent to get 0 if x[i] is close to 0
	Losses<L, D, traits>::do_single_iteration_parallel(inst, i, residuals, inst.x, h_Li);	
      }
#pragma omp parallel for reduction(+:nnz) reduction(+:wnorm)
    for (L i = 0; i < inst.N; i++) 
      if (inst.x[i] != 0)
	{
	  nnz++;
	  wnorm+=inst.x[i]*inst.x[i]/h_Li[i]/inst.sigma;
	}
    wnorm=sqrt(wnorm);
}

    if ((totalRunningTime>nbaff) || ((totalIt+1)%10000==0)){		
      cout << setprecision(6)<< omp_threads << "," << inst.n << ","
	   <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
	   << totalIt << "," << fval << "," << fval__ << "," << -Pval <<"," << -Pval__ << ","<<fval+Pval << "," << nnz << ","
	   << wnorm << "," <<theta<<","<< gamma <<endl;
      nbaff++;
    }


    experimentLogFile << setprecision(16) << omp_threads << "," << inst.n << ","
		      <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
		      << iterations << "," << fval << "," << -Pval << "," <<fval+Pval << "," << nnz << ","
		      << wnorm << ","<< theta<<","<< inst.lambda << ","<<restart << endl;
    totalIt++;
  } // end of main loop


  cout << setprecision(6)<< omp_threads << "," << inst.n << ","
       <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
       << iterations << "," << fval << "," << fvalOpt << endl;

}

ofstream result;
result.open("results/optvar");
   for (int k=0; k<inst.n; k++)
	result << setprecision(16) << inst.x[k] << ",";
result << endl;

}

template<typename L, typename D, typename traits>
void run_experiment(const char* filenameMatrix, const char* filenameVector, int N, int blockReduction,
		    std::vector<gsl_rng *>& rs, ofstream & histogramLogFile,
		    ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm, ProblemType problem) {

  problem_data<L, D> inst;
  omp_set_num_threads(MAXIMUM_THREADS);
  init_random_seeds(rs);

  double fvalOpt=0;
  inst.lambda=0.;
  inst.lambda2=0.;

//  fvalOpt = nesterov_generator(inst, (L)10000, (L)10, (L)8, rs,	histogramLogFile);
//  transpose_matrix(inst);

  //load_file(inst, "/data/fercoq/MaliciousURLs/matriceadaboostcomp.mat", "/data/fercoq/MaliciousURLs/vectoradaboost.mat", rs, histogramLogFile);
  load_file(inst, filenameMatrix, filenameVector, rs, histogramLogFile, (int) (problem==INF_NORM));



  if ((problem==LASSO) || (problem==ONE_NORM) || (problem==LOGISTIC))
     inst.lambda=1;	
  if (problem==LASSO) {
     cout << "Normalising the columns." << endl;
     std::vector<D> colnorms(inst.N, 0);
#pragma omp parallel for 
     for (L i = 0; i < inst.N; i++) {
	colnorms[i] = 0;
	for (L k = inst.A_csc_col_ptr[i];
	     k < inst.A_csc_col_ptr[i + 1]; k++) {
	  colnorms[i] += inst.A_csc_values[k] * inst.A_csc_values[k];
	}
	colnorms[i]=max(1e-50,sqrt(colnorms[i]));
	for (L k = inst.A_csc_col_ptr[i];
	     k < inst.A_csc_col_ptr[i + 1]; k++) {
	  inst.A_csc_values[k] = inst.A_csc_values[k]/colnorms[i];
	}
      }
     cout << "Computing lambdamax." << endl;
     std::vector<D> Atb;
     Atb.resize(inst.N);
     inst.lambda=0;
#pragma omp parallel for 
     for (L i = 0; i < inst.N; i++) {
	Atb[i]=0;
	for (L k = inst.A_csc_col_ptr[i];
	     k < inst.A_csc_col_ptr[i + 1]; k++) {
	  Atb[i] += inst.A_csc_values[k]*inst.b[inst.A_csc_row_idx[k]];
	}
     }
     for (L i = 0; i < inst.N; i++)
	inst.lambda=max(inst.lambda, abs(Atb[i]));


  }
  if (problem==LOGISTIC)
     inst.lambda2=30;
  if ((problem==ADABOOST) || (problem==SVM_PRIMAL)){
  // Make the matrix Adaboost type
    cout << "Making the Adaboost or hinge loss matrix" << endl;
    D sign=1;
    if (problem==SVM_PRIMAL)  {
	sign=-1./2./inst.m;
	inst.lambda2=1./inst.m;
    }
    for (L i=0; i< inst.N; i++)
      for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i+1]; k++)
	inst.A_csc_values[k]*= (sign*inst.b[inst.A_csc_row_idx[k]]);
    for (L j=0; j< inst.m; j++)
      for (L k=inst.A_csr_row_ptr[j]; k < inst.A_csr_row_ptr[j+1]; k++)
	inst.A_csr_values[k]*= (sign*inst.b[j]);
    if (problem==ADABOOST)
      for (L j=0; j<inst.m; j++)
        inst.b[j]=0;
    if (problem==SVM_PRIMAL)
      for (L j=0; j<inst.m; j++)
        inst.b[j]=-1./2./inst.m;
    inst.lowerbound.resize(inst.N,-numeric_limits<D>::max());
    inst.upperbound.resize(inst.N,numeric_limits<D>::max());
    inst.c.resize(inst.N,0.);
    if (problem==SVM_PRIMAL)
      for (L i=0; i< inst.N; i++)
         for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i+1]; k++)
            inst.c[i]+=inst.A_csc_values[k];

  }
  else if (problem == SVM_DUAL){
    cout << "Making the dual SVM matrix" << endl;  
		
    inst.lambda_svm=1./inst.N;  //inst.m will soon become inst.N
    inst.b0=inst.b;
    D factor=1./sqrt(inst.lambda_svm)/inst.m; 
    for (L i=0; i< inst.N; i++){
      for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i+1]; k++)  
	inst.A_csc_values[k]*=inst.b[inst.A_csc_row_idx[k]]*factor;
	}
    for (L j=0; j< inst.m; j++)
      for (L k=inst.A_csr_row_ptr[j]; k < inst.A_csr_row_ptr[j+1]; k++)
	inst.A_csr_values[k]*=inst.b[j]*factor;
    //Transposition of the matrix
    transpose_matrix(inst); //in case it was not already done
    D tmp=inst.m;
    inst.m=inst.N;
    inst.N=tmp;
    inst.n=inst.N;
    inst.blocks_ptr.resize(inst.n+1);
    for (L k=0; k<inst.n+1; k++)
 	inst.blocks_ptr[k]=k;

    inst.A_csc_col_ptr=inst.A_csr_row_ptr;
    inst.A_csc_values=inst.A_csr_values;
    inst.A_csc_row_idx=inst.A_csr_col_idx;
    //Compute the new omega
    transpose_matrix(inst); 		
    inst.omega=0;
    for (L j=0; j<inst.m; j++)
      {
	if (inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j]>inst.omega)
	  inst.omega=inst.A_csr_row_ptr[j+1]-inst.A_csr_row_ptr[j];
      }

    inst.b.resize(0);
    inst.b.resize(inst.m,0.);	

    inst.lambda=0.;	
    inst.lowerbound.resize(inst.N,0.);
    inst.upperbound.resize(inst.N,1.);
    inst.c.resize(inst.N,-1./(D)inst.N);
    }
   else
    {
      inst.lowerbound.resize(inst.N,-numeric_limits<D>::max());
      inst.upperbound.resize(inst.N,numeric_limits<D>::max());
      inst.c.resize(inst.N,0.);
    }
    inst.radius=numeric_limits<D>::max();
    inst.dimball=1;



  if ((algorithm==COORDINATE_DESCENT) || (algorithm==ACCELERATED_COORDINATE_DESCENT))
	inst.n=inst.N;
  else if (algorithm==GRADIENT) {
	inst.n=1;
  }
  else if (algorithm==ACCELERATED_GRADIENT) {
	inst.n=1;
  }
  else if (algorithm==GREEDY) {
	inst.n=inst.N;  //Attention, inst.n is inst.N for the computation of Lipschitz constants but 1 in the main loop.
  }

//inst.n=1;

  inst.blocks_ptr.resize(inst.n+1);
  for (L k=0; k<inst.n+1; k++)
 	inst.blocks_ptr[k]=inst.N/inst.n*k;

  std::vector<D> h_Li(inst.n, 0);
  //-------------- set the number of threads which should be used.
 for (int ll=0; ll<5; ll++)
 {
  inst.lambda = inst.lambda/10;  //de lambdamax/10 a lamdamax/10^6

  cout << "inst.lambda = "<< inst.lambda << endl;

  int TH[1] = {16};
  for (int i = 0; i < 1; i++) {
    cout << "Running experiment with " << TH[i] << " threads" << endl;
    inst.tau=TH[i];
    inst.sigma = 1. + (TH[i] - 1.) * (inst.omega) / (D)(inst.n);  // 1. instead of 1 to avoid Euclidean division.
    Losses<L, D, traits>::compute_reciprocal_lipschitz_constants(inst, h_Li);

    cout << setprecision(16) << "omega=" << inst.omega << ", beta = " << inst.sigma << ", lambda = " << inst.lambda <<endl;

    // run the experiment
    run_computation<L, D,traits>(inst, h_Li, fvalOpt, TH[i], inst.n, inst.m, inst.sigma, N, 1, rs,
				 experimentLogFile, MAXIMUM_THREADS, algorithm, problem);

    //free(inst.reduction_vector);
  }

 }

}

int main(int argc, char * argv[]) {

  // setup GSL random generators
  gsl_rng_env_setup();
  const gsl_rng_type * T;
  gsl_rng * r;
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
  const int MAXIMUM_THREADS =16;
  std::vector<gsl_rng *> rs(MAXIMUM_THREADS);
  for (int i = 0; i < MAXIMUM_THREADS; i++) {
    rs[i] = gsl_rng_alloc(T);
    gsl_rng_set(rs[i], i);
  }
  init_omp_random_seeds();

  //---------------------- Setting parameters of experiments

  for (int expe=22; expe<23; expe+=2) {
    string expename;
    string filenameMatrix;
    string filenameVector;

    if ((expe<4) && (expe>=0))
      expename="url"; //
    else if (expe<8)
      expename="dorothea";
    else if (expe<12)
      expename = "mushrooms";
    else if (expe<16)
      expename = "w8a"; 
    else if (expe<20)
      expename = "laplacian";
    else if (expe<24)
      expename = "kddb";
    else if (expe<28)
      expename = "rcv1";
    else
      expename="random";
    if (expe<24){
      filenameMatrix="/cluster/fhgfs/ofercoq/datasets/matrix_"+expename; //"/data/fercoq/MaliciousURLs/matricecomp.mat";//
      filenameVector="/cluster/fhgfs/ofercoq/datasets/vector_"+expename; //"/data/fercoq/MaliciousURLs/vector.mat";  // 
    }
    cout << "Dataset: " << expename << ", algorithm: ";

    AlgorithmType algorithm = COORDINATE_DESCENT;
    if (expe%4==0)
      algorithm = COORDINATE_DESCENT;
    else if (expe%4==1)
      algorithm = GRADIENT;
    else if (expe%4==2)
      algorithm = ACCELERATED_COORDINATE_DESCENT;
    else if (expe%4==3)
      algorithm = ACCELERATED_GRADIENT;

    ProblemType problem = LASSO;  // Attention, I did not manage to set templates to follow the problem type.

    //---------------------- Set output files
    ofstream histogramLogFile;
    histogramLogFile.open("results/large_scale_experiment_histogram.log");
    ofstream experimentLogFile;	
    string logfilename="results/experiment_"+expename+"_zcompx_";
    if (problem==LASSO)
      { logfilename+="lasso_";  cout << "lasso: " ;}
    else if (problem==SVM_DUAL)
      { logfilename+="svmdual_";  cout << "svm dual: " ;}
    else if (problem==SVM_PRIMAL)
      { logfilename+="svmprimal_";  cout << "svm primal: " ;}
    else if (problem==INF_NORM)
      { logfilename+="infnorm_";  cout << "inf norm: " ;}
    else if (problem==ONE_NORM)
      { logfilename+="onenorm";  cout << "one norm: " ;}
    else if (problem==ADABOOST)
      { logfilename+="adaboost_";  cout << "adaboost: " ;}
    else if (problem==LOGISTIC)
      { logfilename+="logistic_";  cout << "logistic: " ;}

    if (expe%4==0)
      {	logfilename+="COORDINATE_DESCENT"; cout << "COORDINATE_DESCENT" << endl;}
    else if (expe%4==1)
      {	logfilename+="GRADIENT"; cout << "GRADIENT" << endl;}
    else if (expe%4==2)
      {	logfilename+="ACCELERATED_COORDINATE_DESCENT"; cout << "ACCELERATED_COORDINATE_DESCENT" << endl;}
    else if (expe%4==3)
      {	logfilename+="ACCELERATED_GRADIENT"; cout << "ACCELERATED_GRADIENT" << endl;}

    experimentLogFile.open(logfilename.c_str());
    //--------------------- run experiment - one can change precision here
    run_experiment<long long, double, square_loss_traits>(filenameMatrix.c_str(), filenameVector.c_str(),2000., 1, rs, histogramLogFile,  experimentLogFile, MAXIMUM_THREADS, algorithm, problem);
    histogramLogFile.close();
    experimentLogFile.close();	

  }
	

  return 0;
}
