
#include "../solver/structures.h"
#include "../parallel/parallel_essentials.h"
#include "../solver/treshhold_functions.h"




template<typename L, typename D, typename traits>
void chambolle_pock(problem_data<L, D> &inst, std::vector<D> &h_Li, int omp_threads, D MAXTIME,
		     ofstream& experimentLogFile, const int MAXIMUM_THREADS) {
 
  //L imagesize=inst.m/7;

  if (inst.m/7 != inst.N/3)
     cout << "Attention: Chambolle-Pock algorithm only coded for TGV2 problem!\n";

// I remove the top left identity block of the matrix.
   for (L i=0; i<inst.N; i+=3)
	for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) {
	   L j = inst.A_csc_row_idx[k];
	//if (i<11) cout << "A["<< inst.A_csc_row_idx[k]+1 << "," << i+1<< "]"<< "=" << inst.A_csc_values[k] << " -> ";
	   if ((j % 7 == 0) && (j/7==i/3))
	   	inst.A_csc_values[k]-=1.;  //-1+1=0
	//if (i<11) cout << "A["<< inst.A_csc_row_idx[k]+1 << "," << i+1<< "]"<< "=" << inst.A_csc_values[k] << endl;
	}

  

h_Li[0]=1./sqrt(15);  // the 2-norm of the matrix is smaller that sqrt(15).
  h_Li[1]=1./sqrt(15)-1e-15;
  D theta=1;

  inst.mu=1e-15;

  std::vector<D> x_;
  std::vector<D> residuals_x;

  inst.x.resize(inst.N,0.);  //primal variable
  residuals_x.resize(inst.m,0.);
  x_.resize(inst.N,0.);      //buffered primal variable
  inst.w.resize(inst.N,0.);  //extragradient primal variable
  inst.z.resize(inst.m,0.);  //dual variable

  D totalRunningTime = 0.;

  L nbaff=-2;

  L iterations=0;
  D fval=1e300;

  //iterate
  while (totalRunningTime<MAXTIME) {

    if (totalRunningTime>=(D)nbaff) {
        for (L i = 0; i < inst.m; i++) {
          residuals_x[i] = -inst.b[i];
        }
        for (L i = 0; i < inst.N; i++) {
         for (L j = inst.A_csc_col_ptr[i]; j < inst.A_csc_col_ptr[i + 1]; 
	       j++) {
 	   residuals_x[inst.A_csc_row_idx[j]]+=inst.A_csc_values[j]*inst.x[i];
          }
        }
        for (L j = 0; j < inst.m; j+=7) 
   	   residuals_x[j] += inst.x[j/7*3];  // Recall that we have removed these elements of the matrix in the preamble of this file.

        fval = Losses<L, D, traits>::compute_fast_objective(inst, residuals_x);
 	nbaff++;
 	cout << setprecision(5) <<"Chambolle_Pock, "<< iterations<<": "<< totalRunningTime << "s, fval=" << fval <<endl;
    }


    D startTime = gettime_();
    
    // z<-z+sigma Aw
    for (L i=0; i<inst.N; i++)
	for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) {
	   L j = inst.A_csc_row_idx[k];
	   D Aji=inst.A_csc_values[k];
	   inst.z[j]+=h_Li[0]*Aji*inst.w[i];
	}

    // z<-prox_{sigma F*}(z) : projection for z(1:2) and z(3:6), nothing for z(0)
    D radius=inst.alpha;
    for (L j=0; j<inst.m; j+=7) {
	D norm=0;
	for (L k=j+1; k<j+3; k++)
	   norm+=inst.z[k]*inst.z[k];
	norm=sqrt(norm);
	if (norm>radius) {
	    D factor=radius/norm;
	    for (L k=j+1; k<j+3; k++)
		inst.z[k]*=factor;
	}
    }
    radius=inst.beta; // symmetrized gradient ?
    if (inst.beta==0)
	radius=1e30;   // we do not want TGV2(alpha,0) but TV(alpha)
    for (L j=0; j<inst.m; j+=7) {
	D norm=0;
	for (L k=j+3; k<j+7; k++)
	   norm+=inst.z[k]*inst.z[k];
	norm=sqrt(norm);
	if (norm>radius) {
	    D factor=radius/norm;
	    for (L k=j+3; k<j+7; k++)
		inst.z[k]*=factor;
	}
    }

    // save xn
    for (L i=0; i<inst.N; i++)   
	x_[i]=inst.x[i];

    // x<-x-tau K* z
    for (L i=0; i<inst.N; i++)
	for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) {
	   L j = inst.A_csc_row_idx[k];
	   D Aji=inst.A_csc_values[k];
	   inst.x[i]-=h_Li[1]*inst.z[j]*Aji;
	}

    //x<-prox_{tau G}(x) : quadratic on x(1) but nothing on x(2) and x(3)
    for (L i=0; i<inst.N; i+=3)    
	inst.x[i] = (h_Li[1]*inst.b[7*i/3]+inst.x[i])/(h_Li[1]+1);
    if (inst.beta==0)
	for (L i=0; i<inst.N; i++)    
	    if (i%3 != 0)
		inst.x[i] = 0;

    //w<-x+theta(x-x_)
    for (L i=0; i<inst.N; i++) 
	inst.w[i]=(1+theta)*inst.x[i]-theta*x_[i];


    D endTime = gettime_();
    totalRunningTime += endTime - startTime;
 
    iterations++;
  }  

cout << setprecision(20) <<"Chambolle_Pock, "<< iterations<<": "<< totalRunningTime << "s, fval=" << fval <<endl;

for (int j=0; j<20; j++)
cout << residuals_x[j] << " ";
cout << endl;


ofstream result;
result.open("results/optvar_cp");
for (int k=0; k<inst.N; k++)
	result << inst.x[k] << ",";

result << endl;

result.close();


}
