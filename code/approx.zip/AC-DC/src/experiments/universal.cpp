/*
 * This file contains an experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */




#include "../helpers/c_libs_headers.h"
#include "../helpers/gsl_random_helper.h"

#include "../solver/structures.h"
#include "../class/loss/losses.h"
#include "../problem_generator/generator_nesterov.h"
#include "../problem_generator/load_file.h"
#include "../problem_generator/load_image_and_construct_matrix.h"
#include "../solver/lineSearches.h"
#include <omp.h>

enum AlgorithmType {
  GRADIENT,
  COORDINATE_DESCENT,
  ACCELERATED_GRADIENT,
  ACCELERATED_COORDINATE_DESCENT,
  GREEDY,
  UNIVERSAL_COORDINATE_DESCENT,
  UNIVERSAL_ACCELERATED_COORDINATE_DESCENT,
  UNIVERSAL_GRADIENT,
  UNIVERSAL_ACCELERATED_GRADIENT
};



template<typename L, typename D, typename traits>
void run_computation(problem_data<L, D> &inst, std::vector<D> &h_Li,
		     double fvalOpt, int omp_threads, L n, L m, L sigma, int N,
		     int blockReduction, std::vector<gsl_rng *>& rs,
		     ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm) {

  double MAXTIME = N;
	
  vector<D> Q;
  int eso=1;
  if (eso==0) {
     D omega_S=std::min(inst.omega, inst.tau);
     Q = compute_Q_probabilities<L,D>(inst.n, omega_S, inst.n);
//     Q.resize(floor(log2(omega_S))+1,0.);
//     Q[floor(log2(omega_S))+1]=1.;
  }
  else
     Q = compute_Q_probabilities<L,D>(inst.omega, inst.tau, inst.n);

  inst.x.resize(inst.N);
  for (L i = 0; i < inst.N; i++)
    inst.x[i] = 0;
  cout << "x initialised." <<endl;

  D theta=0;
  D tauovern=min(1., (D)inst.tau/(D)inst.n);  // if we have accelerated gradient, we should take tau=n=1 but we parallelize linear algebra.

  if (algorithm==UNIVERSAL_ACCELERATED_COORDINATE_DESCENT)
    {
      theta=tauovern;  
      inst.z.resize(inst.N);
      inst.w.resize(inst.N);
      for (L i=0; i<inst.N; i++) {
	inst.z[i]=inst.x[i];
	inst.w[i]=0;
      }
    }
ofstream print;
//if (algorithm==UNIVERSAL_GRADIENT)/
//	print.open("results/experiment_w8a_compgrad_UNIVERSAL_GRADIENT");

  omp_set_num_threads(omp_threads);
  init_random_seeds(rs);
  cout << "seed OK" <<endl;
  std::vector<D> residuals(inst.m);
  std::vector<D> residuals_w;
  std::vector<D> residuals_z;
  std::vector<D> m_zeros(inst.m,0);

  residuals.resize(inst.m);
  if (algorithm==UNIVERSAL_ACCELERATED_COORDINATE_DESCENT)
    {
      residuals_w.resize(inst.m);  
      Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  //0 to remove the -b in the residuals.
      residuals_z.resize(inst.m);  		
      Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);
		      
      for (L j=0; j<inst.m; j++)
	residuals[j]=theta*theta*residuals_w[j]+residuals_z[j];
      for (L i=0; i<inst.N; i++)
	inst.x[i]=theta*theta*inst.w[i]+inst.z[i];

      for (L idx=0; idx<inst.n; idx++)
	h_Li[idx]*=inst.tau/(D)inst.n;  //inverse lipschitz constants.
    }
  else
    Losses<L, D, traits>::recompute_residuals(inst, residuals, inst.x, inst.b);

  cout << "Normalization factor for inf-norm: " <<inst.normalization_factor << endl;
  D fvalInit = Losses<L, D, traits>::compute_fast_objective(inst, residuals);

  cout << fvalInit << endl;
  L maxblocksize=0;
  for (L idx=0; idx<inst.n; idx++)
    maxblocksize=max(maxblocksize, inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]);

  D nextdecreaseLipschitz=1;
  D decreasefactor=2;

  double totalRunningTime = 0;
  double iterations = 0;
  int nbaff=-1;
  int totalIt=0;
  L perPartIterations = inst.n / blockReduction;
  double additional = perPartIterations / (0.0 + inst.n);
  D fval = fvalInit;
  // store initial objective value
  cout << setprecision(16) << omp_threads << "," << inst.n << "," << inst.m
       << "," << inst.sigma << "," << totalRunningTime << "," << iterations
       << "," << fval << endl;
  experimentLogFile  << setprecision(16) << omp_threads << "," << inst.n << ","
		     <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
		     << iterations << "," << fval << "," << fvalOpt << "," <<0<<",0,0"
		     << endl;

  //iterate
  while (totalRunningTime<MAXTIME) {
    double startTime = gettime_();

  // inst.normalization_factor=1.;
    if (algorithm==UNIVERSAL_GRADIENT) {
	int idx=0;
	std::vector<D> update(inst.N);
	univgradLineSearch<L, D, traits>(inst, residuals, idx, h_Li, inst.epsilon, Q, update);
	//Losses<L, D, traits>::do_single_update_parallel( inst, idx, residuals, inst.x, h_Li, update);
    }
    else if (algorithm==UNIVERSAL_COORDINATE_DESCENT)  {
#pragma omp parallel for
      for (L it = 0; it < perPartIterations; it++) {
	std::vector<D> update(maxblocksize);
	// sampling
	unsigned long int idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);

	// line search
	EsoLineSearch<L, D, traits>(inst, residuals, idx, h_Li, inst.epsilon, Q, update);

	// update of the variable
	Losses<L, D, traits>::do_single_update_parallel( inst, idx, residuals, inst.x, h_Li, update);

	//inst.normalization_factor=1;
/*if (nbaff>7) 
{  

        std::vector<D> grad(maxblocksize);
        Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update, grad);
	D fval_ = fval;
	D resids_=resids;
	resids = 0;
	for (L i = 0; i < inst.m; i++) {
		resids += log(1 + exp(residuals[i]));
	}
	D sumx = 0;
	for (L j = 0; j < inst.N; j++) {
		sumx += abs(inst.x[j]);
	}
	fval = 0.5*inst.lambda*resids + sumx; 
D residsbound=0.5*inst.lambda*resids_+grad[0]*update[0]+0.5/h_Li[idx]*update[0]*update[0];
if (fval_<fval)
cout << fval_ << "<" << fval << ", idx="<<idx << ", " << 0.5*inst.lambda*resids << " ?< " << residsbound << ": " << -sgn(0.5*inst.lambda*resids - residsbound) << "; " << grad[0]*update[0]<< ", inst.x=" << inst.x[idx] << ", update=" << update[0] << endl;

 }*/
      }
    }
    else if (algorithm==UNIVERSAL_ACCELERATED_COORDINATE_DESCENT)
      {
	D iter_glob=iterations;
#pragma omp parallel if (perPartIterations>inst.tau)
	{
	  D iter_loc=iterations;
	  D theta_loc=theta;
	  std::vector<D> update_z(maxblocksize);
	  std::vector<D> update_w(maxblocksize);
	  // Either perPartIterations or nbcoord is large.
#pragma omp for 
	  for (L it = 0; it < perPartIterations; it++) {
	    //#endif
		
	    // one step of the algorithm
		
	    D ck=-(1.-1./tauovern*theta_loc)/(theta_loc*theta_loc);
		  
	    unsigned long int idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);

	    // line search
	    EsoLineSearchAccel<L, D, traits>(inst, residuals_w, residuals_z, idx, h_Li, inst.epsilon, Q, theta_loc, update_z);

	    for (L i=0; i<inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]; i++)
	      update_w[i]=ck*update_z[i]; 
   
	    Losses<L, D, traits>::do_single_update_parallel_accel(inst, idx, residuals_w, residuals_z, h_Li, update_w, update_z);  //Efficient implementation for square loss and l1 loss
		      
	    iter_glob=parallel::atomic_add(iter_glob, 1.);			
			  
	    while(iter_loc<iter_glob)
	      {					
		D theta2=theta_loc*theta_loc;
		theta_loc=0.5*sqrt(theta2*theta2+4*theta2)-0.5*theta2;
		iter_loc+=inst.tau;
	      }
	  }  //end parallel for
#pragma omp critical
	  theta=min(theta,theta_loc);
	}  //end parallel
      } // end if ACCELERATED

    if (totalIt > nextdecreaseLipschitz) {
#pragma omp parallel for
	for (L idx=0; idx<inst.n; idx++)
	    h_Li[idx]*=2;
	h_Li[inst.n]/=2;
	nextdecreaseLipschitz *= decreasefactor;
    }

    double endTime = gettime_();
    iterations += additional;
    totalRunningTime += endTime - startTime;

    

    // recompute residuals  - this step is not necessary but if accumulation of rounding errors occurs it is useful
    if (algorithm==UNIVERSAL_ACCELERATED_COORDINATE_DESCENT)
      {
        if ((L)iterations % 40 == -1) {
 	  cout << "Restarting.\n";
          for (L i=0; i<inst.N; i++) {
	    inst.z[i]=inst.x[i];
	    inst.w[i]=0.;
	  }
	  theta=tauovern;
	  Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  
	  Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);
        }
	for (L j=0; j<inst.m; j++)
	  residuals[j]=theta*theta/(1-theta)*residuals_w[j]+residuals_z[j];
	for (L i=0; i<inst.N; i++)
	  inst.x[i]=theta*theta/(1-theta)*inst.w[i]+inst.z[i];
      }
    D fval__ = Losses<L, D, traits>::compute_fast_objective(inst, residuals);
 
    if (totalIt % 1000 == -1) {      
      if (algorithm==UNIVERSAL_ACCELERATED_COORDINATE_DESCENT) {
	Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  
	Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);
      }
      else 
	Losses<L, D, traits>::recompute_residuals(inst, residuals);
    }
    fval = Losses<L, D, traits>::compute_fast_objective(inst, residuals);  // What are rounding errors like?

   // if (fval<11196)
/*    {
D gradnorm=0;
D maxresids=-100;
vector<D> grad(1);
vector<D> update_x(1);
for (L idx=0; idx<inst.n; idx++){
        Losses<L, D, traits>::compute_update(inst, residuals, idx, h_Li, update_x, grad);
	gradnorm+=grad[0]*grad[0];
}
	for (L j=0; j<inst.m; j++)
	   maxresids=max(maxresids, residuals[j]);
	cout << inst.normalization_factor<<" "<<gradnorm<< " "<< maxresids<<endl;

 
    }*/


    L nnz = 0;
    D wnorm = 0;
    D meanL = 0;
    D stdL = 0;
#pragma omp parallel for reduction(+:nnz)
    for (L i = 0; i < inst.N; i++)
      if (inst.x[i] != 0)
	nnz++;
#pragma omp parallel for reduction(+:wnorm, meanL, stdL)
    for (L idx = 0; idx < inst.n; idx++)  { 
      for (L i = inst.blocks_ptr[idx]; i<inst.blocks_ptr[idx+1];i++)
	wnorm+=inst.x[i]*inst.x[i]/h_Li[idx]/inst.sigma;
      meanL += 1./h_Li[idx];
      stdL += 1./(h_Li[idx]*h_Li[idx]);
    }
    meanL /= inst.n;
    stdL /= inst.n;
    stdL = sqrt(stdL- meanL*meanL);

    wnorm=sqrt(wnorm);

    if ((totalRunningTime>nbaff) || (totalIt%1000==999)){		
      cout << setprecision(5)<< omp_threads << "," << inst.n << ","
	   <<  inst.m << "," <<  inst.epsilon << "," << totalRunningTime << ","
	   << iterations << "," << fval << "," << fval__ << "," << fvalOpt << "," << nnz << ","
	   << wnorm << "," <<meanL << "," << stdL << endl;
      nbaff++;
    }

    experimentLogFile << setprecision(16) << omp_threads << "," << inst.n << ","
		      <<  inst.m << "," <<  inst.epsilon << "," << totalRunningTime << ","
		      << iterations << "," << fval << "," << fvalOpt << "," << nnz << ","
		      << wnorm << ","<<meanL <<endl;
/*if (algorithm==UNIVERSAL_GRADIENT)
print << setprecision(16) << omp_threads << "," << inst.n << ","
		      <<  inst.m << "," <<  inst.epsilon << "," << totalRunningTime << ","
		      << iterations << "," << fval << "," << fvalOpt << "," << nnz << ","
		      << wnorm << ","<<meanL <<endl;*/

    totalIt++;
  }
  cout << setprecision(5)<< omp_threads << "," << inst.n << ","
       <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
       << iterations << "," << fval << "," << fvalOpt << endl;


ofstream result;
result.open("results/optvar");
for (L k=0; k<inst.N; k++)
	result << inst.x[k] << ",";

result << endl;

result.close();
//print.close();

}

template<typename L, typename D, typename traits>
void run_experiment(const char* filenameMatrix, const char* filenameVector, int N, int blockReduction,
		    std::vector<gsl_rng *>& rs, ofstream & histogramLogFile,
		    ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm) {

  problem_data<L, D> inst;
  omp_set_num_threads(MAXIMUM_THREADS);
  init_random_seeds(rs);

  //	double fvalOpt = nesterov_generator(inst, n, m, sigma, rs,
  //			histogramLogFile);

  int adaboost=1;
  int tgv2=0;
  int infnorm=0;

  //load_file(inst, "/data/fercoq/MaliciousURLs/matriceadaboostcomp.mat", "/data/fercoq/MaliciousURLs/vectoradaboost.mat", rs, histogramLogFile);
  //
  inst.lambda=0.01;
  // Make the matrix Adaboost type
  if (adaboost==1){
    load_file(inst, filenameMatrix, filenameVector, rs, histogramLogFile);
    cout << "Making the Adaboost matrix" << endl;
    for (L i=0; i< inst.N; i++)
      for (L k=inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i+1]; k++)
	inst.A_csc_values[k]*=inst.b[inst.A_csc_row_idx[k]];
    for (L j=0; j< inst.m; j++)
      for (L k=inst.A_csr_row_ptr[j]; k < inst.A_csr_row_ptr[j+1]; k++)
	inst.A_csr_values[k]*=inst.b[j];
    for (L j=0; j<inst.m; j++)
      inst.b[j]=0;
    inst.c.resize(inst.N,0.);
    inst.lowerbound.resize(inst.N,-numeric_limits<D>::max());
    inst.upperbound.resize(inst.N, numeric_limits<D>::max());
  }
  else if (tgv2==1) {
    load_image_and_construct_tgv2_matrix(inst, filenameMatrix, filenameVector);  //filenameMatrix only is the sizes of the image	 
    //parameters of tgv2.
    inst.alpha=30.;
    inst.beta=30.;
    if (inst.beta==0)  // we do not want TGV2(alpha,0) but TV(alpha)
      for (L i=0; i<inst.N;i++)
	if (i%3!=0)
          { inst.lowerbound[i]=0; inst.upperbound[i]=0.;}
  }
  else  {
    load_file(inst, filenameMatrix, filenameVector, rs, histogramLogFile, infnorm);
    inst.c.resize(inst.N,0.);
    inst.lowerbound.resize(inst.N,-numeric_limits<D>::max());
    inst.upperbound.resize(inst.N, numeric_limits<D>::max());
  }

  inst.c.resize(inst.N,0.);  
  inst.radius=numeric_limits<D>::max();
  inst.dimball=1;


  if ((algorithm==UNIVERSAL_COORDINATE_DESCENT) || (algorithm==UNIVERSAL_ACCELERATED_COORDINATE_DESCENT))
	inst.n=inst.N;
  else if (algorithm==UNIVERSAL_GRADIENT) {
	inst.n=1;
  }
  else if (algorithm==UNIVERSAL_ACCELERATED_GRADIENT) {
	inst.n=1;
  }

  inst.blocks_ptr.resize(inst.n+1);
  for (L k=0; k<inst.n+1; k++)
    inst.blocks_ptr[k]=inst.N/inst.n*k;

  double fvalOpt=24588.9;  // l1+l1 for w8a
  //27;  // l1+l1 for mushrooms
  //23393024.469448804855;  //found with chambolle pock algorithm for kodimsmall_noisy.





  std::vector<D> h_Li(inst.n+1, 0);  // the last element of h_Li is the sum of the entries.
  //-------------- set the number of threads which should be used.
  int TH[1] = {1};//{1,2,4,8,16};
  D EPSILON[1] = {0.001}; //{1., 1./2., 1./4., 1./8., 1./16.};
  for (int i = 0; i < 1; i++) {
  for (int ieps = 0; ieps<1; ieps++) {

    cout << "Running experiment with " << TH[i] << " threads" << endl;
    inst.tau=TH[i];

    inst.sigma=1.+(inst.omega-1.)*(inst.tau-1.)/max(1., inst.n-1.);

    Losses<L, D, traits>::compute_reciprocal_lipschitz_constants(inst, h_Li);

    D meanL=0.;
    for (L idx = 0; idx < inst.n; idx++)  { 
      meanL += 1./h_Li[idx];
    }
    cout << "mean of L without line search="<<meanL/inst.n << endl;

   inst.mu=1e-20;  // we smooth because I did not want to recode everything
   inst.epsilon=EPSILON[ieps];
   cout << "overwriting: epsilon=" << inst.epsilon << ", mu="<< inst.mu<< endl;

    inst.sigma=1;  //With a line search, no need to know beta.

    for (L idx=0; idx<inst.n; idx++)
      h_Li[idx]=1.;
    h_Li[inst.n]=0.;
    for (L idx =0; idx<inst.n; idx++)
	h_Li[inst.n]+=h_Li[idx];

    cout << setprecision(16) << "omega=" << inst.omega << ", beta = " << inst.sigma << endl;

    // run the experiment
    run_computation<L, D,traits>(inst, h_Li, fvalOpt, TH[i], inst.n, inst.m, inst.sigma, N, 1, rs,
				 experimentLogFile, MAXIMUM_THREADS, algorithm);

  }
  }
}

int main(int argc, char * argv[]) {

  // setup GSL random generators
  gsl_rng_env_setup();
  const gsl_rng_type * T;
  gsl_rng * r;
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
  const int MAXIMUM_THREADS = 24;
  std::vector<gsl_rng *> rs(MAXIMUM_THREADS);
  for (int i = 0; i < MAXIMUM_THREADS; i++) {
    rs[i] = gsl_rng_alloc(T);
    gsl_rng_set(rs[i], i);
  }
  init_omp_random_seeds();

  //---------------------- Setting parameters of experiments

  for (int expe=2; expe<3; expe++){
    string expename;
    string filenameMatrix;
    string filenameVector;
    if (expe<0)
      expename="url";
    else if (expe<4)
      expename="w8a";
    else if (expe<8)
      expename="dorothea";
    else if (expe<12)
      expename = "mushrooms";
    else if (expe<16)
      expename = "kodim23gray-noisy";  // fvalopt(30.,30.)=188501705.13361552358
    else if (expe<20)
      expename = "kodimsmall-noisy";   // fvalopt(30.,30.)= 23393024.469448804855  // kodimsmall=kodim23gray(61:260, 161:350)
    else expename = "untersberg-noisy";

    if (expe<0) {
	filenameMatrix="/data/fercoq/MaliciousURLs/matricecomp.mat";
        filenameVector="/data/fercoq/MaliciousURLs/vector.mat"; 
    }
    else if (expe<12) {
	filenameMatrix="/home/ofercoq/datasets/matrix_"+expename; //"/data/fercoq/MaliciousURLs/matricecomp.mat";//
        filenameVector="/home/ofercoq/datasets/vector_"+expename; //"/data/fercoq/MaliciousURLs/vector.mat";  // 
    }
    else {
	filenameMatrix="/home/ofercoq/ofercoq/mycodes/block-imaging/img/"+expename+".size";
	filenameVector="/home/ofercoq/ofercoq/mycodes/block-imaging/img/"+expename+".ascii";
    }
    cout << "Dataset: " << expename << ", algorithm: ";


    int expeplus=expe+8; // in case it is negative.
    AlgorithmType algorithm = UNIVERSAL_COORDINATE_DESCENT;
    if (expeplus%4==0)
      algorithm = UNIVERSAL_COORDINATE_DESCENT;
    else if (expeplus%4==1)
      algorithm = UNIVERSAL_GRADIENT;
    else if (expeplus%4==2)
      algorithm = UNIVERSAL_ACCELERATED_COORDINATE_DESCENT;
    else if (expeplus%4==3)
      algorithm = UNIVERSAL_ACCELERATED_GRADIENT;

    //---------------------- Set output files
    ofstream histogramLogFile;
    histogramLogFile.open("results/large_scale_experiment_histogram.log");
    ofstream experimentLogFile;	
    string logfilename="results/experiment_"+expename+"_adaboost2_";
    if (expe%4==0)
      {	logfilename+="UNIVERSAL_COORDINATE_DESCENT"; cout << "UNIVERSAL_COORDINATE_DESCENT" << endl;}
    else if (expe%4==1)
      {	logfilename+="UNIVERSAL_GRADIENT"; cout << "UNIVERSAL_GRADIENT" << endl;}
    else if (expe%4==2)
      {	logfilename+="UNIVERSAL_ACCELERATED_COORDINATE_DESCENT"; cout << "UNIVERSAL_ACCELERATED_COORDINATE_DESCENT" << endl;}
    else if (expe%4==3)
      {	logfilename+="UNIVERSAL_ACCELERATED_GRADIENT"; cout << "UNIVERSAL_ACCELERATED_GRADIENT" << endl;}

cout << "log file: "<<logfilename.c_str() << endl;

    experimentLogFile.open(logfilename.c_str());

    //--------------------- run experiment - one can change precision here
    run_experiment<long long, double, exp_loss_traits>(filenameMatrix.c_str(), filenameVector.c_str(), 5, 1, rs, histogramLogFile,
							   experimentLogFile, MAXIMUM_THREADS, algorithm);
    histogramLogFile.close();
    experimentLogFile.close();	

  }
	
  return 0;
}
