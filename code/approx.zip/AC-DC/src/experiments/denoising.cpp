/*
 * This file contains an experiment done in paper
 * P. Richtárik and M. Takáč
 *      Parallel Coordinate Descent Methods for Big Data Optimization
 * http://www.optimization-online.org/DB_HTML/2012/11/3688.html
 */




#include "../helpers/c_libs_headers.h"
#include "../helpers/gsl_random_helper.h"

#include "../solver/structures.h"
#include "../class/loss/losses.h"
#include "../problem_generator/generator_nesterov.h"
#include "../problem_generator/load_file.h"
#include "../problem_generator/load_image_and_construct_matrix.h"
#include "chambolle_pock.h"

#include <limits>
#include <stdint.h>

enum AlgorithmType {
  GRADIENT,
  COORDINATE_DESCENT,
  ACCELERATED_GRADIENT,
  ACCELERATED_COORDINATE_DESCENT,
  GREEDY,
  CHAMBOLLE_POCK
};


template<typename L, typename D, typename traits>
void run_computation(problem_data<L, D> &inst, std::vector<D> &h_Li,
		     double fvalOpt, int omp_threads, L n, L m, L sigma, D MAXTIME,
		     int blockReduction, std::vector<gsl_rng *>& rs,
		     ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm) {

  if (algorithm==CHAMBOLLE_POCK)  {
      chambolle_pock<L,D,traits>(inst, h_Li, omp_threads, MAXTIME, experimentLogFile, MAXIMUM_THREADS);
      return; 
  }

  inst.x.resize(inst.N);
  for (L i = 0; i < inst.N; i++)
    inst.x[i] =0;

  D theta=0;
  D tauovern=(D)inst.tau/(D)inst.n;
  if (algorithm==ACCELERATED_COORDINATE_DESCENT)
    {
      theta=tauovern;
      inst.z.resize(inst.N);
      inst.w.resize(inst.N);
      for (int i=0; i<inst.N; i++)
	inst.z[i]=inst.x[i];
      for (int i=0; i<inst.N; i++)
	inst.w[i]=0;
      for (int idx=0; idx<inst.n; idx++)
	h_Li[idx]=h_Li[idx]*tauovern;
    }

  omp_set_num_threads(omp_threads);
  init_random_seeds(rs);
  std::vector<D> residuals;	
  std::vector<D> residuals_w;
  std::vector<D> residuals_z;
  std::vector<D> m_zeros(inst.m,0);

  residuals.resize(inst.m);
  if (algorithm==ACCELERATED_COORDINATE_DESCENT)
    {
      residuals_w.resize(inst.m);  
      Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  //0 to remove the -b in the residuals.
      residuals_z.resize(inst.m);  		
      Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);

      for (L j=0; j<inst.m; j++)
	residuals[j]=theta*theta*residuals_w[j]+residuals_z[j];
      for (L i=0; i<inst.N; i++)
	inst.x[i]=theta*theta*inst.w[i]+inst.z[i];
    }
  else
    Losses<L, D, traits>::recompute_residuals(inst, residuals, inst.x, inst.b);

  cout << inst.normalization_factor << endl;

  D normb2 = 0;
  for (int j=0; j<inst.m; j++)
	normb2+=inst.b[j]*inst.b[j];


  L maxblocksize=0;
  for (L idx=0; idx<inst.n; idx++)
	maxblocksize=max(maxblocksize, inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]);

  double totalRunningTime = 0;
  double iterations = 0;
  int nbaff=1;
  int totalIt=0;
  L perPartIterations = inst.n / blockReduction;
  double additional = perPartIterations / (0.0 + inst.n);
  
  D fvalInit = Losses<L, D, traits>::compute_fast_objective(inst, residuals);
  D fval=fvalInit;
  D PvalInit=0;
  L tv=0;

  if (tv==1) {
    fvalInit=-fvalInit+0.5*normb2;
    fval = fvalInit;
    std::vector<D> gradu;
    gradu.resize(inst.N,0.);
    for (L i = 0; i < inst.N; i++)
      for (L k = inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) 
        gradu[i] += inst.A_csc_values[k] * inst.b[inst.A_csc_row_idx[k]];  
    for (L idx=0; idx < inst.N/2; idx++)
      PvalInit += inst.radius*sqrt(gradu[2*idx]*gradu[2*idx]+gradu[2*idx+1]*gradu[2*idx+1]);
  }

  // store initial objective value
  cout << setprecision(16) << omp_threads << "," << inst.n << "," << inst.m
       << "," << inst.sigma << "," << totalRunningTime << "," << iterations
       << "," << fval << endl;
  experimentLogFile  << setprecision(16) << omp_threads << "," << inst.n << ","
		     <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
		     << iterations << "," << fval << "," << fvalOpt << "," <<0<<",0,0,0"
		     << endl;

  //iterate
  while (totalRunningTime<MAXTIME) {
    double startTime = gettime_();
    if (algorithm==COORDINATE_DESCENT)
      {
#pragma omp parallel for
	for (L it = 0; it < perPartIterations; it++) {
	  // one step of the algorithm
	  unsigned long int idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);
	  Losses<L, D, traits>::do_single_iteration_parallel(inst, idx, residuals, inst.x, h_Li);
	}
      }
    else if (algorithm==ACCELERATED_COORDINATE_DESCENT)
      {
#pragma omp parallel
	{
	  D theta_loc=theta;
	  D iter_loc=iterations;
	  std::vector<D> update_z(maxblocksize);
	  std::vector<D> update_w(maxblocksize);
#pragma omp for
	  for (L it = 0; it < perPartIterations; it++) {
	      // one step of the algorithm
				
	      D ck=-(1.-1./tauovern*theta_loc)/(theta_loc*theta_loc);

	      unsigned long int idx = gsl_rng_uniform_int(gsl_rng_r, inst.n);

	      Losses<L, D, traits>::compute_update_accel(inst, theta_loc, residuals_w, residuals_z, idx, h_Li, update_z);
	      for (L i=0; i<inst.blocks_ptr[idx+1]-inst.blocks_ptr[idx]; i++)
		   update_w[i]=ck*update_z[i]; 
	      Losses<L, D, traits>::do_single_update_parallel_accel(inst, idx, residuals_w, residuals_z, h_Li, update_w, update_z);

   	      D theta2=theta_loc*theta_loc;
	      theta_loc=0.5*sqrt(theta2*theta2+4*theta2)-0.5*theta2;
	      iter_loc+=inst.tau;
		}  //end parallel for
#pragma omp critical
	      theta=min(theta,theta_loc);
	}  //end parallel
      }
    D ck=-(1.-1./tauovern*theta)/(theta*theta);
    double endTime = gettime_();
  //  if (algorithm!=ACCELERATED_COORDINATE_DESCENT)
	iterations += additional;
    totalRunningTime += endTime - startTime;

    // recompute residuals  - this step is not necessary but if accumulation of rounding errors occurs it is useful
    if (algorithm==ACCELERATED_COORDINATE_DESCENT)
      {
	for (L j=0; j<inst.m; j++)
	  residuals[j]=theta*theta*residuals_w[j]+residuals_z[j];
	for (L i=0; i<inst.N; i++)
	  inst.x[i]=theta*theta/(1-theta)*inst.w[i]+inst.z[i];
      }

    if (totalIt % 1 == 0) {
      if (algorithm==ACCELERATED_COORDINATE_DESCENT) {
	Losses<L, D, traits>::recompute_residuals(inst, residuals_w, inst.w, m_zeros);  
	Losses<L, D, traits>::recompute_residuals(inst, residuals_z, inst.z, inst.b);
      }
      Losses<L, D, traits>::recompute_residuals(inst, residuals);
    }
    fval = Losses<L, D, traits>::compute_fast_objective(inst, residuals);
    D Pval=fval;

    if (tv==1) {
        fval = -fval + 0.5*normb2;

	   Pval=0;
	   std::vector<D> gradu;
	   gradu.resize(inst.N,0.);
	   std::vector<D> primalvar(inst.b);
	   for (L i = 0; i < inst.N; i++)
	  	for (L k = inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) 
		    primalvar[inst.A_csc_row_idx[k]] -= inst.A_csc_values[k] * inst.x[i];  // u = -A * x + b
	   for (L j = 0; j< inst.m; j++)
		Pval += 0.5*(primalvar[j]-inst.b[j])*(primalvar[j]-inst.b[j]);
	   for (L i = 0; i < inst.N; i++)
		for (L k = inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) 
		    gradu[i] += inst.A_csc_values[k] * primalvar[inst.A_csc_row_idx[k]];  
	   for (L idx=0; idx < inst.N/2; idx++)
		Pval += inst.radius*sqrt(gradu[2*idx]*gradu[2*idx]+gradu[2*idx+1]*gradu[2*idx+1]);
   }

    L nnz = 0;
    D wnorm=0;

    if ((totalRunningTime>nbaff) || ((totalIt+1)%10000==0)){		
      cout << setprecision(5)<< omp_threads << "," << inst.n << ","
	   <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
	   << totalIt << "," << fval << "," << Pval << "," << (Pval-fval)/(PvalInit-fvalInit)  << "," << nnz << ","
	   << wnorm << "," <<theta<<endl;
      nbaff++;
    }


    experimentLogFile << setprecision(16) << omp_threads << "," << inst.n << ","
		      <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
		      << iterations << "," << fval << "," << -Pval << "," << nnz << ","
		      << wnorm << ","<< theta<<","<<ck<<endl;
    totalIt++;
  }
  cout << setprecision(5)<< omp_threads << "," << inst.n << ","
       <<  inst.m << "," <<  inst.sigma << "," << totalRunningTime << ","
       << iterations << "," << fval << "," << fvalOpt << endl;


std::vector<D> primalvar(inst.b);
for (L i = 0; i < inst.N; i++)
  for (L k = inst.A_csc_col_ptr[i]; k < inst.A_csc_col_ptr[i + 1]; k++) 
    primalvar[inst.A_csc_row_idx[k]] -= inst.A_csc_values[k] * inst.x[i];  // u = -A * x + b

ofstream result;
result.open("results/optvar");
for (L k=0; k<inst.m; k++)
	result << primalvar[k] << ",";

result << endl;

result.close();

result.open("results/optdualvar");
for (L k=0; k<inst.N; k++)
	result << inst.x[k] << ",";

result << endl;

result.close();

experimentLogFile.close();

}

template<typename L, typename D, typename traits>
void run_experiment(const char* filenameMatrix, const char* filenameVector, int N, int blockReduction,
		    std::vector<gsl_rng *>& rs, ofstream & histogramLogFile,
		    ofstream& experimentLogFile, const int MAXIMUM_THREADS, AlgorithmType algorithm) {

  problem_data<L, D> inst;
  omp_set_num_threads(MAXIMUM_THREADS);
  init_random_seeds(rs);

  double fvalOpt=0;
  inst.lambda=0.;

//  fvalOpt = nesterov_generator(inst, (L)10000, (L)10, (L)8, rs,	histogramLogFile);
//  transpose_matrix(inst);
  
  //load_file(inst, "/data/fercoq/MaliciousURLs/matriceadaboostcomp.mat", "/data/fercoq/MaliciousURLs/vectoradaboost.mat", rs, histogramLogFile);
  //load_file(inst, filenameMatrix, filenameVector, rs, histogramLogFile);

  L tv=0;
  if (tv==1) {
     load_image_and_construct_diff_matrix(inst, filenameMatrix, filenameVector);  //filenameMatrix only is the sizes of the image
     inst.radius=30.;
     inst.dimball=2;
  }
  else  {
     load_image_and_construct_tgv2_matrix(inst, filenameMatrix, filenameVector);  //filenameMatrix only is the sizes of the image
     inst.alpha=30.;
     inst.beta=30.;
  }
  if (inst.beta==0) // we do not want TGV2(alpha,0) but TV(alpha)
    for (L i=0; i<inst.N;i++)
	if (i%3!=0)
          { inst.lowerbound[i]=0; inst.upperbound[i]=0.;}

  if ((algorithm==COORDINATE_DESCENT) || (algorithm==ACCELERATED_COORDINATE_DESCENT))
	if (tv==1) inst.n=inst.N/2; else inst.n=inst.N;
  else if (algorithm==GRADIENT) {
	inst.n=1;
	algorithm=COORDINATE_DESCENT;
  }
  else if (algorithm==ACCELERATED_GRADIENT) {
	inst.n=1;
	algorithm=ACCELERATED_COORDINATE_DESCENT;
  }
  else if (algorithm==CHAMBOLLE_POCK)
	inst.n=1;

  inst.blocks_ptr.resize(inst.n+1);
  for (L k=0; k<inst.n+1; k++)
 	inst.blocks_ptr[k]=inst.N/inst.n*k;

cout << inst.N << "=" << inst.blocks_ptr[inst.n] << endl;

  std::vector<D> h_Li(inst.n, 0);
  //-------------- set the number of threads which should be used.
  int TH[1] = {1};
  for (int i = 0; i < 1; i++) {
    cout << "Running experiment with " << TH[i] << " threads" << endl;
    inst.tau=TH[i];
    inst.sigma = 1. + (TH[i] - 1.) * (inst.omega) / (D)(inst.n);  // 1. instead of 1 to avoid Euclidean division.
    inst.epsilon=inst.N/10*inst.alpha;
    cout << setprecision(16) << "omega = " << inst.omega << ", beta = " << inst.sigma << ", radius = " << inst.radius <<endl;
    Losses<L, D, traits>::compute_reciprocal_lipschitz_constants(inst, h_Li);

    // run the experiment
    run_computation<L, D,traits>(inst, h_Li, fvalOpt, TH[i], inst.n, inst.m, inst.sigma, N, 1, rs,
				 experimentLogFile, MAXIMUM_THREADS, algorithm);

  }
}

int main(int argc, char * argv[]) {

  // setup GSL random generators
  gsl_rng_env_setup();
  const gsl_rng_type * T;
  gsl_rng * r;
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
  const int MAXIMUM_THREADS = 24;
  std::vector<gsl_rng *> rs(MAXIMUM_THREADS);
  for (int i = 0; i < MAXIMUM_THREADS; i++) {
    rs[i] = gsl_rng_alloc(T);
    gsl_rng_set(rs[i], i);
  }
  init_omp_random_seeds();

  //---------------------- Setting parameters of experiments

  for (int expe=0; expe<4; expe++){
    string expename;
    string filenameMatrix;
    string filenameVector;

    if ((expe<4) && (expe>=0))
	expename="kodim23gray-noisy";
    else if (expe<8)
      expename = "kodimsmall-noisy";
    else if (expe<12)
	expename="untersberg-noisy";
    filenameMatrix="/home/ofercoq/ofercoq/mycodes/block-imaging/img/"+expename+".size"; //"/data/fercoq/MaliciousURLs/matricecomp.mat";//
    filenameVector="/home/ofercoq/ofercoq/mycodes/block-imaging/img/"+expename+".ascii"; //"/data/fercoq/MaliciousURLs/vector.mat";  // 

    cout << "Dataset: " << expename << ", algorithm: ";

    AlgorithmType algorithm = COORDINATE_DESCENT;
    if (expe%4==0)
      algorithm = COORDINATE_DESCENT;
    else if (expe%4==1)
      algorithm = CHAMBOLLE_POCK;
    else if (expe%4==2)
      algorithm = ACCELERATED_COORDINATE_DESCENT;
    else if (expe%4==3)
      algorithm = ACCELERATED_GRADIENT;

    //---------------------- Set output files
    ofstream histogramLogFile;
    histogramLogFile.open("results/large_scale_experiment_histogram.log");
    ofstream experimentLogFile;	
    string logfilename="results/experiment_"+expename+"_";
    if (expe%4==0)
      {	logfilename+="COORDINATE_DESCENT"; cout << "COORDINATE_DESCENT" << endl;}
    else if (expe%4==1)
      {	logfilename+="CHAMBOLLE_POCK"; cout << "CHAMBOLLE_POCK" << endl;}
    else if (expe%4==2)
      {	logfilename+="ACCELERATED_COORDINATE_DESCENT"; cout << "ACCELERATED_COORDINATE_DESCENT" << endl;}
    else if (expe%4==3)
      {	logfilename+="ACCELERATED_GRADIENT"; cout << "ACCELERATED_GRADIENT" << endl;}

    experimentLogFile.open(logfilename.c_str());
    //--------------------- run experiment - one can change precision here
    run_experiment<long long, double, tgv2_loss_traits>(filenameMatrix.c_str(), filenameVector.c_str(),200., 1, rs, histogramLogFile,  experimentLogFile, MAXIMUM_THREADS, algorithm);
    histogramLogFile.close();
    experimentLogFile.close();	

  }
	

  return 0;
}
