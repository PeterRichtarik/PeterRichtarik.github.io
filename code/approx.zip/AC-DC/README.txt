﻿This small package contains a code which was used to generate data for plot in Section 7 of paper
P. Richtárik and M. Takáč: Parallel Coordinate Descent Methods for Big Data Optimization
http://www.optimization-online.org/DB_HTML/2012/11/3688.html
It has been modified to deal with the problems solved in the paper
O. Fercoq and P. Richtárik: Accelerated Parallel and Proximal Coordinate Descent.

The dataset's name and the problem are hard coded in the file src/experiments/experiment.cpp.
The matrices should be entered as an ascii file. We provide the Matlab script saveSparseMatrix.m to save Matlab matrices into our file format. Vectors are just given as the list of their entries, one number per line.

To compile and run type:

>> cd PUT_PATH_TO_ROOT_WHERE_THIS_README_FILE_IS
>> make experiment
>> release/experiment

into your terminal and the computation will start.

Tested on

g++ (Ubuntu/Linaro 4.7.2-4precise1) 4.7.2

Please note, that you have to have GSL library installed http://www.gnu.org/software/gsl/
We tried it with version 1.15

This code comes as is, with no guarantee. We did not perform extensive testings. We welcome any suggestion to solve bugs or improve the code.