function saveSparseMatrix(filename, A)
[i,j,s]=find(A);
n=size(A,2);
m=size(A,1);
nnz_=nnz(A);
Ajc=zeros(n+1,1);
Ajc(1)=0;
l=1;
k=1;
while k<=nnz_
    if j(k)<=l
        Ajc(l+1)=Ajc(l+1)+1;
        k=k+1;
    else
        l=l+1;
        Ajc(l+1)=Ajc(l);
    end
end
Air=i-1;
Apr=s;

save(filename, 'n', 'm', 'nnz_', 'Ajc', 'Air', 'Apr', '-ascii','-double');

end

