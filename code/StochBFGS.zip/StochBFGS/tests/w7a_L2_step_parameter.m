%% step size parameters for real_sim
% BBFGS_gauss
BBFGS_gauss_step_parameter =   10^(-2);
% FBBFGS gaussian
FBBFGS_gauss_step_parameter =   10^(-2);
% LBBFGS_metric-action-gauss
LBBFGS_prev_step_parameter =   10^(-3);
% LBBFGS gaussian
LBBFGS_gauss_step_parameter =   10^(-3);
% LFBBFGS
LFBBFGS_step_parameter  =  7*10^(-3);
%SQN 
SQN_step_parameter  =  10^(-2);
% SVRG 
SVRG_step_parameter  =10^(-2);