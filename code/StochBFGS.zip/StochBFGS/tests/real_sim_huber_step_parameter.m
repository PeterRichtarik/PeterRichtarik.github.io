%% step size parameters for covtype
% LBBFGS_prev    %%using previous search directions
LBBFGS_prev_step_parameter =   10^(-2);
% LBBFGS gaussian
LBBFGS_gaussian_step_parameter =   10^(-2);
% LFBBFGS
LFBBFGS_step_parameter  =  10^(-3);
%SQN 
SQN_step_parameter  =  5*10^(-2);
% SVRG 
SVRG_step_parameter  = 10^(-1);